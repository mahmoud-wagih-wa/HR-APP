const LEAVE_TYPES = ["راحة","يوم شهر","راحة عيد"];
const TRANSFER_TYPE = "انتقال مصنع";
const STATUSES = ["دائم","مؤقت","تحت الاختبار"];
const FACTORIES = ['الرئيسي','الواحة','الإسكندرية','أسيوط'];
const FACTORY_COLORS = ['#2B5F5A','#3B6FA0','#A0527A','#6E7F3C','#B34B4B','#7A5AA8','#C97B3D','#4B6FA0'];
const SHIFTS = ['الوردية الأولى','الوردية الثانية','الوردية الثالثة'];
const RANKS = ['مهندس','كبير مشرفين','مشرف','مساعد مشرف','مشغل'];
const ROSTER_GROUPS = ['الرئيسي','الواحة','أسيوط']; // الإسكندرية nested inside الواحة's page
const ROSTER_HEADS = { 'الرئيسي':'محمد سعيد', 'الواحة':'أحمد مهدي  /  محمد قمر', 'أسيوط':'' };
const PINNED_NAMES = ['محمد سعيد','أحمد مهدي','محمد قمر','محمد علي السيد']; // fixed heads — excluded from shift columns (matched as substrings)
function normalizeAr(s){ return String(s||'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/\s+/g,' ').trim(); }
const MEETING_GROUPS = ['الاجتماع الأول','الاجتماع الثاني'];
const CITATION_KINDS = ['مكافأة','جزاء'];
const WEEK_ANCHOR_DATE = new Date(2026,6,18); // Saturday 18/7/2026 = week 38
const WEEK_ANCHOR_NUMBER = 38;
let employees = [];
let leaves = [];
let transfers = [];
let citations = []; // {id, employeeId, kind:'مكافأة'|'جزاء', amount, reason, date}
let employeePhotos = {};
let currentTab = "dash";
let selectedLeaveType = LEAVE_TYPES[0];
let editingEmpId = null;
let editingLeaveId = null;
let editingCitationId = null;
let selectedCitationKind = CITATION_KINDS[0];
let citationSearch = '';
let citationFactoryFilter = '';
let citationKindFilter = '';
let citationMonthFilter = '';
let citationSortState = {col:'date', dir:-1};
let reportPeriod = 'month'; // 'week' | 'month' | 'year'
let reportView = 'summary'; // 'summary' | 'calendar'
let reportRefDate = new Date();
let reportFactoryFilter = '';
let dashFactoryFilter = '';
let logFactoryFilter = '';
let logTypeFilter = '';
let logMonthFilter = '';
let empSearch = '';
let empStatusFilter = '';
let empSortState = {col:'code', dir:1};
let logSearch = '';
let logShiftFilter = '';
let logSortState = {col:'date', dir:-1};
let reportSortState = {col:'name', dir:1};
let reportShiftFilter = '';
let reportSearch = '';
let reportStatusFilter = '';
let reportCustomStart = fmtDate(new Date(Date.now()-6*86400000));
let reportCustomEnd = fmtDate(new Date());
let recentLeaveSearch = '';
let recentLeaveFactoryFilter = '';
let recentLeaveShiftFilter = '';
let recentLeaveSortState = {col:'date', dir:-1};
let rosterGroup = 'الرئيسي';
let rosterRefDate = new Date();
let alexMsgRefDate = new Date();
let lastAlexMsgText = '';
let rosterShowFriday = false;
let alexandriaWeekly = {};
let alexandriaOrder = [];
let alexStartWeek = 41;
let meetingGroups = [];
let meetingEditing = false;

function compareVal(a,b){
  const as = String(a).trim(), bs = String(b).trim();
  const numA = as!=='' && /^\d+(\.\d+)?$/.test(as);
  const numB = bs!=='' && /^\d+(\.\d+)?$/.test(bs);
  if(numA && numB) return parseFloat(as) - parseFloat(bs);
  return as.localeCompare(bs, 'ar');
}
function toggleSort(state, col){
  if(state.col===col){ state.dir *= -1; } else { state.col=col; state.dir=1; }
}
function sortArrow(state, col){
  if(state.col!==col) return '<span style="opacity:.35;">↕</span>';
  return state.dir===1 ? '<span style="color:var(--brand);">↑</span>' : '<span style="color:var(--brand);">↓</span>';
}
function setEmpSort(col){ toggleSort(empSortState, col); render(); }
function setRecentLeaveSort(col){ toggleSort(recentLeaveSortState, col); render(); }
function setLogSort(col){ toggleSort(logSortState, col); applyLogFilters(); }
function setReportSort(col){ toggleSort(reportSortState, col); render(); }

function slug(t){ return t.replace(/\s+/g,'-'); }
function uid(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,7); }
function escapeHtml(str){
  return String(str==null?'':str).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function fmtDate(d){
  const y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,'0'), day=String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function dateFmtShort(d){ return `${d.getDate()}/${d.getMonth()+1}`; }
function fmtDateAr(isoStr){
  if(!isoStr) return '';
  const [y,m,d] = isoStr.split('-');
  return `${parseInt(d,10)}/${parseInt(m,10)}/${y}`;
}
function parseDate(s){ const [y,m,d]=s.split('-').map(Number); return new Date(y,m-1,d); }
function todayStr(){ return fmtDate(new Date()); }
function inRange(dateStr, start, end){
  const d = parseDate(dateStr);
  return d>=start && d<=end;
}
function countFridays(start, end){
  let c=0; const d=new Date(start);
  while(d<=end){ if(d.getDay()===5) c++; d.setDate(d.getDate()+1); }
  return c;
}
function getSaturdayOf(date){
  const d = new Date(date);
  const dow = d.getDay(); // 0=Sun..6=Sat
  const diff = (dow - 6 + 7) % 7;
  d.setDate(d.getDate()-diff);
  d.setHours(0,0,0,0);
  return d;
}
function weekNumberFor(saturday){
  const diffDays = Math.round((saturday - WEEK_ANCHOR_DATE)/(1000*60*60*24));
  return WEEK_ANCHOR_NUMBER + Math.round(diffDays/7);
}
function weekKeyFor(refDate){ return fmtDate(getSaturdayOf(refDate)); }
function getWeekSnapshot(weekKey){
  // كل أسبوع له نسخته الخاصة. لو الأسبوع ده لسه معملهوش حد أي تغيير، بنورّي أقرب أسبوع سابق كنقطة بداية بس من غير ما نلمس بياناته
  if(weeklyRoster[weekKey]) return weeklyRoster[weekKey];
  const priorKeys = Object.keys(weeklyRoster).filter(k => k < weekKey).sort();
  if(priorKeys.length===0) return {};
  return weeklyRoster[priorKeys[priorKeys.length-1]];
}
function materializeWeek(weekKey){
  if(!weeklyRoster[weekKey]){
    // انسخ ورديات الأسبوع السابق فقط كنقطة بداية.
    // جدول الجمعة لا ينتقل تلقائيًا من أسبوع لآخر؛ لكل جمعة بياناتها المستقلة.
    const prior = getWeekSnapshot(weekKey);
    const copy = Object.assign({}, prior || {});
    delete copy.__friday;
    weeklyRoster[weekKey] = copy;
  }
  return weeklyRoster[weekKey];
}

function getFridaySnapshot(weekKey){
  const snap = weeklyRoster[weekKey];
  if(!snap || !snap.__friday || typeof snap.__friday !== 'object') return {};
  return snap.__friday;
}
function currentShiftOf(empId){
  return getWeekSnapshot(weekKeyFor(new Date()))[empId] || null;
}
function factoryColor(name){
  const idx = FACTORIES.indexOf(name);
  return FACTORY_COLORS[idx>=0 ? idx % FACTORY_COLORS.length : 0];
}
function rankColor(rank){
  const map = {
    'مهندس':'var(--type3)',
    'كبير مشرفين':'var(--brand-dark)',
    'مشرف':'var(--danger)',
    'مساعد مشرف':'var(--brand)',
    'مشغل':'var(--accent)'
  };
  return map[rank] || 'var(--ink-soft)';
}

const STORAGE_KEY_EMP = 'hr-employees';
const STORAGE_KEY_LEAVES = 'hr-leaves';
const STORAGE_KEY_TRANSFERS = 'hr-transfers';
const STORAGE_KEY_PHOTOS = 'hr-employee-photos';
const STORAGE_KEY_ALEX = 'hr-alex-weekly';
const STORAGE_KEY_MEETINGS = 'hr-meetings';
const STORAGE_KEY_ALEX_ORDER = 'hr-alex-order';
const STORAGE_KEY_ALEX_START = 'hr-alex-start-week';
const STORAGE_KEY_WEEKLY_ROSTER = 'hr-weekly-roster';
const STORAGE_KEY_CITATIONS = 'hr-citations';
const SYNC_URL_KEY = 'hr-sync-url';
const STORAGE_KEY_SYNC_VERSION = 'hr-sync-version';
let syncVersion = Number(localStorage.getItem(STORAGE_KEY_SYNC_VERSION) || 0);
let weeklyRoster = {}; // { weekKey: { employeeId: shift } } — each week is its own independent snapshot

function defaultAlexOrder(){
  // كل سطرين متجاورين هنا هما اللي كانوا قصاد بعض في نفس صف الجدول المرجعي (الصورة) — بيسافروا مع بعض
  return [
    {name:'احمد عبدالرحمن', code:'1544'},
    {name:'رضا عمر', code:'1114'},
    {name:'مدحت عبدالحفيظ', code:'379'},
    {name:'باسم عبدالرحمن', code:'1009'},
    {name:'محمد عبدالله شحاته', code:'1575'},
    {name:'حسام محمد', code:'2171'},
    {name:'أحمد عزب', code:'399'},
    {name:'عبدالرحمن محمد', code:'1345'},
    {name:'وحيد عزت', code:'387'},
    {name:'علي رجب', code:'2334'},
    {name:'محمود توفيق', code:'2831'},
    {name:'اسلام رمضان', code:'2104'},
    {name:'محمد عبدالله', code:'376'},
    {name:'محمود وجيه حجو', code:'2037'},
    {name:'بسام محمد', code:'2080'},
    {name:'عبدالحميد عيد', code:'1040'},
    {name:'محمد عبدالعزيز', code:'1338'},
    {name:'السيد محمد', code:'1065'},
    {name:'احمد محمد السيد', code:'391'},
    {name:'احمد جاد', code:'1117'},
    {name:'احمد احمد يونس', code:'387'},
    {name:'ناصر اسماعيل', code:'1146'},
    {name:'محمد دسوقي', code:'2638'},
    {name:'محمود سعيد', code:'3635'},
  ];
}

function defaultMeetingGroups(){
  return MEETING_GROUPS.map((title,i)=>({ id:'mg'+i, title, rows:[{name:'',code:''}] }));
}

async function loadData(){
  try{
    const e = localStorage.getItem(STORAGE_KEY_EMP);
    employees = e ? JSON.parse(e) : [];
  }catch(err){ employees = []; }
  try{
    const l = localStorage.getItem(STORAGE_KEY_LEAVES);
    leaves = l ? JSON.parse(l) : [];
  }catch(err){ leaves = []; }
  try{
    const tr = localStorage.getItem(STORAGE_KEY_TRANSFERS);
    transfers = tr ? JSON.parse(tr) : [];
  }catch(err){ transfers = []; }
  try{
    const ci = localStorage.getItem(STORAGE_KEY_CITATIONS);
    citations = ci ? JSON.parse(ci) : [];
  }catch(err){ citations = []; }
  try{
    const ph = localStorage.getItem(STORAGE_KEY_PHOTOS);
    employeePhotos = ph ? JSON.parse(ph) : {};
  }catch(err){ employeePhotos = {}; }
  try{
    const a = localStorage.getItem(STORAGE_KEY_ALEX);
    alexandriaWeekly = a ? JSON.parse(a) : {};
  }catch(err){ alexandriaWeekly = {}; }
  try{
    const m = localStorage.getItem(STORAGE_KEY_MEETINGS);
    meetingGroups = m ? JSON.parse(m) : defaultMeetingGroups();
  }catch(err){ meetingGroups = defaultMeetingGroups(); }
  try{
    const ao = localStorage.getItem(STORAGE_KEY_ALEX_ORDER);
    alexandriaOrder = ao ? JSON.parse(ao) : defaultAlexOrder();
  }catch(err){ alexandriaOrder = defaultAlexOrder(); }
  try{
    const asw = localStorage.getItem(STORAGE_KEY_ALEX_START);
    alexStartWeek = asw ? parseInt(asw,10) : 41;
  }catch(err){ alexStartWeek = 41; }
  try{
    const wr = localStorage.getItem(STORAGE_KEY_WEEKLY_ROSTER);
    weeklyRoster = wr ? JSON.parse(wr) : {};
  }catch(err){ weeklyRoster = {}; }
  // one-time migration: if no weekly snapshots exist yet but employees have the old flat .shift value, seed this week from it
  if(Object.keys(weeklyRoster).length===0){
    const todayKey = fmtDate(getSaturdayOf(new Date()));
    const seed = {};
    let any = false;
    employees.forEach(e=>{ if(e.shift){ seed[e.id]=e.shift; any=true; } });
    if(any){
      weeklyRoster[todayKey] = seed;
      localStorage.setItem(STORAGE_KEY_WEEKLY_ROSTER, JSON.stringify(weeklyRoster));
    }
  }
}
async function saveEmployees(){
  try{ localStorage.setItem(STORAGE_KEY_EMP, JSON.stringify(employees)); }
  catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushToRemote();
}
async function saveLeaves(){
  try{ localStorage.setItem(STORAGE_KEY_LEAVES, JSON.stringify(leaves)); }
  catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushToRemote();
}
async function saveTransfers(){
  try{ localStorage.setItem(STORAGE_KEY_TRANSFERS, JSON.stringify(transfers)); }
  catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushToRemote();
}
async function saveCitations(){
  try{ localStorage.setItem(STORAGE_KEY_CITATIONS, JSON.stringify(citations)); }
  catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushToRemote();
}
// الصور بتتحفظ محليًا، وبرضو بتتزامن — لكن كل صورة بتتبعت لوحدها في طلب منفصل وصغير
// (مش جوه البيانات العامة)، عشان صورة كبيرة متبطّئش أو توقف مزامنة الإجازات والموظفين.
async function savePhotos(){
  try{ localStorage.setItem(STORAGE_KEY_PHOTOS, JSON.stringify(employeePhotos)); }
  catch(err){ showToast('الصورة كبيرة قوي أو مساحة التخزين خلصت — جرّب صورة أصغر'); }
}
function resizeImageToDataUrl(file, maxSize){
  return new Promise((resolve, reject)=>{
    const reader = new FileReader();
    reader.onerror = ()=>reject(new Error('read failed'));
    reader.onload = ()=>{
      const img = new Image();
      img.onerror = ()=>reject(new Error('image failed'));
      img.onload = ()=>{
        const side = Math.min(img.width, img.height);
        const sx = (img.width-side)/2, sy = (img.height-side)/2;
        const canvas = document.createElement('canvas');
        canvas.width = maxSize; canvas.height = maxSize;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, sx, sy, side, side, 0, 0, maxSize, maxSize);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
const STORAGE_KEY_PHOTO_PENDING = 'hr-photos-pending';
function loadPendingPhotoActions(){
  try{ return JSON.parse(localStorage.getItem(STORAGE_KEY_PHOTO_PENDING) || '{}'); }
  catch(err){ return {}; }
}
function savePendingPhotoActions(obj){
  try{ localStorage.setItem(STORAGE_KEY_PHOTO_PENDING, JSON.stringify(obj)); }catch(err){}
}
function markPhotoPending(employeeId, action, dataUrl){
  const pending = loadPendingPhotoActions();
  pending[employeeId] = action==='set' ? {action:'set', dataUrl} : {action:'delete'};
  savePendingPhotoActions(pending);
}
function clearPhotoPending(employeeId){
  const pending = loadPendingPhotoActions();
  if(pending[employeeId]){ delete pending[employeeId]; savePendingPhotoActions(pending); }
}
// بيحاول يبعت أي تعديلات صور اتأجلت بسبب فشل في النت. بينادى تلقائي أول ما
// النت يرجع، وكمان في بداية التطبيق وعند "مزامنة الآن".
async function flushPendingPhotos(){
  const pending = loadPendingPhotoActions();
  const ids = Object.keys(pending);
  if(ids.length===0) return;
  for(const id of ids){
    const item = pending[id];
    let ok;
    if(item.action==='set') ok = await pushPhotoToRemote(id, item.dataUrl);
    else ok = await deletePhotoRemote(id);
    if(ok) clearPhotoPending(id);
  }
}
window.addEventListener('online', flushPendingPhotos);

async function handlePhotoUpload(employeeId, file){
  if(!file) return;
  if(!file.type.startsWith('image/')){ showToast('لازم تختار صورة'); return; }
  try{
    const dataUrl = await resizeImageToDataUrl(file, 160);
    employeePhotos[employeeId] = dataUrl;
    await savePhotos();
    render();
    const synced = await pushPhotoToRemote(employeeId, dataUrl);
    if(synced){
      clearPhotoPending(employeeId);
      showToast('تم حفظ الصورة ومزامنتها');
    }else{
      markPhotoPending(employeeId, 'set', dataUrl);
      showToast('تعذّر الاتصال — الصورة محفوظة على الجهاز ده وهتتزامن تلقائي أول ما النت يرجع');
    }
  }catch(err){
    showToast('حصلت مشكلة في تحميل الصورة — جرّب تاني');
  }
}
async function removePhoto(employeeId){
  delete employeePhotos[employeeId];
  await savePhotos();
  render();
  const ok = await deletePhotoRemote(employeeId);
  if(!ok) markPhotoPending(employeeId, 'delete');
  else clearPhotoPending(employeeId);
}
// بيبعت صورة موظف واحد بس في طلب منفصل — مش جزء من المزامنة العامة.
async function pushPhotoToRemote(employeeId, dataUrl){
  const url = getSyncUrl();
  if(!url) return false;
  try{
    await fetch(url, {
      method:'POST',
      headers:{'Content-Type':'text/plain;charset=utf-8'},
      body: JSON.stringify({action:'setPhoto', employeeId, dataUrl})
    });
    return true;
  }catch(err){
    return false;
  }
}
async function deletePhotoRemote(employeeId){
  const url = getSyncUrl();
  if(!url) return false;
  try{
    await fetch(url, {
      method:'POST',
      headers:{'Content-Type':'text/plain;charset=utf-8'},
      body: JSON.stringify({action:'deletePhoto', employeeId})
    });
    return true;
  }catch(err){
    return false;
  }
}
// بيجيب كل صور الموظفين اللي زمّلاءك رفعوها على أجهزة تانية — بيتنادى مرة عند فتح الصفحة،
// ومرة كمان لو دُست "مزامنة الآن" يدويًا. مش بيتنادى مع كل حفظ عادي عشان يفضل سريع.
async function pullPhotosFromRemote(manual){
  const url = getSyncUrl();
  if(!url) return;
  try{
    const sep = url.includes('?') ? '&' : '?';
    const res = await fetch(url + sep + 'action=photos');
    const data = await res.json();
    if(data && typeof data==='object'){
      // استبدال كامل، مش دمج — لو حد مسح صورة من جهاز تاني، لازم تتمسح عندك
      // كمان. الدمج كان بيخلي الصور المحذوفة ترجع تاني على أي جهاز تاني.
      employeePhotos = data;
      await savePhotos();
      render();
    }
    if(manual) showToast('تم تحديث الصور');
  }catch(err){
    // فشل جلب الصور مش مشكلة حرجة زي فشل جلب باقي البيانات، فبنسيبها تفضل زي ما هي
  }
}
async function saveAlexWeekly(){
  try{ localStorage.setItem(STORAGE_KEY_ALEX, JSON.stringify(alexandriaWeekly)); }
  catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushToRemote();
}
async function saveWeeklyRoster(weekKey){
  try{ localStorage.setItem(STORAGE_KEY_WEEKLY_ROSTER, JSON.stringify(weeklyRoster)); }
  catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushWeekToRemote(weekKey || rosterWeekRange().key);
}
async function saveAlexOrder(){
  try{
    localStorage.setItem(STORAGE_KEY_ALEX_ORDER, JSON.stringify(alexandriaOrder));
    localStorage.setItem(STORAGE_KEY_ALEX_START, String(alexStartWeek));
  }catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushToRemote();
}
async function saveMeetings(){
  try{ localStorage.setItem(STORAGE_KEY_MEETINGS, JSON.stringify(meetingGroups)); }
  catch(err){ showToast('حصل خطأ في الحفظ'); }
  pushToRemote();
}

/* ---------- SYNC (Google Apps Script backend) ---------- */
function getSyncUrl(){
  return localStorage.getItem(SYNC_URL_KEY) || '';
}
function setSyncStatus(text, kind){
  const el = document.getElementById('syncStatus');
  if(!el) return;
  el.textContent = text;
  el.className = 'sync-status' + (kind? ' '+kind : '');
}
function toggleSyncPanel(){
  const p = document.getElementById('syncPanel');
  const input = document.getElementById('syncUrlInput');
  input.value = getSyncUrl();
  p.style.display = p.style.display==='none' ? 'block' : 'none';
}
function saveSyncUrl(){
  const url = document.getElementById('syncUrlInput').value.trim();
  if(url){
    const hasLocalData = employees.length>0 || leaves.length>0;
    const isNewUrl = url !== getSyncUrl();
    if(hasLocalData && isNewUrl){
      const sure = confirm('عندك بيانات محفوظة على الجهاز ده بالفعل. لما تفعّل المزامنة، أي بيانات موجودة على الرابط ده هتستبدل اللي شايفه دلوقتي على الشاشة. متأكد إنك عايز تكمل؟');
      if(!sure) return;
    }
    localStorage.setItem(SYNC_URL_KEY, url);
    showToast('تم حفظ رابط المزامنة');
    pullFromRemote(true);
    pullPhotosFromRemote(false);
    flushPendingPhotos();
    flushPendingWeeks();
  }else{
    localStorage.removeItem(SYNC_URL_KEY);
    setSyncStatus('غير مفعّلة — البيانات محفوظة على الجهاز ده بس');
    showToast('تم إلغاء تفعيل المزامنة');
  }
}
// حفظ أسبوع واحد بس في الجدول الأسبوعي — بيعدّل صف الأسبوع ده لوحده في شيت
// WeeklyRoster من غير ما يلمس أي أسبوع تاني أو أي بيانات تانية. ده أضمن
// وأسرع بكتير من بعت كل البيانات في كل دوسة، ومش بيتعارض مع حفظ حاجة تانية
// بتحصل في نفس الوقت (زي تعديل موظف).
async function pushWeekToRemote(weekKey){
  const url = getSyncUrl();
  if(!url || !weekKey) return;
  try{
    setSyncStatus('جارِ حفظ الأسبوع…');
    const res = await fetch(url, {
      method:'POST',
      headers:{'Content-Type':'text/plain;charset=utf-8'},
      body: JSON.stringify({action:'setWeek', weekKey, data: weeklyRoster[weekKey] || {}})
    });
    let result;
    try{ result = await res.json(); } catch(parseErr){ throw new Error('bad response'); }
    if(!res.ok || result.status !== 'ok'){ throw new Error(result.message || ('http '+res.status)); }
    clearWeekPending(weekKey);
    setSyncStatus('تمت المزامنة ✓', 'ok');
  }catch(err){
    setSyncStatus('تعذّرت مزامنة الأسبوع — هيتحفظ على الجهاز ده بس ويعاد المحاولة', 'err');
    markWeekPending(weekKey, weeklyRoster[weekKey] || {});
  }
}
// قائمة الأسابيع اللي اتعدّلت محليًا ولسه ما اتأكدش وصولها للسيرفر — بتخزن
// المحتوى الفعلي (مش بس اسم الأسبوع)، عشان نقدر نرجّعه لو السحب من السيرفر
// جاب نسخة أقدم فوقه بالغلط.
const STORAGE_KEY_WEEK_PENDING = 'hr-weeks-pending';
function loadPendingWeeks(){
  try{ return JSON.parse(localStorage.getItem(STORAGE_KEY_WEEK_PENDING)||'{}'); }catch(err){ return {}; }
}
function markWeekPending(weekKey, data){
  const p = loadPendingWeeks();
  p[weekKey] = data;
  try{ localStorage.setItem(STORAGE_KEY_WEEK_PENDING, JSON.stringify(p)); }catch(err){}
}
function clearWeekPending(weekKey){
  const p = loadPendingWeeks();
  if(weekKey in p){ delete p[weekKey]; try{ localStorage.setItem(STORAGE_KEY_WEEK_PENDING, JSON.stringify(p)); }catch(err){} }
}
async function flushPendingWeeks(){
  const pending = loadPendingWeeks();
  const keys = Object.keys(pending);
  if(keys.length===0) return;
  const url = getSyncUrl();
  if(!url) return;
  for(const wk of keys){
    try{
      const res = await fetch(url, {
        method:'POST', headers:{'Content-Type':'text/plain;charset=utf-8'},
        body: JSON.stringify({action:'setWeek', weekKey: wk, data: pending[wk] || {}})
      });
      const result = await res.json();
      if(res.ok && result.status === 'ok') clearWeekPending(wk);
    }catch(err){ /* هيفضل معلّق، هنحاول تاني بعدين */ }
  }
}
// بعد أي سحب من السيرفر، لو لسه في أسابيع معلّقة (فشلت حتى بعد إعادة
// المحاولة)، نرجّع نسختها المحلية فوق اللي جاي من السيرفر — عشان السحب
// مايمسحش تعديل محلي لسه ما اتأكدش وصوله، وده بالظبط اللي كان بيحصل قبل كده.
function reapplyPendingWeeksLocally(){
  const pending = loadPendingWeeks();
  const keys = Object.keys(pending);
  if(keys.length===0) return;
  keys.forEach(wk=>{ weeklyRoster[wk] = pending[wk]; });
  try{ localStorage.setItem(STORAGE_KEY_WEEKLY_ROSTER, JSON.stringify(weeklyRoster)); }catch(err){}
  showToast(`تم استرجاع ${keys.length===1?'أسبوع كان':'عدد '+keys.length+' أسابيع كانت'} لسه ما اتزامنش — هيعاد المحاولة`);
}
window.addEventListener('online', flushPendingWeeks);

let pushInFlight = false;
let pushQueuedAgain = false;
async function pushToRemote(){
  // لو في مزامنة شغالة دلوقتي (زي وقت التعديل السريع في الجدول الأسبوعي)،
  // منبعتش طلب فوقه — بس نعلّم إننا محتاجين نبعت تاني أول ما يخلص، بآخر
  // نسخة من البيانات وقتها. ده بيمنع تضارب الجهاز مع نفسه.
  if(pushInFlight){ pushQueuedAgain = true; return; }
  pushInFlight = true;
  try{ await pushOnce(); }
  finally{
    pushInFlight = false;
    if(pushQueuedAgain){ pushQueuedAgain = false; pushToRemote(); }
  }
}
async function pushOnce(){
  const url = getSyncUrl();
  if(!url) return;
  try{
    setSyncStatus('جارِ المزامنة…');
    const res = await fetch(url, {
      method:'POST',
      headers:{'Content-Type':'text/plain;charset=utf-8'},
      body: JSON.stringify({employees, leaves, transfers, citations, alexandriaWeekly, meetingGroups, alexandriaOrder, alexStartWeek, expectedVersion: syncVersion})
    });
    let result;
    try{ result = await res.json(); }
    catch(parseErr){ throw new Error('bad response'); }

    if(!res.ok || result.status !== 'ok'){
      throw new Error(result.message || ('http '+res.status));
    }
    if(typeof result.version === 'number'){
      syncVersion = result.version;
      localStorage.setItem(STORAGE_KEY_SYNC_VERSION, String(syncVersion));
    }
    setSyncStatus('تمت المزامنة ✓', 'ok');
  }catch(err){
    setSyncStatus('تعذّرت المزامنة — هيتحفظ على الجهاز ده بس', 'err');
  }
}
async function pullFromRemote(manual){
  const url = getSyncUrl();
  if(!url){
    if(manual) showToast('محتاج تحفظ رابط المزامنة الأول');
    return;
  }
  try{
    setSyncStatus('جارِ جلب آخر تحديث…');
    const res = await fetch(url);
    const data = await res.json();
    if('employees' in data) employees = data.employees || [];
    if('leaves' in data) leaves = data.leaves || [];
    if('transfers' in data) transfers = data.transfers || [];
    if('citations' in data) citations = data.citations || [];
    if('alexandriaWeekly' in data) alexandriaWeekly = data.alexandriaWeekly || {};
    if('meetingGroups' in data) meetingGroups = data.meetingGroups || [];
    if('alexandriaOrder' in data) alexandriaOrder = data.alexandriaOrder || [];
    if('alexStartWeek' in data && (data.alexStartWeek || data.alexStartWeek===0)) alexStartWeek = data.alexStartWeek;
    if('weeklyRoster' in data) weeklyRoster = data.weeklyRoster || {};
    if(typeof data.version === 'number'){
      syncVersion = data.version;
      localStorage.setItem(STORAGE_KEY_SYNC_VERSION, String(syncVersion));
    }
    localStorage.setItem(STORAGE_KEY_EMP, JSON.stringify(employees));
    localStorage.setItem(STORAGE_KEY_LEAVES, JSON.stringify(leaves));
    localStorage.setItem(STORAGE_KEY_TRANSFERS, JSON.stringify(transfers));
    localStorage.setItem(STORAGE_KEY_CITATIONS, JSON.stringify(citations));
    localStorage.setItem(STORAGE_KEY_ALEX, JSON.stringify(alexandriaWeekly));
    localStorage.setItem(STORAGE_KEY_MEETINGS, JSON.stringify(meetingGroups));
    localStorage.setItem(STORAGE_KEY_ALEX_ORDER, JSON.stringify(alexandriaOrder));
    localStorage.setItem(STORAGE_KEY_ALEX_START, String(alexStartWeek));
    localStorage.setItem(STORAGE_KEY_WEEKLY_ROSTER, JSON.stringify(weeklyRoster));
    setSyncStatus('متزامن ✓ — آخر تحديث الآن', 'ok');
    render();
    if(manual) showToast('تم تحديث البيانات من المزامنة');
  }catch(err){
    setSyncStatus('تعذّر الاتصال بالمزامنة — بيانات الجهاز فقط', 'err');
  }
}

function showToast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 1800);
}

function empName(id){
  const e = employees.find(x=>x.id===id);
  return e ? e.name : '—';
}
function empPhoneCell(e){
  const nums = [e.phone1, e.phone2].filter(Boolean);
  if(nums.length===0) return '—';
  return nums.map(n=>`<a href="tel:${escapeHtml(n)}" class="emp-phone-link">${escapeHtml(n)}</a>`).join('<br>');
}
function empDisplayLabel(e){
  return `${e.name}${e.factory? ' — '+e.factory:''}${e.code? ' ('+e.code+')':''}`;
}
function filterEmpSuggestions(q){
  q = (q||'').trim().toLowerCase();
  if(!q) return employees.slice(0,8);
  return employees.filter(e=>
    e.name.toLowerCase().includes(q) || (e.code||'').toLowerCase().includes(q)
  ).slice(0,8);
}
function renderEmpSuggestions(list){
  renderEmpSuggestionsInto('empSuggest', list, selectEmpFromSuggest);
}
function renderEmpSuggestionsInto(boxId, list, onPickId){
  const box = document.getElementById(boxId);
  if(!box) return;
  if(list.length===0){
    box.innerHTML = `<div class="emp-suggest-empty">مفيش نتائج مطابقة</div>`;
    box.style.display = 'block';
    return;
  }
  box.innerHTML = list.map(e=>`
    <div class="emp-suggest-item" data-id="${e.id}">
      <span class="emp-suggest-name">${escapeHtml(e.name)}</span>
      <span class="emp-suggest-meta">${e.factory? escapeHtml(e.factory):''}${e.code? ' • '+escapeHtml(e.code):''}</span>
    </div>
  `).join('');
  box.style.display = 'block';
  box.querySelectorAll('.emp-suggest-item').forEach(item=>{
    item.addEventListener('mousedown', (ev)=>{
      ev.preventDefault();
      onPickId(item.dataset.id);
    });
  });
}
/**
 * Adds a suggestion dropdown to an existing free-text filter box (the box already has its
 * own oninput handler that filters a list). Picking a suggestion fills the box with that
 * employee's name and re-runs the same filter — no new field, just a picker on top of the
 * one that's already there.
 */
function attachSearchSuggestions(inputId, suggestId, stateSetter, refreshFn){
  const input = document.getElementById(inputId);
  const box = document.getElementById(suggestId);
  if(!input || !box) return;
  const showSug = ()=> renderEmpSuggestionsInto(suggestId, filterEmpSuggestions(input.value), (id)=>{
    const e = employees.find(x=>x.id===id);
    if(!e) return;
    input.value = e.name;
    stateSetter(e.name);
    box.style.display = 'none';
    refreshFn();
  });
  input.addEventListener('focus', showSug);
  input.addEventListener('input', showSug);
  input.addEventListener('blur', ()=>{ setTimeout(()=>{ box.style.display='none'; }, 150); });
}
/**
 * Wires up a "type name or code" employee picker: a text input (searchId) that shows a
 * live suggestion dropdown (suggestId), optionally writing the chosen id into a hidden
 * field (hiddenId), and calling onSelect(employee) once a pick is made. Same pattern used
 * everywhere an employee needs to be selected (leave form, log filter, Alexandria picks...).
 */
function initEmpAutocomplete(searchId, hiddenId, suggestId, onSelect){
  const searchInput = document.getElementById(searchId);
  const hiddenInput = hiddenId ? document.getElementById(hiddenId) : null;
  const box = document.getElementById(suggestId);
  if(!searchInput || !box) return;
  const pick = (id)=>{
    const e = employees.find(x=>x.id===id);
    if(!e) return;
    if(hiddenInput) hiddenInput.value = e.id;
    searchInput.value = empDisplayLabel(e);
    box.style.display = 'none'; box.innerHTML = '';
    if(onSelect) onSelect(e);
  };
  searchInput.addEventListener('input', ()=>{
    if(hiddenInput) hiddenInput.value = '';
    renderEmpSuggestionsInto(suggestId, filterEmpSuggestions(searchInput.value), pick);
  });
  searchInput.addEventListener('focus', ()=>{
    renderEmpSuggestionsInto(suggestId, filterEmpSuggestions(searchInput.value), pick);
  });
  searchInput.addEventListener('blur', ()=>{
    setTimeout(()=>{ box.style.display = 'none'; }, 150);
  });
  searchInput.addEventListener('keydown', (ev)=>{
    if(ev.key!=='Enter') return;
    ev.preventDefault();
    const q = searchInput.value.trim().toLowerCase();
    if(!q) return;
    const exact = employees.find(e=>(e.code||'').toLowerCase()===q);
    const list = filterEmpSuggestions(searchInput.value);
    const chosen = exact || list[0];
    if(chosen) pick(chosen.id);
  });
}
function selectEmpFromSuggest(id){
  const e = employees.find(x=>x.id===id);
  if(!e) return;
  const hidden = document.getElementById('lEmp');
  const search = document.getElementById('lEmpSearch');
  if(hidden) hidden.value = e.id;
  if(search) search.value = empDisplayLabel(e);
  const box = document.getElementById('empSuggest');
  if(box){ box.style.display = 'none'; box.innerHTML = ''; }
}
function leaveCountsFor(empId){
  const counts = {}; LEAVE_TYPES.forEach(t=>counts[t]=0);
  leaves.filter(l=>l.employeeId===empId).forEach(l=>{ counts[l.type] = (counts[l.type]||0)+1; });
  return counts;
}

// اللي بيسافر الإسكندرية بيسافر الخميس ويرجع الخميس اللي بعده — يعني الجمعة
// والسبت بعد رجوعه بيبقوا راحة زيادة عن المعتاد. عشان كده الشهر اللي سافر فيه،
// سقف الراحة بتاعه لازم يزيد يوم، وإلا هيبان وكأنه تعدى السقف وهو ماشي صح.
function getAlexTravelerIdsInMonth(yearMonth){
  const ids = new Set();
  const [y,m] = yearMonth.split('-').map(Number);
  const monthStart = new Date(y, m-1, 1);
  const monthEnd = new Date(y, m, 0);
  let cursor = getSaturdayOf(monthStart);
  cursor.setDate(cursor.getDate()-7);
  for(let i=0;i<8;i++){
    const thursday = new Date(cursor); thursday.setDate(cursor.getDate()+5);
    if(thursday>=monthStart && thursday<=monthEnd){
      const weekKey = fmtDate(cursor);
      const weekNo = weekNumberFor(cursor);
      const disp = getAlexDisplayForWeek(weekKey, weekNo);
      disp.people.forEach(p=>{ if(p.id) ids.add(p.id); });
    }
    cursor = new Date(cursor); cursor.setDate(cursor.getDate()+7);
  }
  return ids;
}
function getAlexTravelerIdsInRange(start, end){
  const ids = new Set();
  const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
  const endMonth = new Date(end.getFullYear(), end.getMonth(), 1);
  while(cursor<=endMonth){
    const key = `${cursor.getFullYear()}-${String(cursor.getMonth()+1).padStart(2,'0')}`;
    getAlexTravelerIdsInMonth(key).forEach(id=>ids.add(id));
    cursor.setMonth(cursor.getMonth()+1);
  }
  return ids;
}
function getDashCapWarnings(){
  const thisMonth = todayStr().slice(0,7);
  const [y,m] = thisMonth.split('-').map(Number);
  const monthStart = new Date(y, m-1, 1);
  const monthEnd = new Date(y, m, 0);
  const rahaCap = countFridays(monthStart, monthEnd);
  if(!rahaCap) return [];
  const alexIds = getAlexTravelerIdsInMonth(thisMonth);
  const warnings = [];
  employees.forEach(e=>{
    const cap = rahaCap + (alexIds.has(e.id) ? 1 : 0);
    const used = leaves.filter(l=>l.employeeId===e.id && l.type==='راحة' && l.date.slice(0,7)===thisMonth).length;
    if(used>cap) warnings.push({emp:e, used, cap, over: true});
  });
  return warnings.sort((a,b)=> (b.used-b.cap)-(a.used-a.cap));
}
function getFactoryLeavesThisMonth(){
  const thisMonth = todayStr().slice(0,7);
  const monthLeaves = leaves.filter(l=>l.date.slice(0,7)===thisMonth);
  return FACTORIES.map(f=>{
    const val = monthLeaves.filter(l=>{
      const e = employees.find(x=>x.id===l.employeeId);
      return e && e.factory===f;
    }).length;
    return {label:f, val, color:factoryColor(f)};
  }).sort((a,b)=>b.val-a.val);
}
function getTopLeaveTakers(limit){
  const thisMonth = todayStr().slice(0,7);
  const counts = {};
  leaves.filter(l=>l.date.slice(0,7)===thisMonth).forEach(l=>{
    counts[l.employeeId] = (counts[l.employeeId]||0)+1;
  });
  return Object.entries(counts)
    .map(([id,val])=>({emp:employees.find(e=>e.id===id), val}))
    .filter(x=>x.emp)
    .sort((a,b)=>b.val-a.val)
    .slice(0, limit||5)
    .map(x=>({label:x.emp.name, val:x.val, color:factoryColor(x.emp.factory)}));
}
function barListHTML(items, emptyMsg, labelClass){
  if(!items.length) return `<div class="mini-bars-empty">${emptyMsg||'🟢 مفيش بيانات'}</div>`;
  const max = Math.max(1, ...items.map(i=>i.val));
  return `<div class="factory-bars">
    ${items.map(i=>`
      <div class="factory-bar-row">
        <div class="factory-bar-lbl ${labelClass||''}">${escapeHtml(i.label)}</div>
        <div class="factory-bar-track"><div class="factory-bar-fill" style="width:${Math.max(6,i.val/max*100)}%;background:${i.color||'var(--brand)'};"></div></div>
        <div class="factory-bar-num">${i.val}</div>
      </div>
    `).join('')}
  </div>`;
}
// نظام الراحات عندنا: الدائم بس هو اللي راحته مدفوعة الأجر. المؤقت واللي
// تحت الاختبار برضو بياخدوا نفس عدد الراحات (عدد جمعات الشهر) — بس على
// حسابهم هما (مش مدفوعة). يعني الفرق بينهم مش "بياخد راحة ولا لأ"، الفرق
// إن راحة الدائم مدفوعة وراحتهم هما لأ. عشان كده بنعمل تحليلين منفصلين:
// واحد للدائم (راحة مدفوعة)، وواحد للمؤقت وتحت الاختبار (راحة على حسابهم)
// — الاتنين بيتحسبوا على نفس الأساس (الأسبوع الحالي، نوع "راحة" بس).
function getPermanentWithoutRestThisWeek(weekSat, weekFri){
  const restTakenIds = new Set(
    leaves.filter(l=>l.type==='راحة' && inRange(l.date, weekSat, weekFri)).map(l=>l.employeeId)
  );
  return employees.filter(e=>e.status==='دائم' && !restTakenIds.has(e.id))
    .sort((a,b)=>compareVal(a.name,b.name));
}
function getNonPermanentWithoutRestThisWeek(weekSat, weekFri){
  const restTakenIds = new Set(
    leaves.filter(l=>l.type==='راحة' && inRange(l.date, weekSat, weekFri)).map(l=>l.employeeId)
  );
  return employees.filter(e=>e.status!=='دائم' && !restTakenIds.has(e.id))
    .sort((a,b)=>compareVal(a.name,b.name));
}
// بدل عرض أسماء المؤقت وتحت الاختبار، نسبة مين اخد راحته الأسبوع ده مقارنة
// بالدائم — أنسب لعدد كبير من الأسماء.
function getRestRatioStats(weekSat, weekFri){
  const restTakenIds = new Set(
    leaves.filter(l=>l.type==='راحة' && inRange(l.date, weekSat, weekFri)).map(l=>l.employeeId)
  );
  const perm = employees.filter(e=>e.status==='دائم');
  const temp = employees.filter(e=>e.status!=='دائم');
  const permTaken = perm.filter(e=>restTakenIds.has(e.id)).length;
  const tempTaken = temp.filter(e=>restTakenIds.has(e.id)).length;
  return {
    totalTaken: permTaken+tempTaken, totalEmps: perm.length+temp.length,
    permTaken, permTotal: perm.length, permPct: perm.length? Math.round(permTaken/perm.length*100):0,
    tempTaken, tempTotal: temp.length, tempPct: temp.length? Math.round(tempTaken/temp.length*100):0,
  };
}
// قائمة أشخاص بشكل "شيبات" أنيقة بدل سطور نص عادية — تُستخدم لمسافري
// الإسكندرية واللي لسه محدش ياخد إجازة الشهر ده.
function peopleChipListHTML(people, {icon='👤', iconColor='var(--brand-soft)', emptyMsg='🟢 مفيش حد'} = {}){
  if(!people.length) return `<div class="mini-bars-empty">${emptyMsg}</div>`;
  return `<div class="people-chip-list">
    ${people.map(p=>`
      <span class="people-chip">
        <span class="chip-icon" style="--chip-clr-soft:${iconColor};">${icon}</span>
        ${escapeHtml(p.name)}${p.code? ` <span class="chip-code">(${escapeHtml(p.code)})</span>`:''}
      </span>
    `).join('')}
  </div>`;
}

/* ---------- RENDER ---------- */
function render(){
  const active = document.activeElement;
  const activeId = active && active.id;
  const selStart = (active && typeof active.selectionStart === 'number') ? active.selectionStart : null;
  const selEnd = (active && typeof active.selectionEnd === 'number') ? active.selectionEnd : null;

  document.getElementById('empCountStamp').textContent = employees.length.toLocaleString('ar-EG');
  const badgeEl = document.getElementById('dashNavBadge');
  if(badgeEl){
    const todayCount = leaves.filter(l=>l.date===todayStr()).length;
    if(todayCount>0){ badgeEl.textContent = todayCount; badgeEl.style.display = 'inline-block'; }
    else{ badgeEl.style.display = 'none'; }
  }
  const panel = document.getElementById('panel');
  if(currentTab==='dash') panel.innerHTML = renderDash();
  else if(currentTab==='reports') panel.innerHTML = renderReports();
  else if(currentTab==='roster') panel.innerHTML = renderRoster();
  else if(currentTab==='alexmsg') panel.innerHTML = renderAlexMessage();
  else if(currentTab==='meeting') panel.innerHTML = renderMeeting();
  else if(currentTab==='emp') panel.innerHTML = renderEmp();
  else if(currentTab==='leave') panel.innerHTML = renderLeaveForm();
  else if(currentTab==='rewards') panel.innerHTML = renderRewards();
  else if(currentTab==='log') panel.innerHTML = renderLog();
  attachHandlers();

  if(activeId){
    const el = document.getElementById(activeId);
    if(el && el.tagName==='INPUT'){
      el.focus();
      if(selStart!==null && el.setSelectionRange){
        try{ el.setSelectionRange(selStart, selEnd); }catch(err){}
      }
    }
  }
}

function donutChartHTML(parts, total, big){
  let cumulative = 0;
  const stops = [];
  parts.forEach(p=>{
    if(p.val<=0) return;
    const start = total>0 ? (cumulative/total*360) : 0;
    cumulative += p.val;
    const end = total>0 ? (cumulative/total*360) : 0;
    stops.push(`${p.color} ${start}deg ${end}deg`);
  });
  const gradient = stops.length ? stops.join(', ') : 'var(--line) 0deg 360deg';
  const legend = parts.map(p=>{
    const pct = total>0 ? Math.round(p.val/total*100) : 0;
    return `
    <div class="row">
      <span class="lbl"><span class="dot" style="background:${p.color};"></span>${p.label}</span>
      <span class="row-right"><b>${p.val}</b>${big?`<span class="pct">${pct}%</span>`:''}</span>
    </div>
  `;}).join('');
  return `
    <div class="donut-row${big?' big':''}">
      <div class="donut${big?' big':''}" style="background:conic-gradient(${gradient});">
        <div class="donut-hole"><span class="tot-n">${total}</span><span class="tot-l">إجمالي</span></div>
      </div>
      <div class="donut-legend${big?' big':''}">${legend}</div>
    </div>
  `;
}

function miniLeaveBarsHTML(parts){
  const max = Math.max(1, ...parts.map(p=>p.val));
  const anyLeaves = parts.some(p=>p.val>0);
  if(!anyLeaves){
    return `<div class="mini-bars-empty">🟢 مفيش إجازات الأسبوع ده</div>`;
  }
  return `<div class="mini-bars">
    ${parts.map(p=>`
      <div class="mini-bar-col">
        <span class="mini-bar-val">${p.val}</span>
        <div class="mini-bar" style="height:${p.val>0?Math.max(6,(p.val/max*100)):3}%;background:${p.val>0?p.color:'var(--line)'};"></div>
        <span class="mini-bar-lbl">${p.label}</span>
      </div>
    `).join('')}
  </div>`;
}

function renderDash(){
  const thisMonth = todayStr().slice(0,7);
  const leavesThisMonth = leaves.filter(l=>l.date.slice(0,7)===thisMonth).length;
  const byStatus = {};
  STATUSES.forEach(s=>byStatus[s]=employees.filter(e=>e.status===s).length);
  const byFactory = {};
  FACTORIES.forEach(f=>byFactory[f]=employees.filter(e=>e.factory===f).length);

  // توزيع إجازات الشهر الحالي حسب النوع + مين في إجازة النهارده
  const monthLeaves = leaves.filter(l=>l.date.slice(0,7)===thisMonth);
  const [rahaY, rahaM] = thisMonth.split('-').map(Number);
  const rahaMonthStart = new Date(rahaY, rahaM-1, 1);
  const rahaMonthEnd = new Date(rahaY, rahaM, 0);
  const rahaBaseCap = countFridays(rahaMonthStart, rahaMonthEnd);
  const rahaAlexIds = getAlexTravelerIdsInMonth(thisMonth);
  // الراحة المدفوعة (وبالتالي "المسموح بيه") بتخص الدائم بس — المؤقت وتحت
  // الاختبار بياخدوا راحتهم على حسابهم هما، فمش من المفروض يدخلوا في حساب
  // السقف ده. زيادة المسافرين للإسكندرية بتتحسب لوحدها فوق ده لأي حد سافر
  // بغض النظر عن حالته.
  const rahaPermanentIds = new Set(employees.filter(e=>e.status==='دائم').map(e=>e.id));
  const rahaExpectedTotal = rahaPermanentIds.size * rahaBaseCap + rahaAlexIds.size;
  const rahaActualTotal = monthLeaves.filter(l=>l.type==='راحة' && rahaPermanentIds.has(l.employeeId)).length;
  const rahaDiff = rahaActualTotal - rahaExpectedTotal;
  const todayDateStr = todayStr();
  const todayLeaves = leaves
    .filter(l=>l.date===todayDateStr)
    .map(l=>({...l, emp: employees.find(x=>x.id===l.employeeId)}))
    .filter(x=>x.emp);

  // نظرة الأسبوع الحالي لكل مصنع
  const today = new Date();
  const weekSat = getSaturdayOf(today);
  const weekFri = new Date(weekSat); weekFri.setDate(weekSat.getDate()+6);
  const weekNo = weekNumberFor(weekSat);
  const weekKey = weekKeyFor(today);
  const weekSnap = getWeekSnapshot(weekKey);
  const notPinnedDash = e => !PINNED_NAMES.some(p=>normalizeAr(e.name).includes(normalizeAr(p)));

  const factoryWeekCards = FACTORIES.map(f=>{
    const emps = employees.filter(e=>e.factory===f && notPinnedDash(e));
    const counts = {}; SHIFTS.forEach(s=>counts[s]=0);
    let unassignedCount = 0;
    emps.forEach(e=>{
      const s = weekSnap[e.id];
      if(s && counts[s]!==undefined) counts[s]++; else unassignedCount++;
    });
    const leaveShiftCounts = {}; SHIFTS.forEach(s=>leaveShiftCounts[s]=0);
    let leaveUnassignedCount = 0;
    const weekLeaves = leaves.filter(l=>{
      const e = employees.find(x=>x.id===l.employeeId);
      return e && e.factory===f && inRange(l.date, weekSat, weekFri);
    });
    weekLeaves.forEach(l=>{
      const e = employees.find(x=>x.id===l.employeeId);
      const s = e && weekSnap[e.id];
      if(s && leaveShiftCounts[s]!==undefined) leaveShiftCounts[s]++; else leaveUnassignedCount++;
    });
    return {f, total: emps.length, counts, unassignedCount, leavesThisWeek: weekLeaves.length, leaveShiftCounts, leaveUnassignedCount};
  });

  const factoryLeavesMonth = getFactoryLeavesThisMonth();
  const topTakers = getTopLeaveTakers(5);
  const capWarnings = getDashCapWarnings();
  const noRestYet = getPermanentWithoutRestThisWeek(weekSat, weekFri);
  const alexTravelerIds = getAlexTravelerIdsInMonth(todayStr().slice(0,7));
  const alexThisWeek = getAlexDisplayForWeek(weekKey, weekNo);
  const prevWeekSat = new Date(weekSat); prevWeekSat.setDate(prevWeekSat.getDate()-7);
  const alexPrevWeek = getAlexDisplayForWeek(fmtDate(prevWeekSat), weekNo-1);
  const noRestYetTemp = getRestRatioStats(weekSat, weekFri);

  return `
    <div class="no-print" style="display:flex;justify-content:flex-end;margin-bottom:10px;">
      <button class="btn secondary" onclick="downloadPanelImage('لوحة_الملخص.png', 'لوحة الملخص — ' + todayStr())">📷 تحميل صورة</button>
    </div>
    <div class="stats-panel">
      <div class="stats-row">
        <div class="stat-item">
          <div class="stat-icon" style="--stat-soft:var(--brand-soft);">👥</div>
          <div>
            <div class="stat-num">${employees.length}</div>
            <div class="stat-lbl">إجمالي الموظفين</div>
          </div>
        </div>
        <div class="stat-divider"></div>
        <div class="stat-item">
          <div class="stat-icon" style="--stat-soft:var(--accent-soft);">🗓️</div>
          <div>
            <div class="stat-num">${leavesThisMonth}</div>
            <div class="stat-lbl">إجازات الشهر الحالي</div>
          </div>
        </div>
        <div class="stat-divider"></div>
        <div class="stat-item">
          <div class="stat-icon" style="--stat-soft:var(--success-soft);">📋</div>
          <div>
            <div class="stat-num">${leaves.length}</div>
            <div class="stat-lbl">إجمالي سجلات الإجازات</div>
          </div>
        </div>
      </div>
      <div class="status-strip">
        <span class="status-strip-lbl">📌 الحالة الوظيفية</span>
        <div class="status-bar">
          ${employees.length? `
            <span style="width:${byStatus['دائم']/employees.length*100}%;background:var(--success);"></span>
            <span style="width:${byStatus['مؤقت']/employees.length*100}%;background:var(--accent);"></span>
            <span style="width:${byStatus['تحت الاختبار']/employees.length*100}%;background:var(--danger);"></span>
          ` : ''}
        </div>
        <div class="status-legend">
          <span class="status-legend-item"><span class="status-legend-dot" style="background:var(--success);"></span>${byStatus['دائم']} دائم</span>
          <span class="status-legend-item"><span class="status-legend-dot" style="background:var(--accent);"></span>${byStatus['مؤقت']} مؤقت</span>
          <span class="status-legend-item"><span class="status-legend-dot" style="background:var(--danger);"></span>${byStatus['تحت الاختبار']} تحت الاختبار</span>
        </div>
      </div>
    </div>

    <div class="dash-two-col">
      <div>
        <h3 class="dash-factory-title">🏭 عدد الموظفين لكل مصنع</h3>
        <div class="factory-bars">
        ${FACTORIES.slice().sort((a,b)=>byFactory[b]-byFactory[a]).map(f=>{
          const pct = employees.length? Math.round(byFactory[f]/employees.length*100) : 0;
          return `
          <div class="factory-bar-row">
            <div class="factory-bar-lbl">${f}</div>
            <div class="factory-bar-track"><div class="factory-bar-fill" style="width:${pct}%;background:${factoryColor(f)};"></div></div>
            <div class="factory-bar-num">${byFactory[f]}</div>
          </div>`;
        }).join('')}
        </div>
      </div>
      <div style="flex:1;min-width:260px;max-width:420px;">
        <h3 class="dash-factory-title">🎖️ التوزيع حسب الرتبة</h3>
        <div class="rank-chip-grid">
        ${(()=>{
          const rankParts = RANKS.map(r=>({label:r, val:employees.filter(e=>(e.rank||'مشغل')===r).length, color:rankColor(r)}));
          if(!employees.length) return `<div class="mini-bars-empty">🟢 لسه مفيش موظفين مسجّلين</div>`;
          return rankParts.map(p=>`
            <div class="rank-chip" style="border-right-color:${p.color};">
              <div class="n">${p.val}</div>
              <div class="l">${p.label}</div>
            </div>
          `).join('');
        })()}
        </div>
      </div>
    </div>

    <div class="dash-insight-box alex-week-box">
      <div class="report-chart-title">🧳 الإسكندرية</div>
      <div class="alex-split">
        <div class="alex-split-col alex-col-here">
          <div class="alex-week-sub">📍 اللي هناك دلوقتي</div>
          ${peopleChipListHTML(alexPrevWeek.people, {icon:'🧳', iconColor:'#fff', emptyMsg:'🟢 محدش هناك دلوقتي'})}
        </div>
        <div class="alex-split-divider"></div>
        <div class="alex-split-col alex-col-travel">
          <div class="alex-week-sub">🚀 مسافر آخر الأسبوع ده</div>
          ${peopleChipListHTML(alexThisWeek.people, {icon:'🚀', iconColor:'#fff', emptyMsg:'🟢 محدش هيسافر آخر الأسبوع ده'})}
        </div>
      </div>
    </div>

    <div class="dash-insights">
      <div class="dash-insight-box dash-insight-wide">
        <div class="report-chart-title">📊 حساب الراحات — الشهر الحالي</div>
        <div class="raha-scorecard">
          <div class="raha-score-top">
            <div class="raha-score-main">
              <span class="raha-score-num ${rahaDiff>0?'over':'ok'}">${rahaActualTotal}</span>
              <span class="raha-score-of">/ ${rahaExpectedTotal} يوم مسموح</span>
            </div>
            <div class="raha-score-pct ${rahaDiff>0?'over':'ok'}">${Math.round(rahaActualTotal/Math.max(1,rahaExpectedTotal)*100)}%</div>
          </div>
          <div class="raha-gauge-track">
            <div class="raha-gauge-fill ${rahaDiff>0?'over':'ok'}" style="width:${Math.min(100, Math.round(rahaActualTotal/Math.max(1,rahaExpectedTotal)*100))}%;"></div>
          </div>
          <div class="raha-score-sub">${rahaBaseCap} يوم أساسي × ${rahaPermanentIds.size} موظف دائم${rahaAlexIds.size? ` + ${rahaAlexIds.size} يوم زيادة لمسافري الإسكندرية`:''}</div>
          <div class="raha-score-status ${rahaDiff>0?'over':'ok'}">
            ${rahaDiff>0 ? `🚨 كسرنا الرقم بمقدار ${rahaDiff} يوم راحة زيادة عن المسموح` : `✅ لسه في حدود المسموح — فاضل ${-rahaDiff} يوم`}
          </div>
        </div>
      </div>
      <div class="dash-insight-box">
        <div class="report-chart-title">🟠 في إجازة النهارده (${todayLeaves.length})</div>
        ${todayLeaves.length===0 ? `<div class="mini-bars-empty">🟢 محدش في إجازة النهارده</div>` : `
          <div class="dash-today-list">
            ${todayLeaves.map(x=>`
              <div class="dash-today-row">
                <span class="type-dot type-${slug(x.type)}" title="${x.type}"></span>
                <span class="dash-today-name">${escapeHtml(x.emp.name)}${x.emp.code? ` <span class="dash-today-code">(${escapeHtml(x.emp.code)})</span>`:''}</span>
                <span class="dash-today-type">${x.type}</span>
                <span class="dash-today-shift">${shiftShortLabel(currentShiftOf(x.emp.id))}</span>
                <span class="pill factory-pill" style="background:${factoryColor(x.emp.factory)};">${x.emp.factory||'—'}</span>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    </div>

    <div class="dash-week-header">
      <h3 style="margin:0;color:var(--brand-dark);">📅 نظرة على الأسبوع الحالي — أسبوع ${weekNo} (${dateFmtShort(weekSat)} - ${dateFmtShort(weekFri)})</h3>
      <button class="btn secondary" onclick="switchTab('roster')">روح للجدول الأسبوعي</button>
    </div>
    <div class="dash-week-grid">
      ${factoryWeekCards.map(({f,total,counts,unassignedCount,leavesThisWeek,leaveShiftCounts,leaveUnassignedCount})=>{
        const shiftColors = ['var(--type1)','var(--type2)','var(--type3)'];
        const donutParts = SHIFTS.map((s,i)=>({label:`وردية ${SHIFT_SHORT[i]}`, val:counts[s], color:shiftColors[i]}));
        donutParts.push({label:'بدون وردية', val:unassignedCount, color:'var(--danger)'});
        const barParts = SHIFTS.map((s,i)=>({label:SHIFT_SHORT[i], val:leaveShiftCounts[s], color:shiftColors[i]}));
        barParts.push({label:'بدون', val:leaveUnassignedCount, color:'var(--danger)'});
        return `
        <div class="dash-week-card" style="border-top-color:${factoryColor(f)};">
          <div class="dash-week-card-head">
            <span class="dash-week-factory" style="color:${factoryColor(f)};">${f}</span>
            <span class="dash-week-total">${total} فرد</span>
          </div>
          ${donutChartHTML(donutParts, total)}
          <div class="dash-week-leaves-title">🟠 إجازات كل وردية الأسبوع ده (${leavesThisWeek})</div>
          ${miniLeaveBarsHTML(barParts)}
        </div>
      `;}).join('')}
    </div>

    <div class="dash-insights" style="margin-top:26px;">
      <div class="dash-insight-box">
        <div class="report-chart-title">📊 الإجازات حسب المصنع — الشهر الحالي (${factoryLeavesMonth.reduce((s,p)=>s+p.val,0)})</div>
        ${barListHTML(factoryLeavesMonth, '🟢 مفيش إجازات مسجّلة الشهر ده')}
      </div>
      <div class="dash-insight-box">
        <div class="report-chart-title">⏳ الدائم اللي لسه مسجّلش راحة الأسبوع ده (${noRestYet.length})</div>
        <div class="alex-week-sub">راحة مدفوعة الأجر</div>
        ${peopleChipListHTML(noRestYet, {icon:'⏳', iconColor:'var(--success-soft)', emptyMsg:'🟢 كل الدائمين سجّلوا راحتهم الأسبوع ده'})}
      </div>
      <div class="dash-insight-box">
        <div class="report-chart-title">📊 نسبة أخذ الراحات — الأسبوع ده (${noRestYetTemp.totalTaken}/${noRestYetTemp.totalEmps})</div>
        <div class="factory-bars">
          <div class="factory-bar-row">
            <div class="factory-bar-lbl">الدائم</div>
            <div class="factory-bar-track"><div class="factory-bar-fill" style="width:${Math.max(4,noRestYetTemp.permPct)}%;background:var(--success);"></div></div>
            <div class="factory-bar-num">${noRestYetTemp.permPct}%</div>
          </div>
          <div class="factory-bar-row">
            <div class="factory-bar-lbl">مؤقت واختبار</div>
            <div class="factory-bar-track"><div class="factory-bar-fill" style="width:${Math.max(4,noRestYetTemp.tempPct)}%;background:var(--accent);"></div></div>
            <div class="factory-bar-num">${noRestYetTemp.tempPct}%</div>
          </div>
        </div>
        <div class="alex-week-sub" style="margin-top:12px;">دائم: ${noRestYetTemp.permTaken}/${noRestYetTemp.permTotal} (مدفوعة) · مؤقت واختبار: ${noRestYetTemp.tempTaken}/${noRestYetTemp.tempTotal} (على حسابهم)</div>
      </div>
    </div>

    <div class="dash-insights" style="margin-top:20px;">
      <div class="dash-insight-box">
        <div class="report-chart-title">🏆 الأكتر إجازات الشهر ده</div>
        ${barListHTML(topTakers, '🟢 لسه محدش سجّل إجازة الشهر ده', 'emp-lbl')}
      </div>
      <div class="dash-insight-box">
        <div class="report-chart-title">🚨 كسر حد الراحة الشهري</div>
        ${capWarnings.length===0 ? `<div class="mini-bars-empty">🟢 محدش كسر السقف</div>` : `
          <div class="cap-warn-list">
            ${capWarnings.map(w=>`
              <div class="cap-warn-row ${w.over?'over':''}">
                <span class="cap-warn-name">${escapeHtml(w.emp.name)}${alexTravelerIds.has(w.emp.id)?' 🧳':''}</span>
                <span class="cap-warn-nums">${w.used}/${w.cap}</span>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    </div>
  `;
}

/* ---------- REPORTS ---------- */
function getPeriodRange(){
  if(reportPeriod==='custom'){
    let start = parseDate(reportCustomStart);
    let end = parseDate(reportCustomEnd);
    if(end < start){ const t=start; start=end; end=t; }
    start.setHours(0,0,0,0); end.setHours(0,0,0,0);
    const dates=[]; const cur = new Date(start);
    while(cur<=end){ dates.push(new Date(cur)); cur.setDate(cur.getDate()+1); }
    const label = `${start.getDate()}/${start.getMonth()+1}/${start.getFullYear()} → ${end.getDate()}/${end.getMonth()+1}/${end.getFullYear()}`;
    return {start,end,dates,label};
  }
  if(reportPeriod==='week'){
    const dow = reportRefDate.getDay();
    const diff = (dow - 6 + 7) % 7;
    const start = new Date(reportRefDate); start.setDate(start.getDate()-diff); start.setHours(0,0,0,0);
    const end = new Date(start); end.setDate(start.getDate()+6);
    const dates=[]; for(let i=0;i<7;i++){ const d=new Date(start); d.setDate(start.getDate()+i); dates.push(d); }
    const label = `أسبوع ${start.getDate()}/${start.getMonth()+1} → ${end.getDate()}/${end.getMonth()+1}`;
    return {start,end,dates,label};
  }
  if(reportPeriod==='year'){
    const y = reportRefDate.getFullYear();
    const start = new Date(y,0,1); const end = new Date(y,11,31);
    const dates = []; for(let m=0;m<12;m++){ dates.push(new Date(y,m,1)); }
    return {start,end,dates,label:`سنة ${y}`};
  }
  // month
  const y = reportRefDate.getFullYear(), m = reportRefDate.getMonth();
  const start = new Date(y,m,1); const end = new Date(y,m+1,0);
  const dates = []; for(let d=1; d<=end.getDate(); d++){ dates.push(new Date(y,m,d)); }
  const label = start.toLocaleDateString('ar-EG',{month:'long', year:'numeric'});
  return {start,end,dates,label};
}
function getCaps(range){
  const caps = {};
  caps['راحة'] = countFridays(range.start, range.end);
  caps['يوم شهر'] = (reportPeriod==='month') ? 1 : (reportPeriod==='year' ? 12 : null);
  caps['راحة عيد'] = null;
  return caps;
}
function shiftReportPeriod(dir){
  if(reportPeriod==='week') reportRefDate.setDate(reportRefDate.getDate()+7*dir);
  else if(reportPeriod==='month') reportRefDate.setMonth(reportRefDate.getMonth()+dir);
  else if(reportPeriod==='year') reportRefDate.setFullYear(reportRefDate.getFullYear()+dir);
  render();
}
function setReportPeriod(p){
  reportPeriod=p;
  if(p!=='custom') reportRefDate=new Date();
  render();
}
function applyCustomReportRange(){
  const s = document.getElementById('reportCustomStartInput').value;
  const e = document.getElementById('reportCustomEndInput').value;
  if(!s || !e){ showToast('لازم تحدد تاريخ البداية والنهاية'); return; }
  reportCustomStart = s;
  reportCustomEnd = e;
  render();
}
function setReportView(v){ reportView=v; render(); }

function getFilteredReportEmployees(){
  let emps = reportFactoryFilter ? employees.filter(e=>e.factory===reportFactoryFilter) : employees;
  if(reportShiftFilter) emps = emps.filter(e=>currentShiftOf(e.id)===reportShiftFilter);
  if(reportStatusFilter) emps = emps.filter(e=>e.status===reportStatusFilter);
  if(reportSearch){
    const q = reportSearch.trim().toLowerCase();
    emps = emps.filter(e=> e.name.toLowerCase().includes(q) || (e.code||'').toLowerCase().includes(q));
  }
  return emps;
}
function renderReportSummary(range, caps){
  let emps = getFilteredReportEmployees();
  if(emps.length===0){
    return `<tr class="empty-row"><td colspan="${LEAVE_TYPES.length+3}">لا يوجد موظفين مطابقين</td></tr>`;
  }
  const alexIds = getAlexTravelerIdsInRange(range.start, range.end);
  const withCounts = emps.map(e=>{
    const empLeaves = leaves.filter(l=>l.employeeId===e.id && inRange(l.date, range.start, range.end));
    const counts = {}; LEAVE_TYPES.forEach(t=>counts[t]=0);
    empLeaves.forEach(l=>counts[l.type]=(counts[l.type]||0)+1);
    const total = LEAVE_TYPES.reduce((s,t)=>s+counts[t],0);
    return {e, counts, total};
  });
  withCounts.sort((a,b)=>{
    let av,bv;
    if(reportSortState.col==='total'){ av=a.total; bv=b.total; }
    else if(reportSortState.col==='shift'){ av=currentShiftOf(a.e.id)||''; bv=currentShiftOf(b.e.id)||''; }
    else if(LEAVE_TYPES.includes(reportSortState.col)){ av=a.counts[reportSortState.col]; bv=b.counts[reportSortState.col]; }
    else { av=a.e.name; bv=b.e.name; }
    return compareVal(av,bv)*reportSortState.dir;
  });
  return withCounts.map(({e,counts,total})=>{
    const cells = LEAVE_TYPES.map(t=>{
      let cap = caps[t];
      const isAlexAdjusted = t==='راحة' && alexIds.has(e.id) && cap!==null;
      if(isAlexAdjusted) cap = cap + 1;
      if(cap===null) return `<td>${counts[t]}</td>`;
      const over = counts[t] > cap;
      return `<td ${over?'style="color:var(--danger);font-weight:700;"':''}>${counts[t]} / ${cap}${isAlexAdjusted?' 🧳':''}</td>`;
    }).join('');
    return `<tr><td><strong class="emp-name">${escapeHtml(e.name)}</strong></td><td>${currentShiftOf(e.id)||'—'}</td>${cells}<td><strong>${total}</strong></td></tr>`;
  }).join('');
}

function renderReportCalendar(range){
  let emps = getFilteredReportEmployees();
  if(emps.length===0){
    return `<div class="empty-state"><div class="big">👥</div>لا يوجد موظفين مطابقين</div>`;
  }
  if(reportPeriod==='year'){
    const header = range.dates.map(d=>`<th>${d.toLocaleDateString('ar-EG',{month:'short'})}</th>`).join('');
    const rows = emps.map(e=>{
      const cells = range.dates.map(mStart=>{
        const mEnd = new Date(mStart.getFullYear(), mStart.getMonth()+1, 0);
        const dayLeaves = leaves.filter(l=>l.employeeId===e.id && inRange(l.date, mStart, mEnd));
        if(dayLeaves.length===0) return `<td class="cal-cell" style="color:var(--ink-soft);">—</td>`;
        const parts = LEAVE_TYPES.map(t=>{
          const n = dayLeaves.filter(l=>l.type===t).length;
          return n>0 ? `<span class="type-dot type-${slug(t)}" title="${t}"></span>${n}` : '';
        }).filter(Boolean).join('&nbsp;');
        return `<td class="cal-cell" style="font-size:12px;">${parts}</td>`;
      }).join('');
      return `<tr><td><strong class="emp-name">${escapeHtml(e.name)}</strong></td>${cells}</tr>`;
    }).join('');
    return `<div style="overflow-x:auto;"><table><thead><tr><th>الاسم</th>${header}</tr></thead><tbody>${rows}</tbody></table></div>`;
  }
  // week or month: columns = days
  const header = range.dates.map(d=>{
    const isFri = d.getDay()===5;
    return `<th class="${isFri?'cal-fri':''}">${d.getDate()}<br><span style="font-weight:400;font-size:10px;">${d.toLocaleDateString('ar-EG',{weekday:'short'})}</span></th>`;
  }).join('');
  const rows = emps.map(e=>{
    const cells = range.dates.map(d=>{
      const ds = fmtDate(d);
      const isFri = d.getDay()===5;
      const dayLeaves = leaves.filter(l=>l.employeeId===e.id && l.date===ds);
      const cls = 'cal-cell' + (isFri?' cal-fri':'');
      if(dayLeaves.length===0) return `<td class="${cls}" style="color:var(--ink-soft);">—</td>`;
      const dots = dayLeaves.map(l=>`<span class="type-dot type-${slug(l.type)}" title="${l.type}"></span>`).join(' ');
      return `<td class="${cls}">${dots}</td>`;
    }).join('');
    return `<tr><td><strong class="emp-name">${escapeHtml(e.name)}</strong></td>${cells}</tr>`;
  }).join('');
  return `<div style="overflow-x:auto;"><table><thead><tr><th>الاسم</th>${header}</tr></thead><tbody>${rows}</tbody></table></div>`;
}

function renderReports(){
  const range = getPeriodRange();
  const caps = getCaps(range);
  const capsInfo = LEAVE_TYPES.map(t=>{
    const cap = caps[t];
    const periodLbl = reportPeriod==='week'?'أسبوعي':reportPeriod==='month'?'شهري':reportPeriod==='year'?'سنوي':'للفترة المحددة';
    return `<div class="card"><div class="num">${cap===null?'∞':cap}</div><div class="lbl"><span class="type-dot type-${slug(t)}"></span> سقف ${t} — ${periodLbl}</div></div>`;
  }).join('');

  const filteredEmps = getFilteredReportEmployees();
  const periodLeaves = leaves.filter(l=>{
    const e = employees.find(x=>x.id===l.employeeId);
    return e && filteredEmps.includes(e) && inRange(l.date, range.start, range.end);
  });
  const typeColors = {[LEAVE_TYPES[0]]:'var(--type1)', [LEAVE_TYPES[1]]:'var(--type2)', [LEAVE_TYPES[2]]:'var(--type3)'};
  const chartParts = LEAVE_TYPES.map(t=>({label:t, val:periodLeaves.filter(l=>l.type===t).length, color:typeColors[t]}));
  const avgPerEmp = filteredEmps.length ? (periodLeaves.length/filteredEmps.length).toFixed(1) : '0';

  const body = employees.length===0
    ? `<div class="empty-state"><div class="big">👥</div>ضيف موظفين الأول من تبويب "الموظفين" عشان تشوف التقارير</div>`
    : (reportView==='summary'
        ? `<div style="overflow-x:auto;"><table>
            <thead><tr>
              <th style="cursor:pointer;" onclick="setReportSort('name')">الاسم ${sortArrow(reportSortState,'name')}</th>
              <th style="cursor:pointer;" onclick="setReportSort('shift')">الوردية ${sortArrow(reportSortState,'shift')}</th>
              ${LEAVE_TYPES.map(t=>`<th style="cursor:pointer;" onclick="setReportSort('${t}')"><span class="type-dot type-${slug(t)}"></span> ${t} ${sortArrow(reportSortState,t)}</th>`).join('')}
              <th style="cursor:pointer;" onclick="setReportSort('total')">الإجمالي ${sortArrow(reportSortState,'total')}</th>
            </tr></thead>
            <tbody>${renderReportSummary(range, caps)}</tbody>
          </table></div>`
        : renderReportCalendar(range));

  return `
    <div class="report-controls no-print">
      <div class="seg-toggle">
        <button class="${reportPeriod==='week'?'sel':''}" onclick="setReportPeriod('week')">أسبوعي</button>
        <button class="${reportPeriod==='month'?'sel':''}" onclick="setReportPeriod('month')">شهري</button>
        <button class="${reportPeriod==='year'?'sel':''}" onclick="setReportPeriod('year')">سنوي</button>
        <button class="${reportPeriod==='custom'?'sel':''}" onclick="setReportPeriod('custom')">🗓️ فترة مخصصة</button>
      </div>
      ${reportPeriod==='custom' ? `
      <div class="period-nav" style="gap:8px;">
        <label style="font-size:12.5px;color:var(--ink-soft);">من</label>
        <input type="date" id="reportCustomStartInput" value="${reportCustomStart}" style="padding:6px 8px;">
        <label style="font-size:12.5px;color:var(--ink-soft);">إلى</label>
        <input type="date" id="reportCustomEndInput" value="${reportCustomEnd}" style="padding:6px 8px;">
        <button class="btn secondary" onclick="applyCustomReportRange()">تطبيق</button>
      </div>` : `
      <div class="period-nav">
        <button onclick="shiftReportPeriod(-1)">◀</button>
        <strong>${range.label}</strong>
        <button onclick="shiftReportPeriod(1)">▶</button>
      </div>`}
      <div class="seg-toggle">
        <button class="${reportView==='summary'?'sel':''}" onclick="setReportView('summary')">ملخص</button>
        <button class="${reportView==='calendar'?'sel':''}" onclick="setReportView('calendar')">جدول</button>
      </div>
      <button class="btn secondary" onclick="downloadPanelImage('تقرير.png', buildReportsFilterSummary())">📷 تحميل صورة</button>
    </div>
    <div class="filters no-print" style="margin-top:10px;">
      <div class="search-field" style="position:relative;"><input type="text" id="reportSearchInput" placeholder="بحث بالاسم أو الكود" value="${escapeHtml(reportSearch)}" oninput="reportSearch=this.value; render();"><div class="emp-suggest" id="reportSearchSuggest" style="display:none;"></div></div>
      <select onchange="reportFactoryFilter=this.value; render();">
        <option value="">كل المصانع</option>
        ${FACTORIES.map(f=>`<option value="${f}" ${reportFactoryFilter===f?'selected':''}>${f}</option>`).join('')}
      </select>
      <select onchange="reportShiftFilter=this.value; render();">
        <option value="">كل الورديات</option>
        ${SHIFTS.map(s=>`<option value="${s}" ${reportShiftFilter===s?'selected':''}>${s}</option>`).join('')}
      </select>
      <select onchange="reportStatusFilter=this.value; render();">
        <option value="">كل الحالات</option>
        ${STATUSES.map(s=>`<option value="${s}" ${reportStatusFilter===s?'selected':''}>${s}</option>`).join('')}
      </select>
    </div>
    <div class="report-visual">
      <div class="cards" style="margin:0;flex:1;">${capsInfo}</div>
      <div class="report-chart-box">
        <div class="report-chart-title">📊 إجمالي الإجازات حسب النوع — ${filteredEmps.length} موظف، متوسط ${avgPerEmp}/فرد</div>
        ${miniLeaveBarsHTML(chartParts)}
      </div>
    </div>
    ${body}
  `;
}

/* ---------- WEDNESDAY REMINDER ---------- */
const WED_BANNER_DISMISS_KEY = 'hr-wed-banner-dismissed';
function checkWedBanner(){
  const el = document.getElementById('wedBanner');
  if(!el) return;
  if(new Date().getDay()!==3){ el.innerHTML=''; return; }
  const today = fmtDate(new Date());
  if(localStorage.getItem(WED_BANNER_DISMISS_KEY)===today){ el.innerHTML=''; return; }
  el.innerHTML = `
    <div class="wed-banner">
      <span>📨 النهارده الأربعاء — متنساش تبعت رسالة الإسكندرية بتاعة بكرة الخميس!</span>
      <div style="display:flex;gap:8px;">
        <button class="btn" onclick="goToAlexMsgFromBanner()">روح للرسالة</button>
        <button class="icon-btn" onclick="dismissWedBanner()" title="إخفاء">✕</button>
      </div>
    </div>`;
}
function dismissWedBanner(){
  try{ localStorage.setItem(WED_BANNER_DISMISS_KEY, fmtDate(new Date())); }catch(err){}
  const el = document.getElementById('wedBanner');
  if(el) el.innerHTML='';
}
function goToAlexMsgFromBanner(){
  dismissWedBanner();
  switchTab('alexmsg');
}

/* ---------- WEEKLY ROSTER (الجدول الأسبوعي) ---------- */
const SHIFT_SHORT = ['1','2','3'];
function shiftShortLabel(shift){
  const i = SHIFTS.indexOf(shift);
  return i>-1 ? `وردية ${SHIFT_SHORT[i]}` : 'بدون وردية';
}
/* ---------- ALEXANDRIA MESSAGE (رسالة الإسكندرية) ---------- */
function alexMsgWeekRange(refDate){
  const saturday = getSaturdayOf(refDate);
  const thursday = new Date(saturday); thursday.setDate(saturday.getDate()+5);
  const prevSaturday = new Date(saturday); prevSaturday.setDate(saturday.getDate()-7);
  return { saturday, thursday, weekNo: weekNumberFor(saturday), key: fmtDate(saturday), prevKey: fmtDate(prevSaturday) };
}
function shiftAlexMsgWeek(dir){ alexMsgRefDate = new Date(alexMsgRefDate); alexMsgRefDate.setDate(alexMsgRefDate.getDate()+7*dir); render(); }
async function copyAlexMessage(){
  try{
    await navigator.clipboard.writeText(lastAlexMsgText);
    showToast('اتنسخت الرسالة ✓');
  }catch(err){
    const ta = document.createElement('textarea');
    ta.value = lastAlexMsgText;
    document.body.appendChild(ta);
    ta.select();
    try{ document.execCommand('copy'); showToast('اتنسخت الرسالة ✓'); }
    catch(e2){ showToast('تعذّر النسخ — انسخها يدويًا'); }
    document.body.removeChild(ta);
  }
}
async function downloadAlexMessageImage(){
  const el = document.getElementById('alexMsgCard');
  if(!el || typeof html2canvas==='undefined'){ showToast('تعذّر إنشاء الصورة'); return; }
  showToast('جارِ إنشاء الصورة…');
  try{
    const canvas = await html2canvas(el, {scale:2, backgroundColor:'#ffffff', windowWidth:1100, windowHeight:Math.max(el.scrollHeight+80, 800)});
    const link = document.createElement('a');
    link.download = 'رسالة_الاسكندرية.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  }catch(err){
    showToast('تعذّر إنشاء الصورة');
  }
}
async function downloadPanelImage(filename, titleText){
  const panel = document.getElementById('panel');
  if(!panel || typeof html2canvas==='undefined'){ showToast('تعذّر إنشاء الصورة'); return; }
  showToast('جارِ إنشاء الصورة…');
  const logoEl = document.querySelector('.logo-img');
  const logoSrc = logoEl ? logoEl.src : '';
  const header = document.createElement('div');
  header.className = 'capture-header';
  header.innerHTML = `
    ${logoSrc? `<img src="${logoSrc}" alt="">`:''}
    <div>
      <div class="capture-header-dept">إدارة قسم التعبئة والروبوت</div>
      <div class="capture-header-title">${escapeHtml(titleText||'')}</div>
      <div class="capture-header-date">${parseDate(todayStr()).toLocaleDateString('ar-EG')}</div>
    </div>
  `;
  panel.insertBefore(header, panel.firstChild);
  panel.classList.add('capture-mode');
  try{
    await new Promise(r=>setTimeout(r, 60));
    const canvas = await html2canvas(panel, {scale:2, backgroundColor:'#ffffff', windowWidth:1100, windowHeight:Math.max(panel.scrollHeight+80, 800)});
    const link = document.createElement('a');
    link.download = filename;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }catch(err){
    showToast('تعذّر إنشاء الصورة');
  }finally{
    panel.classList.remove('capture-mode');
    header.remove();
  }
}
function buildReportsFilterSummary(){
  const range = getPeriodRange();
  const parts = [range.label];
  if(reportSearch) parts.push(`بحث: ${reportSearch}`);
  if(reportFactoryFilter) parts.push(reportFactoryFilter);
  if(reportShiftFilter) parts.push(reportShiftFilter);
  if(reportStatusFilter) parts.push(reportStatusFilter);
  return parts.join(' • ');
}
function buildLogFilterSummary(){
  const parts = [];
  if(logSearch) parts.push(`بحث: ${logSearch}`);
  if(logTypeFilter) parts.push(logTypeFilter);
  if(logFactoryFilter) parts.push(logFactoryFilter);
  if(logShiftFilter) parts.push(logShiftFilter);
  if(logMonthFilter) parts.push(logMonthFilter);
  return parts.length ? parts.join(' • ') : 'السجل الكامل — كل السجلات';
}
async function downloadAlexOrderImage(){
  if(typeof html2canvas==='undefined'){ showToast('تعذّر إنشاء الصورة'); return; }
  showToast('جارِ إنشاء الصورة…');
  const logoEl = document.querySelector('.logo-img');
  const logoSrc = logoEl ? logoEl.src : '';
  const weekNo = lastAlexOrderWeekNo;
  const activeIdx = getAutoAlexIndicesForWeek(weekNo);
  const activePair = activeIdx.length ? Math.floor(activeIdx[0]/2) : -1;
  const totalPairs = Math.ceil(alexandriaOrder.length/2);

  let rowsHtml = '';
  for(let p=0;p<totalPairs;p++){
    const e1 = alexandriaOrder[p*2] || {name:'',code:''};
    const e2 = alexandriaOrder[p*2+1] || {name:'',code:''};
    const weekLabel = (alexStartWeek||41) + p;
    const isActive = p===activePair;
    const rowBg = isActive ? '#DFF5E6' : (p%2 ? '#FAFBFA' : '#FFFFFF');
    const numColor = isActive ? '#1B7A45' : '#5B6B67';
    rowsHtml += `
      <tr style="background:${rowBg};">
        <td style="padding:11px 8px;font-weight:800;color:${numColor};text-align:center;white-space:nowrap;border-bottom:1px solid #ECEFED;font-size:13.5px;">${isActive?'👉 ':''}أسبوع ${weekLabel}</td>
        <td style="padding:11px 14px;font-weight:800;font-size:16.5px;color:#1B3A34;border-bottom:1px solid #ECEFED;">${escapeHtml(e1.name)||'—'}</td>
        <td style="padding:11px 8px;color:#8A9A96;font-size:13px;border-bottom:1px solid #ECEFED;text-align:center;">${escapeHtml(e1.code)||'—'}</td>
        <td style="padding:11px 14px;font-weight:800;font-size:16.5px;color:#1B3A34;border-bottom:1px solid #ECEFED;">${escapeHtml(e2.name)||'—'}</td>
        <td style="padding:11px 8px;color:#8A9A96;font-size:13px;border-bottom:1px solid #ECEFED;text-align:center;">${escapeHtml(e2.code)||'—'}</td>
      </tr>`;
  }

  const node = document.createElement('div');
  node.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:880px;background:#fff;padding:30px;font-family:Tajawal,Cairo,sans-serif;direction:rtl;';
  node.innerHTML = `
    <div style="display:flex;align-items:center;gap:16px;justify-content:center;margin-bottom:4px;">
      ${logoSrc ? `<img src="${logoSrc}" style="width:74px;height:74px;object-fit:contain;">` : ''}
      <div style="text-align:center;">
        <div style="font-weight:800;font-size:25px;color:#1B3A34;">إدارة قسم التعبئة والروبوت</div>
        <div style="font-weight:800;font-size:18px;color:#2B5F5A;margin-top:3px;">🔢 ترتيب الإسكندرية</div>
      </div>
    </div>
    <div style="text-align:center;color:#8A9A96;font-size:12.5px;margin:6px 0 18px;">بداية العد من الأسبوع ${alexStartWeek||41} — الأسبوع الحالي ${weekNo}</div>
    <table style="width:100%;border-collapse:collapse;border-radius:10px;overflow:hidden;">
      <thead>
        <tr style="background:#2B5F5A;color:#fff;">
          <th style="padding:11px 8px;font-size:13.5px;">الأسبوع</th>
          <th style="padding:11px 8px;font-size:13.5px;">فني 1</th>
          <th style="padding:11px 8px;font-size:13.5px;">الكود</th>
          <th style="padding:11px 8px;font-size:13.5px;">فني 2</th>
          <th style="padding:11px 8px;font-size:13.5px;">الكود</th>
        </tr>
      </thead>
      <tbody>${rowsHtml}</tbody>
    </table>
    <div style="text-align:center;color:#B0BAB6;font-size:11px;margin-top:20px;">© ${new Date().getFullYear()} إدارة قسم التعبئة والروبوت — جميع الحقوق محفوظة</div>
  `;
  document.body.appendChild(node);
  try{
    const canvas = await html2canvas(node, {scale:2, backgroundColor:'#ffffff', windowWidth:920});
    const link = document.createElement('a');
    link.download = 'ترتيب_الاسكندرية.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  }catch(err){
    showToast('تعذّر إنشاء الصورة');
  }finally{
    document.body.removeChild(node);
  }
}
let lastAlexOrderWeekNo = 0;
function getAutoAlexIndicesForWeek(weekNo){
  const order = alexandriaOrder;
  if(!order || order.length<2) return [];
  if((weekNo||0) < (alexStartWeek||41)) return []; // الترتيب لسه ما بداش الأسبوع ده
  const perWeek = 2;
  const totalTurns = Math.ceil(order.length/perWeek);
  const n = ((weekNo||0) - (alexStartWeek||41)) % totalTurns;
  const idx = n*perWeek;
  return [idx, idx+1];
}
function renderAlexOrderTable(currentWeekNo){
  lastAlexOrderWeekNo = currentWeekNo;
  const activeIdx = getAutoAlexIndicesForWeek(currentWeekNo);
  const activePair = activeIdx.length ? Math.floor(activeIdx[0]/2) : -1;
  const totalPairs = Math.ceil(alexandriaOrder.length/2);
  const personCell = (idx, entry) => `
    <td class="alex-order-person">
      <div class="alex-order-personbox">
        <div class="alex-order-fields">
          <input type="text" class="alex-order-name" placeholder="الاسم" value="${escapeHtml(entry.name)}"
                onchange="updateAlexOrderField(${idx}, 'name', this.value)">
          <input type="text" class="alex-order-code" placeholder="الكود" value="${escapeHtml(entry.code)}"
                onchange="updateAlexOrderField(${idx}, 'code', this.value)">
        </div>
        <div class="alex-order-picker-field" style="position:relative;">
          <input type="text" class="alex-order-picker" id="alexOrderSearch${idx}" autocomplete="off" placeholder="🔍 اكتب اسم أو كود موظف">
          <div class="emp-suggest" id="alexOrderSuggest${idx}" style="display:none;"></div>
        </div>
      </div>
    </td>`;
  let rows = '';
  for(let p=0;p<totalPairs;p++){
    const e1 = alexandriaOrder[p*2] || {name:'',code:''};
    const e2 = alexandriaOrder[p*2+1] || {name:'',code:''};
    const weekLabel = (alexStartWeek||41) + p;
    rows += `
      <tr class="${p===activePair?'alex-order-active':''}">
        <td class="alex-order-num">أسبوع ${weekLabel}</td>
        ${personCell(p*2, e1)}
        ${personCell(p*2+1, e2)}
        <td class="no-print alex-order-actions">
          <button class="icon-btn" title="لأعلى" onclick="moveAlexOrderPair(${p}, -1)">▲</button>
          <button class="icon-btn" title="لأسفل" onclick="moveAlexOrderPair(${p}, 1)">▼</button>
          <button class="icon-btn" title="حذف الزوج" onclick="removeAlexOrderPair(${p})">🗑</button>
        </td>
      </tr>`;
  }
  return `
    <div class="alex-order-card no-print" id="alexOrderCard">
      <div class="alex-order-header">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
          <strong>🔢 ترتيب الإسكندرية (مرجع)</strong>
          <button class="btn secondary" onclick="downloadAlexOrderImage()">📷 تحميل صورة الجدول</button>
        </div>
        <span class="alex-order-sub">الأخضر = أسبوع النهارده، والترتيب بيلف تلقائي على مدار السنة.</span>
      </div>
      <div class="alex-order-start">
        <label>ابدأ العد من الأسبوع رقم</label>
        <input type="number" value="${alexStartWeek}" onchange="setAlexStartWeek(this.value)" style="width:70px;">
        <span class="alex-order-current-week">📅 النهارده أسبوع ${currentWeekNo}${activePair<0 ? ' — الترتيب لسه ما بداش (هيبدأ من أسبوع '+(alexStartWeek||41)+')' : ''}</span>
      </div>
      <div style="overflow-x:auto;">
        <table class="roster-table alex-order-table">
          <thead><tr><th>الأسبوع</th><th colspan="1">فني 1</th><th colspan="1">فني 2</th><th class="no-print"></th></tr></thead>
          <tbody>${rows || `<tr><td colspan="4" style="color:var(--ink-soft);">لسه مفيش أسماء في الترتيب</td></tr>`}</tbody>
        </table>
      </div>
      <button class="btn secondary" onclick="addAlexOrderPair()">+ إضافة زوج</button>
    </div>
  `;
}
function renderAlexMessage(){
  const range = alexMsgWeekRange(alexMsgRefDate);
  const dateFmt = d => `${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}`;
  const thursdayStr = dateFmt(range.thursday);

  const dep = getAlexDisplayForWeek(range.key, range.weekNo);
  const ret = getAlexDisplayForWeek(range.prevKey, range.weekNo-1);
  const departing = dep.people;
  const returning = ret.people;
  const formatNames = list => list.map(e => `${e.name}${e.code? ' كود '+e.code : ''}`).join(' و');

  let message = 'السلام عليكم ورحمة الله وبركاته\n\n';
  message += departing.length>0
    ? `ذهاب كلاً من: ${formatNames(departing)} للإسكندرية الخميس بتاريخ ${thursdayStr}\n\n`
    : `ذهاب: مفيش حد متحدد للإسكندرية الأسبوع ده\n\n`;
  message += returning.length>0
    ? `ونزول كلاً من: ${formatNames(returning)} بتاريخ ${thursdayStr}`
    : `نزول: مفيش حد عائد الأسبوع ده`;

  lastAlexMsgText = message;

  const peopleChips = (list, emptyLabel, colorVar) => list.length>0
    ? `<div class="alexmsg-people">${list.map((e,i)=>`
        <div class="alexmsg-person">
          <span class="num" style="background:${colorVar};">${i+1}</span>
          <span class="name">${escapeHtml(e.name)}</span>
          ${e.code? `<span class="code">كود ${escapeHtml(e.code)}</span>` : ''}
        </div>`).join('')}</div>`
    : `<div class="alexmsg-people"><div class="alexmsg-empty">${emptyLabel}</div></div>`;

  return `
    <div class="report-controls no-print">
      <div class="period-nav">
        <button onclick="shiftAlexMsgWeek(-1)">◀</button>
        <strong>الأسبوع ${range.weekNo} — الخميس ${thursdayStr}</strong>
        <button onclick="shiftAlexMsgWeek(1)">▶</button>
      </div>
      <button class="btn secondary" onclick="copyAlexMessage()">📋 نسخ كنص</button>
      <button class="export-btn" onclick="downloadAlexMessageImage()">📷 تحميل كصورة</button>
    </div>

    <div class="alexmsg-layout">
      <div id="alexMsgCard" class="alexmsg-card">
        <div class="alexmsg-card-header">
          <img src="${document.querySelector('.logo-img') ? document.querySelector('.logo-img').src : ''}" class="roster-logo" alt="">
          <div>
            <div class="roster-dept">إدارة قسم التعبئة والروبوت</div>
            <div class="alexmsg-card-title">🧳 رسالة الإسكندرية</div>
            <div class="roster-week-dates">الأسبوع ${range.weekNo} — الخميس ${thursdayStr}</div>
          </div>
        </div>
        <div class="alexmsg-greeting">السلام عليكم ورحمة الله وبركاته</div>
        <div class="alexmsg-section">
          <div class="alexmsg-section-title dep">🧳 ذهاب — الخميس ${thursdayStr}</div>
          ${peopleChips(departing, 'مفيش حد متحدد', 'var(--brand)')}
        </div>
        <div class="alexmsg-section">
          <div class="alexmsg-section-title ret">↩️ نزول — الخميس ${thursdayStr}</div>
          ${peopleChips(returning, 'مفيش حد عائد', 'var(--accent)')}
        </div>
      </div>

      ${renderAlexOrderTable(range.weekNo)}
    </div>

    <p style="font-size:12.5px;color:var(--ink-soft);margin-top:12px;" class="no-print">
      الرسالة دي بتتبني تلقائيًا من ترتيب الإسكندرية (جدول المرجع جنبها) — ولو محتاج تغيّر أي أسبوع بعينه يدويًا تقدر من تبويب "📅 الجدول الأسبوعي".
      "نسخ كنص" لو هتبعتها كتابة، أو "تحميل كصورة" لو هتبعتها صورة جاهزة.
    </p>
  `;
}

function rosterWeekRange(){
  const saturday = getSaturdayOf(rosterRefDate);
  const thursday = new Date(saturday); thursday.setDate(saturday.getDate()+5);
  const friday = new Date(saturday); friday.setDate(saturday.getDate()+6);
  return { saturday, thursday, friday, weekNo: weekNumberFor(saturday), key: fmtDate(saturday) };
}
function setRosterGroup(g){ rosterGroup=g; render(); }
function shiftRosterWeek(dir){ rosterRefDate = new Date(rosterRefDate); rosterRefDate.setDate(rosterRefDate.getDate()+7*dir); render(); }
function toggleRosterFriday(){ rosterShowFriday = !rosterShowFriday; render(); }
async function setEmployeeFridayShift(id, shift){
  const e = employees.find(x=>x.id===id);
  if(!e) return;

  const weekKey = rosterWeekRange().key;
  const snap = materializeWeek(weekKey);

  // جدول الجمعة خاص بالأسبوع الحالي فقط.
  if(!snap.__friday || typeof snap.__friday !== 'object'){
    snap.__friday = {};
  }

  if(shift){
    snap.__friday[id] = {
      shift: shift,
      order: Date.now()
    };
  }else{
    delete snap.__friday[id];
  }

  await saveWeeklyRoster(weekKey);
  render();
}
const ROTATE_TO = { [SHIFTS[0]]: SHIFTS[2], [SHIFTS[1]]: SHIFTS[0], [SHIFTS[2]]: SHIFTS[1] };
let lastRotationSnapshot = null; // {weekKey, group, before:{empId:shift}}
async function rotateGroupShifts(){
  const weekKey = rosterWeekRange().key;
  if(!confirm(`تدوير ورديات "${rosterGroup}" لأسبوع ${rosterWeekRange().weekNo} بس (الأولى→الثالثة، الثانية→الأولى، الثالثة→الثانية)؟`)) return;
  const snap = materializeWeek(weekKey);
  lastRotationSnapshot = { weekKey, group: rosterGroup, before: Object.assign({}, snap) };
  const affected = employees.filter(e=>e.factory===rosterGroup && !PINNED_NAMES.some(p=>normalizeAr(e.name).includes(normalizeAr(p))));
  affected.forEach(e=>{
    const cur = snap[e.id];
    if(cur && ROTATE_TO[cur]) snap[e.id] = ROTATE_TO[cur];
  });
  await saveWeeklyRoster(weekKey);
  showToast(`تم تدوير ورديات أسبوع ${rosterWeekRange().weekNo} فقط`);
  render();
}
async function undoRotation(){
  if(!lastRotationSnapshot) return;
  weeklyRoster[lastRotationSnapshot.weekKey] = lastRotationSnapshot.before;
  const undoneWeekKey = lastRotationSnapshot.weekKey;
  lastRotationSnapshot = null;
  await saveWeeklyRoster(undoneWeekKey);
  showToast('تم التراجع عن التدوير');
  render();
}
async function setEmployeeShift(id, shift){
  const weekKey = rosterWeekRange().key;
  const snap = materializeWeek(weekKey);
  if(shift) snap[id] = shift; else delete snap[id];
  await saveWeeklyRoster(weekKey);
  render();
}
async function setAlexPick(slot, empId){
  const key = rosterWeekRange().key;
  const cur = alexandriaWeekly[key] ? alexandriaWeekly[key].slice() : ['',''];
  cur[slot] = empId;
  alexandriaWeekly[key] = cur;
  await saveAlexWeekly();
  render();
}
async function clearAlexAutoOverride(){
  // يمسح الاختيار اليدوي للأسبوع الحالي ويرجّعه للترتيب التلقائي
  const key = rosterWeekRange().key;
  delete alexandriaWeekly[key];
  await saveAlexWeekly();
  render();
}
function getAutoAlexEntriesForWeek(weekNo){
  const order = alexandriaOrder;
  if(!order || order.length<2) return [null, null];
  if((weekNo||0) < (alexStartWeek||41)) return [null, null]; // الترتيب لسه ما بداش الأسبوع ده
  const perWeek = 2;
  const totalTurns = Math.ceil(order.length/perWeek);
  const n = ((weekNo||0) - (alexStartWeek||41)) % totalTurns;
  const idx = n*perWeek;
  return [order[idx]||null, order[idx+1]||null];
}
function resolveAlexEntryToEmployeeId(entry){
  if(!entry) return '';
  let match = null;
  if(entry.code) match = employees.find(e=>e.code && e.code===entry.code);
  if(!match && entry.name) match = employees.find(e=>normalizeAr(e.name)===normalizeAr(entry.name));
  return match ? match.id : '';
}
function getAlexDisplayForWeek(weekKey, weekNo){
  const saved = (alexandriaWeekly[weekKey]||[]).filter(Boolean);
  if(saved.length>0){
    return { auto:false, people: saved.map(id=>employees.find(e=>e.id===id)).filter(Boolean).map(e=>({name:e.name, code:e.code||'', id:e.id})) };
  }
  const auto = getAutoAlexEntriesForWeek(weekNo).filter(Boolean);
  return { auto:true, people: auto.map(entry=>({name:entry.name, code:entry.code||'', id: resolveAlexEntryToEmployeeId(entry)||null})) };
}
function updateAlexOrderField(idx, field, value){
  if(!alexandriaOrder[idx]) return;
  alexandriaOrder[idx][field] = value;
  saveAlexOrder();
}
function addAlexOrderPair(){
  alexandriaOrder.push({name:'', code:''}, {name:'', code:''});
  saveAlexOrder();
  render();
}
function removeAlexOrderPair(pairIdx){
  if(!confirm('تأكيد حذف الزوج ده من ترتيب الإسكندرية؟')) return;
  alexandriaOrder.splice(pairIdx*2, 2);
  saveAlexOrder();
  render();
}
function moveAlexOrderPair(pairIdx, dir){
  const targetPair = pairIdx+dir;
  const totalPairs = Math.ceil(alexandriaOrder.length/2);
  if(targetPair<0 || targetPair>=totalPairs) return;
  const a = alexandriaOrder.slice(pairIdx*2, pairIdx*2+2);
  const b = alexandriaOrder.slice(targetPair*2, targetPair*2+2);
  while(a.length<2) a.push({name:'',code:''});
  while(b.length<2) b.push({name:'',code:''});
  for(let i=0;i<2;i++){ alexandriaOrder[targetPair*2+i]=a[i]; alexandriaOrder[pairIdx*2+i]=b[i]; }
  saveAlexOrder();
  render();
}
function setAlexOrderPerson(idx, employeeId){
  if(!employeeId) return;
  const emp = employees.find(e=>e.id===employeeId);
  if(!emp) return;
  if(!alexandriaOrder[idx]) alexandriaOrder[idx] = {name:'', code:''};
  alexandriaOrder[idx].name = emp.name;
  alexandriaOrder[idx].code = emp.code || '';
  saveAlexOrder();
  render();
}
function setAlexStartWeek(value){
  const n = parseInt(value,10);
  if(!isNaN(n)) alexStartWeek = n;
  saveAlexOrder();
  render();
}
function rankStyle(rank){
  if(rank==='كبير مشرفين') return 'color:var(--danger);font-weight:800;text-decoration:underline;';
  if(rank==='مهندس') return 'color:var(--type3);font-weight:800;';
  if(rank==='مشرف') return 'color:var(--danger);font-weight:800;';
  if(rank==='مساعد مشرف') return 'color:var(--brand);font-weight:700;';
  return 'color:var(--ink);font-weight:500;';
}
function rosterEmployeeRow(e, alexIds, shiftVal){
  const isAlex = alexIds && alexIds.includes(e.id);
  return `
    <div class="roster-emp-row">
      <span style="${rankStyle(e.rank)}">${escapeHtml(e.name)}</span>
      ${isAlex? `<span class="alex-badge" title="مسافر الإسكندرية الأسبوع ده">— إسكندرية</span>` : ''}
      <select class="roster-shift-select no-print" onchange="setEmployeeShift('${e.id}', this.value)">
        <option value="" ${!shiftVal?'selected':''}>—</option>
        ${SHIFTS.map((s,i)=>`<option value="${s}" ${shiftVal===s?'selected':''}>${SHIFT_SHORT[i]}</option>`).join('')}
      </select>
    </div>`;
}
function fridayEmployeeRow(e, fridayData){
  const info = fridayData && fridayData[e.id] ? fridayData[e.id] : null;
  const shiftVal = info ? info.shift : '';

  return `
    <div class="roster-emp-row">
      <span style="${rankStyle(e.rank)}">${escapeHtml(e.name)}</span>
      <select class="roster-shift-select no-print" onchange="setEmployeeFridayShift('${e.id}', this.value)">
        <option value="" ${!shiftVal?'selected':''}>—</option>
        <option value="${SHIFTS[0]}" ${shiftVal===SHIFTS[0]?'selected':''}>1</option>
        <option value="${SHIFTS[1]}" ${shiftVal===SHIFTS[1]?'selected':''}>2</option>
      </select>
    </div>`;
}
function printRoster(){
  window.print();
}
async function downloadRosterImage(){
  if(typeof html2canvas==='undefined'){ showToast('تعذّر إنشاء الصورة'); return; }
  showToast('جارِ إنشاء الصورة…');
  const range = rosterWeekRange();
  const dateFmt = d => `${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}`;
  const notPinned = e => !PINNED_NAMES.some(p => normalizeAr(e.name).includes(normalizeAr(p)));
  const mainEmps = employees.filter(e=>e.factory===rosterGroup && notPinned(e));
  const headName = ROSTER_HEADS[rosterGroup] || '';
  const alexSaved = alexandriaWeekly[range.key];
  const alexPicks = (alexSaved && alexSaved.some(Boolean)) ? alexSaved : getAutoAlexEntriesForWeek(range.weekNo).map(resolveAlexEntryToEmployeeId);
  const alexIds = alexPicks.filter(Boolean);
  const isMainFactory = rosterGroup === 'الرئيسي';
  const weekSnap = getWeekSnapshot(range.key);

  const columns = SHIFTS.map(shift=>{
    const inShift = mainEmps.filter(e=>weekSnap[e.id]===shift)
      .sort((a,b)=>{
        const ra = RANKS.indexOf(a.rank||'مشغل'), rb = RANKS.indexOf(b.rank||'مشغل');
        if(ra!==rb) return ra-rb;
        return compareVal(a.name,b.name);
      });
    return {shift, list: inShift};
  });
  const bodyRowCount = Math.max(1, ...columns.map(c=>c.list.length));

  let fridayColumns = null, fridayRowCount = 0;
  if(isMainFactory && rosterShowFriday){
    const fridayData = getFridaySnapshot(range.key);
    fridayColumns = [SHIFTS[0], SHIFTS[1]].map(shift=>{
      const inShift = mainEmps.filter(e=> fridayData[e.id] && fridayData[e.id].shift===shift)
        .sort((a,b)=>{
          const ra = RANKS.indexOf(a.rank||'مشغل'), rb = RANKS.indexOf(b.rank||'مشغل');
          if(ra!==rb) return ra-rb;
          const oa=fridayData[a.id]?(fridayData[a.id].order||0):0, ob=fridayData[b.id]?(fridayData[b.id].order||0):0;
          return oa-ob;
        });
      return {shift, list: inShift};
    });
    fridayRowCount = Math.max(1, ...fridayColumns.map(c=>c.list.length));
  }

  const logoEl = document.querySelector('.logo-img');
  const logoSrc = logoEl ? logoEl.src : '';
  const nameCell = (e) => e ? `${escapeHtml(e.name)}${alexIds.includes(e.id)?' 🧳':''}` : '&nbsp;';
  // أول صفين بس بيتلوّنوا (زي النموذج) — باقي الصفوف بيضاء عادية.
  const ROW_HILITE = ['#FBE7E7', '#E4EDF8'];
  const buildRows = (cols, rowCount, hilite) => {
    let html = '';
    for(let i=0;i<rowCount;i++){
      const rowBg = hilite && ROW_HILITE[i] ? ROW_HILITE[i] : (i%2? '#FAFBFA':'#fff');
      html += `<tr style="background:${rowBg};">` + cols.map((c,colIdx)=>{
        const e = c.list[i];
        return `<td style="padding:11px 16px;border-bottom:1px solid #ECEFED;">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
            <span style="font-weight:${e?800:400};font-size:16px;color:#1B3A34;flex:1;text-align:center;">${nameCell(e)}</span>
            ${e? `<span style="flex:none;min-width:22px;height:22px;padding:0 5px;border:1.5px solid #C7D2CE;border-radius:6px;background:#fff;color:#1B3A34;font-weight:800;font-size:13px;display:flex;align-items:center;justify-content:center;">${colIdx+1}</span>` : '<span style="flex:none;width:22px;"></span>'}
          </div>
        </td>`;
      }).join('') + '</tr>';
    }
    return html;
  };

  const node = document.createElement('div');
  node.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:1000px;background:#fff;padding:36px 32px;font-family:Tajawal,Cairo,sans-serif;direction:rtl;';
  node.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:12px;">
      ${logoSrc? `<img src="${logoSrc}" style="width:38px;height:38px;object-fit:contain;">`:''}
      <div style="font-weight:700;font-size:13px;color:#1B3A34;">قسم التعبئة والروبوت</div>
    </div>
    <div style="text-align:center;font-weight:800;font-size:28px;color:#1B3A34;margin-bottom:8px;">الجدول الاسبوعي (${range.weekNo})</div>
    <div style="text-align:center;font-weight:700;font-size:15px;color:#2B5F5A;margin-bottom:18px;">من السبت ${dateFmt(range.saturday)} إلى الجمعة ${dateFmt(range.friday)}</div>
    ${headName? `<div style="text-align:center;font-weight:800;font-size:22px;color:#1B3A34;background:#EFF2F1;border-radius:8px;padding:14px;margin-bottom:20px;">${escapeHtml(headName)}</div>` : ''}
    <table style="width:100%;border-collapse:collapse;border-radius:10px;overflow:hidden;margin-bottom:${fridayColumns?'30':'6'}px;">
      <thead><tr style="background:#1B3A34;color:#fff;">
        ${columns.map(c=>`<th style="padding:15px 10px;font-size:17px;font-weight:800;text-align:center;vertical-align:middle;color:#ffffff;">${c.shift}</th>`).join('')}
      </tr></thead>
      <tbody>${buildRows(columns, bodyRowCount, true)}</tbody>
    </table>
    ${fridayColumns? `
      <div style="text-align:center;font-weight:800;font-size:19px;color:#1B3A34;margin-bottom:12px;">جدول غدًا الجمعة ${dateFmt(range.friday)}</div>
      <table style="width:100%;border-collapse:collapse;border-radius:10px;overflow:hidden;">
        <thead><tr style="background:#1B3A34;color:#fff;">
          ${fridayColumns.map(c=>`<th style="padding:15px 10px;font-size:17px;font-weight:800;text-align:center;vertical-align:middle;color:#ffffff;">${c.shift}</th>`).join('')}
        </tr></thead>
        <tbody>${buildRows(fridayColumns, fridayRowCount, false)}</tbody>
      </table>
    ` : ''}
    <div style="text-align:center;color:#B0BAB6;font-size:11px;margin-top:24px;">© ${new Date().getFullYear()} إدارة قسم التعبئة والروبوت — جميع الحقوق محفوظة</div>
  `;
  document.body.appendChild(node);
  try{
    const canvas = await html2canvas(node, {scale:2, backgroundColor:'#ffffff', windowWidth:1064});
    const link = document.createElement('a');
    link.download = `الجدول_الاسبوعي_${rosterGroup}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }catch(err){
    showToast('تعذّر إنشاء الصورة');
  }finally{
    document.body.removeChild(node);
  }
}
function renderRoster(){
  const range = rosterWeekRange();
  const dateFmt = d => `${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}`;
  const notPinned = e => !PINNED_NAMES.some(p => normalizeAr(e.name).includes(normalizeAr(p)));
  const mainEmps = employees.filter(e=>e.factory===rosterGroup && notPinned(e));
  const headName = ROSTER_HEADS[rosterGroup] || '';
  const alexSaved = alexandriaWeekly[range.key];
  let alexPicks, alexAuto;
  if(alexSaved && alexSaved.some(Boolean)){
    alexPicks = alexSaved;
    alexAuto = false;
  }else{
    alexPicks = getAutoAlexEntriesForWeek(range.weekNo).map(resolveAlexEntryToEmployeeId);
    alexAuto = true;
  }
  const alexIds = alexPicks.filter(Boolean);
  const isMainFactory = rosterGroup === 'الرئيسي';
  const allNonPinned = employees.filter(notPinned).sort((a,b)=>compareVal(a.name,b.name));

  const weekSnap = getWeekSnapshot(range.key);
  const unassigned = mainEmps.filter(e=>!weekSnap[e.id])
    .sort((a,b)=>{
      const ra = RANKS.indexOf(a.rank||'مشغل'), rb = RANKS.indexOf(b.rank||'مشغل');
      if(ra!==rb) return ra-rb;
      return compareVal(a.name,b.name);
    });

  const columns = SHIFTS.map(shift=>{
    const inShift = mainEmps.filter(e=>weekSnap[e.id]===shift)
      .sort((a,b)=>{
        const ra = RANKS.indexOf(a.rank||'مشغل'), rb = RANKS.indexOf(b.rank||'مشغل');
        if(ra!==rb) return ra-rb;
        return compareVal(a.name,b.name);
      });
    return {shift, list: inShift};
  });

  const bodyRowCount = Math.max(1, ...columns.map(c=>c.list.length));
  let bodyRows = '';
  for(let i=0;i<bodyRowCount;i++){
    const rowClass = i===0 ? 'roster-row-sup' : (i===1 ? 'roster-row-asst' : 'roster-row-op');
    bodyRows += `<tr class="${rowClass}">` + columns.map(c=>{
      const e = c.list[i];
      return `<td>${e ? rosterEmployeeRow(e, alexIds, weekSnap[e.id]) : ''}</td>`;
    }).join('') + '</tr>';
  }
  if(mainEmps.length===0){
    bodyRows = `<tr><td colspan="3" style="text-align:center;color:var(--ink-soft);padding:24px;">مفيش موظفين في ${rosterGroup} — ضيفهم من تبويب "الموظفين" الأول</td></tr>`;
  }

  // جدول الجمعة مستقل تمامًا لكل أسبوع.
  // لا نقرأ e.fridayShift من بيانات الموظف لأنها بيانات عامة وليست أسبوعية.
  const fridayData = getFridaySnapshot(range.key);

  const fridayColumns = [SHIFTS[0], SHIFTS[1]].map(shift=>{
    const inShift = mainEmps.filter(e=>{
      return fridayData[e.id] && fridayData[e.id].shift === shift;
    })
      .sort((a,b)=>{
        const ra = RANKS.indexOf(a.rank||'مشغل'), rb = RANKS.indexOf(b.rank||'مشغل');
        if(ra!==rb) return ra-rb;
        const oa = fridayData[a.id] ? (fridayData[a.id].order || 0) : 0;
        const ob = fridayData[b.id] ? (fridayData[b.id].order || 0) : 0;
        return oa-ob;
      });
    return {shift, list: inShift};
  });

  const fridayRowCount = Math.max(1, ...fridayColumns.map(c=>c.list.length));
  let fridayRows = '';
  for(let i=0;i<fridayRowCount;i++){
    fridayRows += '<tr>' + fridayColumns.map(c=>{
      const e = c.list[i];
      return `<td>${e ? fridayEmployeeRow(e, fridayData) : ''}</td>`;
    }).join('') + '</tr>';
  }

  const fridayUnassigned = mainEmps.filter(e=>!fridayData[e.id])
    .sort((a,b)=>{
      const ra = RANKS.indexOf(a.rank||'مشغل'), rb = RANKS.indexOf(b.rank||'مشغل');
      if(ra!==rb) return ra-rb;
      return compareVal(a.name,b.name);
    });

  return `
    <div class="report-controls no-print">
      <div class="seg-toggle">
        ${ROSTER_GROUPS.map(g=>`<button class="${rosterGroup===g?'sel':''}" onclick="setRosterGroup('${g}')">${g}</button>`).join('')}
      </div>
      <div class="period-nav">
        <button onclick="shiftRosterWeek(-1)">◀</button>
        <strong>الأسبوع ${range.weekNo} — من ${dateFmt(range.saturday)} إلى ${dateFmt(range.friday)}</strong>
        <button onclick="shiftRosterWeek(1)">▶</button>
      </div>
      <button class="btn secondary" onclick="rotateGroupShifts()" title="الأولى→الثالثة، الثانية→الأولى، الثالثة→الثانية">🔁 تدوير الورديات</button>
      ${(lastRotationSnapshot && lastRotationSnapshot.group===rosterGroup && lastRotationSnapshot.weekKey===range.key) ? `<button class="btn secondary" onclick="undoRotation()">↩️ تراجع عن التدوير</button>` : ''}
      ${isMainFactory ? `<button class="btn secondary" onclick="toggleRosterFriday()">${rosterShowFriday?'إخفاء جدول الجمعة':'عرض جدول الجمعة'}</button>` : ''}
      <button class="btn secondary" onclick="downloadRosterImage()">📷 تحميل كصورة</button>
      <button class="export-btn" onclick="printRoster()">🖨 طباعة</button>
    </div>

    <div class="roster-alex-picker no-print">
      <strong>🧳 الإسكندرية — الأسبوع ده (اختار اتنين من أي مصنع):</strong>
      ${alexAuto
        ? `<span class="alex-auto-note">🔄 اتملت تلقائيًا من ترتيب الإسكندرية (الأسبوع ${range.weekNo})</span>`
        : `<span class="alex-auto-note manual">✋ اتغيّرت يدوي — <button class="link-btn" onclick="clearAlexAutoOverride()">رجّعها للترتيب التلقائي</button></span>`
      }
      <div class="roster-alex-selects">
        <select onchange="setAlexPick(0, this.value)">
          <option value="">— اختر الأول —</option>
          ${allNonPinned.map(e=>`<option value="${e.id}" ${alexPicks[0]===e.id?'selected':''}>${escapeHtml(e.name)} (${e.factory||''})</option>`).join('')}
        </select>
        <select onchange="setAlexPick(1, this.value)">
          <option value="">— اختر الثاني —</option>
          ${allNonPinned.map(e=>`<option value="${e.id}" ${alexPicks[1]===e.id?'selected':''}>${escapeHtml(e.name)} (${e.factory||''})</option>`).join('')}
        </select>
      </div>
    </div>

    ${unassigned.length>0 ? `
      <div class="roster-unassigned no-print">
        <strong>موظفين لسه متوزعوش على وردية (${unassigned.length}) — اختار لكل واحد ورديته:</strong>
        <div class="roster-unassigned-list">
          ${unassigned.map(e=>rosterEmployeeRow(e, alexIds, weekSnap[e.id])).join('')}
        </div>
      </div>
    ` : ''}

    ${(isMainFactory && rosterShowFriday && fridayUnassigned.length>0) ? `
      <div class="roster-unassigned no-print">
        <strong>موظفين لسه ملهمش وردية جمعة (${fridayUnassigned.length}) — اختار لكل واحد الأولى أو الثانية:</strong>
        <div class="roster-unassigned-list">
          ${fridayUnassigned.map(e=>fridayEmployeeRow(e, fridayData)).join('')}
        </div>
      </div>
    ` : ''}

    <div id="rosterPrintArea" class="print-area">
      <div class="roster-print-header">
        <img src="${document.querySelector('.logo-img') ? document.querySelector('.logo-img').src : ''}" class="roster-logo" alt="">
        <div>
          <div class="roster-dept">إدارة قسم التعبئة والروبوت</div>
          <div class="roster-week-title">الجدول الاسبوعي (${range.weekNo})</div>
          <div class="roster-week-dates">اعتبارًا من يوم السبت ${dateFmt(range.saturday)} إلى ${dateFmt(range.friday)}</div>
        </div>
      </div>

      ${headName ? `<div class="roster-head-name">${headName}</div>` : ''}

      <table class="roster-table">
        <thead><tr>${SHIFTS.map(s=>`<th>${s}</th>`).join('')}</tr></thead>
        <tbody>${bodyRows}</tbody>
      </table>

      ${(isMainFactory && rosterShowFriday) ? `
        <h3 class="roster-friday-title">جدول الجمعة ${dateFmt(range.friday)}</h3>
        <table class="roster-table">
          <thead><tr><th>${SHIFTS[0]}</th><th>${SHIFTS[1]}</th></tr></thead>
          <tbody>${fridayRows}</tbody>
        </table>
      ` : ''}
    </div>

    <p style="font-size:12.5px;color:var(--ink-soft);margin-top:14px;" class="no-print">
      اختار الرقم جنب أي اسم عشان تنقله بين الورديات، أو دوس "🔁 تدوير الورديات" لما تعمل أسبوع جديد.
    </p>
  `;
}

/* ---------- MEETING SCHEDULE (جدول الاجتماع) — fully manual, separate from roster ---------- */
async function addMeetingGroup(){
  meetingGroups.push({ id:'mg'+uid(), title:'اجتماع جديد', rows:[{name:'',code:''}] });
  await saveMeetings();
  render();
}
async function removeMeetingGroup(id){
  if(!confirm('تأكيد حذف هذا الاجتماع بالكامل؟')) return;
  meetingGroups = meetingGroups.filter(g=>g.id!==id);
  await saveMeetings();
  render();
}
async function renameMeetingGroup(id, title){
  const g = meetingGroups.find(x=>x.id===id);
  if(g){ g.title = title; await saveMeetings(); }
}
async function addMeetingRow(groupId){
  const g = meetingGroups.find(x=>x.id===groupId);
  if(g){ g.rows.push({name:'',code:''}); await saveMeetings(); render(); }
}
async function removeMeetingRow(groupId, idx){
  const g = meetingGroups.find(x=>x.id===groupId);
  if(g){ g.rows.splice(idx,1); if(g.rows.length===0) g.rows.push({name:'',code:''}); await saveMeetings(); render(); }
}
async function updateMeetingCell(groupId, idx, field, value){
  const g = meetingGroups.find(x=>x.id===groupId);
  if(g && g.rows[idx]){ g.rows[idx][field] = value; await saveMeetings(); }
}
function attachMeetingRowAutocomplete(groupId, idx){
  const nameInput = document.getElementById(`meetingName_${groupId}_${idx}`);
  const codeInput = document.getElementById(`meetingCode_${groupId}_${idx}`);
  const box = document.getElementById(`meetingSuggest_${groupId}_${idx}`);
  if(!box) return;
  const pick = (id)=>{
    const e = employees.find(x=>x.id===id);
    if(!e) return;
    updateMeetingCell(groupId, idx, 'name', e.name);
    updateMeetingCell(groupId, idx, 'code', e.code||'');
    box.style.display = 'none';
    render();
  };
  const showFrom = (input)=>{
    if(!input) return;
    renderEmpSuggestionsInto(box.id, filterEmpSuggestions(input.value), pick);
  };
  [nameInput, codeInput].forEach(input=>{
    if(!input) return;
    input.addEventListener('focus', ()=>showFrom(input));
    input.addEventListener('input', ()=>showFrom(input));
    input.addEventListener('blur', ()=>{ setTimeout(()=>{ box.style.display='none'; }, 150); });
  });
}
function printMeeting(){
  window.print();
}
async function downloadMeetingImage(){
  const el = document.getElementById('meetingPrintArea');
  if(!el || typeof html2canvas==='undefined'){ showToast('تعذّر إنشاء الصورة'); return; }
  showToast('جارِ إنشاء الصورة…');
  try{
    const canvas = await html2canvas(el, {scale:2, backgroundColor:'#ffffff', windowWidth:1100, windowHeight:Math.max(el.scrollHeight+80, 800)});
    const link = document.createElement('a');
    link.download = 'جدول_الاجتماع.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  }catch(err){
    showToast('تعذّر إنشاء الصورة');
  }
}
function renderMeeting(){
  return `
    <div class="report-controls no-print">
      <strong style="color:var(--brand-dark);">جدول الاجتماع — تعبئة يدوية بالكامل، منفصل عن جدول الورديات</strong>
      <button class="btn secondary" onclick="addMeetingGroup()">+ إضافة اجتماع</button>
      <button class="export-btn" onclick="downloadMeetingImage()">📷 تحميل صورة</button>
      <button class="export-btn" onclick="printMeeting()">🖨 طباعة</button>
    </div>

    <div id="meetingPrintArea" class="print-area">
      <div class="roster-print-header">
        <img src="${document.querySelector('.logo-img') ? document.querySelector('.logo-img').src : ''}" class="roster-logo" alt="">
        <div>
          <div class="roster-dept">إدارة قسم التعبئة والروبوت</div>
          <div class="roster-week-title">جدول الاجتماع</div>
        </div>
      </div>

      ${meetingGroups.map(g => `
        <div class="meeting-group">
          <input type="text" class="meeting-title-input" value="${escapeHtml(g.title)}"
                 onchange="renameMeetingGroup('${g.id}', this.value)">
          <button class="icon-btn no-print" title="حذف الاجتماع" onclick="removeMeetingGroup('${g.id}')">🗑</button>
          <table class="roster-table">
            <thead><tr><th>الاسم</th><th>الكود</th><th class="no-print"></th></tr></thead>
            <tbody>
              ${g.rows.map((r,idx)=>`
                <tr>
                  <td style="position:relative;">
                    <input type="text" class="meeting-cell" id="meetingName_${g.id}_${idx}" placeholder="الاسم" value="${escapeHtml(r.name)}"
                        onchange="updateMeetingCell('${g.id}', ${idx}, 'name', this.value)">
                    <div class="emp-suggest" id="meetingSuggest_${g.id}_${idx}" style="display:none;"></div>
                  </td>
                  <td><input type="text" class="meeting-cell" id="meetingCode_${g.id}_${idx}" placeholder="الكود" value="${escapeHtml(r.code)}"
                        onchange="updateMeetingCell('${g.id}', ${idx}, 'code', this.value)"></td>
                  <td class="no-print"><button class="icon-btn" title="حذف السطر" onclick="removeMeetingRow('${g.id}', ${idx})">🗑</button></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <button class="btn secondary no-print" onclick="addMeetingRow('${g.id}')">+ إضافة اسم</button>
        </div>
      `).join('')}
    </div>
  `;
}

function renderEmp(){
  const editing = employees.find(e=>e.id===editingEmpId);
  let visibleEmps = employees.slice();
  if(dashFactoryFilter) visibleEmps = visibleEmps.filter(e=>e.factory===dashFactoryFilter);
  if(empStatusFilter) visibleEmps = visibleEmps.filter(e=>e.status===empStatusFilter);
  if(empSearch){
    const q = empSearch.trim().toLowerCase();
    visibleEmps = visibleEmps.filter(e=> e.name.toLowerCase().includes(q) || (e.code||'').toLowerCase().includes(q));
  }
  visibleEmps.sort((a,b)=>{
    let av,bv;
    if(empSortState.col==='code'){ av=a.code||''; bv=b.code||''; }
    else if(empSortState.col==='status'){ av=a.status; bv=b.status; }
    else if(empSortState.col==='factory'){ av=a.factory||''; bv=b.factory||''; }
    else if(empSortState.col==='rank'){ av=RANKS.indexOf(a.rank||'مشغل'); bv=RANKS.indexOf(b.rank||'مشغل'); }
    else { av=a.name; bv=b.name; }
    return compareVal(av,bv)*empSortState.dir;
  });
  let rows = visibleEmps.map(e=>{
    const photoUrl = employeePhotos[e.id];
    const initial = (e.name||'?').trim().charAt(0);
    return `
    <tr>
      <td>
        <div class="emp-avatar-wrap">
          ${photoUrl
            ? `<img src="${photoUrl}" class="emp-avatar" title="غيّر الصورة" onclick="document.getElementById('photoInput-${e.id}').click()">`
            : `<div class="emp-avatar emp-avatar-placeholder" title="ضيف صورة" onclick="document.getElementById('photoInput-${e.id}').click()">${escapeHtml(initial)}</div>`}
          <input type="file" accept="image/*" id="photoInput-${e.id}" style="display:none;" onchange="handlePhotoUpload('${e.id}', this.files[0])">
          ${photoUrl ? `<button class="emp-avatar-remove" title="حذف الصورة" onclick="removePhoto('${e.id}')">✕</button>` : ''}
        </div>
      </td>
      <td><strong class="emp-name">${escapeHtml(e.name)}</strong></td>
      <td class="emp-code-cell">${escapeHtml(e.code)||'—'}</td>
      <td class="emp-phone-cell">${empPhoneCell(e)}</td>
      <td><span class="pill status-${slug(e.status)}">${e.status}</span></td>
      <td><span class="pill factory-pill" style="background:${factoryColor(e.factory)};">${e.factory||'—'}</span></td>
      <td><span style="${rankStyle(e.rank)}">${e.rank||'مشغل'}</span></td>
      <td>${currentShiftOf(e.id)||'—'}</td>
      <td class="emp-joindate-cell">${e.joinDate? fmtDateAr(e.joinDate) : '—'}</td>
      <td style="white-space:nowrap;">
        <button class="icon-btn" title="تعديل" onclick="editEmployee('${e.id}')">✎</button>
        <button class="icon-btn" title="حذف" onclick="deleteEmployee('${e.id}')">🗑</button>
      </td>
    </tr>`;}).join('');
  if(visibleEmps.length===0){
    rows = `<tr class="empty-row"><td colspan="10">مفيش موظفين مطابقين — ${employees.length===0? 'ضيف أول واحد من الفورم فوق':'جرب تغيّر الفلاتر'}</td></tr>`;
  }
  return `
    <h3 style="margin-top:0;color:var(--brand-dark);">${editing? 'تعديل بيانات موظف':'إضافة موظف جديد'}</h3>
    <form class="grid-form" id="empForm">
      <div>
        <label>الاسم</label>
        <input type="text" id="fName" placeholder="اسم الموظف" required value="${editing? escapeHtml(editing.name):''}">
      </div>
      <div>
        <label>الكود (اختياري)</label>
        <input type="text" id="fCode" placeholder="كود الموظف" value="${editing? escapeHtml(editing.code||''):''}">
      </div>
      <div>
        <label>رقم تليفون 1 (اختياري)</label>
        <input type="tel" id="fPhone1" placeholder="01xxxxxxxxx" value="${editing? escapeHtml(editing.phone1||''):''}">
      </div>
      <div>
        <label>رقم تليفون 2 (اختياري)</label>
        <input type="tel" id="fPhone2" placeholder="01xxxxxxxxx" value="${editing? escapeHtml(editing.phone2||''):''}">
      </div>
      <div>
        <label>الحالة الوظيفية</label>
        <select id="fStatus">
          ${STATUSES.map(s=>`<option ${editing&&editing.status===s?'selected':''}>${s}</option>`).join('')}
        </select>
      </div>
      <div>
        <label>المصنع</label>
        <select id="fFactory">
          ${FACTORIES.map(f=>`<option ${editing&&editing.factory===f?'selected':''}>${f}</option>`).join('')}
        </select>
      </div>
      <div>
        <label>الرتبة</label>
        <select id="fRank">
          ${RANKS.map(r=>`<option ${editing&&editing.rank===r?'selected':(!editing&&r==='مشغل'?'selected':'')}>${r}</option>`).join('')}
        </select>
      </div>
      <div>
        <label>تاريخ الانضمام (اختياري)</label>
        <input type="date" id="fJoinDate" value="${editing&&editing.joinDate?editing.joinDate:''}">
      </div>
      <div style="display:flex;gap:8px;">
        <button type="submit" class="btn">${editing? 'حفظ التعديل':'إضافة'}</button>
        ${editing? `<button type="button" class="btn secondary" onclick="cancelEdit()">إلغاء</button>`:''}
      </div>
    </form>
    <div class="filters">
      <div class="search-field" style="position:relative;"><input type="text" id="empSearchInput" placeholder="بحث بالاسم أو الكود" value="${escapeHtml(empSearch)}" oninput="empSearch=this.value; render();"><div class="emp-suggest" id="empSearchSuggest" style="display:none;"></div></div>
      <select onchange="empStatusFilter=this.value; render();">
        <option value="">كل الحالات</option>
        ${STATUSES.map(s=>`<option value="${s}" ${empStatusFilter===s?'selected':''}>${s}</option>`).join('')}
      </select>
      <select id="empFactoryFilter" onchange="dashFactoryFilter=this.value; render();">
        <option value="">كل المصانع</option>
        ${FACTORIES.map(f=>`<option value="${f}" ${dashFactoryFilter===f?'selected':''}>${f}</option>`).join('')}
      </select>
    </div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr>
        <th></th>
        <th style="cursor:pointer;" onclick="setEmpSort('name')">الاسم ${sortArrow(empSortState,'name')}</th>
        <th style="cursor:pointer;" onclick="setEmpSort('code')">الكود ${sortArrow(empSortState,'code')}</th>
        <th>تليفون</th>
        <th style="cursor:pointer;" onclick="setEmpSort('status')">الحالة ${sortArrow(empSortState,'status')}</th>
        <th style="cursor:pointer;" onclick="setEmpSort('factory')">المصنع ${sortArrow(empSortState,'factory')}</th>
        <th style="cursor:pointer;" onclick="setEmpSort('rank')">الرتبة ${sortArrow(empSortState,'rank')}</th>
        <th>الوردية</th>
        <th>تاريخ الانضمام</th>
        <th>إجراءات</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>
    </div>
  `;
}

function renderLeaveForm(){
  if(employees.length===0){
    return `<div class="empty-state"><div class="big">👥</div>لازم تضيف موظفين الأول قبل ما تسجل إجازات<br><br>
    <button class="btn" onclick="switchTab('emp')">روح لتبويب الموظفين</button></div>`;
  }
  const editing = leaves.find(l=>l.id===editingLeaveId);
  const weekSat = getSaturdayOf(new Date());
  const weekFri = new Date(weekSat); weekFri.setDate(weekFri.getDate()+6);
  let recent = [...leaves].filter(l=>inRange(l.date, weekSat, weekFri));
  if(recentLeaveFactoryFilter){
    recent = recent.filter(l=>{
      const e = employees.find(x=>x.id===l.employeeId);
      return e && e.factory===recentLeaveFactoryFilter;
    });
  }
  if(recentLeaveShiftFilter){
    recent = recent.filter(l=>{
      const e = employees.find(x=>x.id===l.employeeId);
      return e && currentShiftOf(e.id)===recentLeaveShiftFilter;
    });
  }
  if(recentLeaveSearch){
    const q = recentLeaveSearch.trim().toLowerCase();
    recent = recent.filter(l=>{
      const e = employees.find(x=>x.id===l.employeeId);
      return e && (e.name.toLowerCase().includes(q) || (e.code||'').toLowerCase().includes(q));
    });
  }
  recent.sort((a,b)=>{
    let av, bv;
    const ea = employees.find(x=>x.id===a.employeeId), eb = employees.find(x=>x.id===b.employeeId);
    switch(recentLeaveSortState.col){
      case 'name': av=ea?ea.name:''; bv=eb?eb.name:''; break;
      case 'factory': av=ea?ea.factory:''; bv=eb?eb.factory:''; break;
      case 'type': av=a.type; bv=b.type; break;
      case 'date': default: av=a.date; bv=b.date; break;
    }
    return compareVal(av,bv)*recentLeaveSortState.dir;
  });
  let recentRows = recent.map(l=>{
    const e = employees.find(x=>x.id===l.employeeId);
    return `
    <tr>
      <td>${escapeHtml(empName(l.employeeId))}</td>
      <td>${e? `<span class="pill factory-pill" style="background:${factoryColor(e.factory)};">${e.factory||'—'}</span>` : '—'}</td>
      <td><span class="type-dot type-${slug(l.type)}"></span> ${l.type}</td>
      <td>${l.date}</td>
      <td>${escapeHtml(l.note)||'—'}</td>
      <td style="white-space:nowrap;">
        <button class="icon-btn" title="تعديل" onclick="editLeave('${l.id}')">✎</button>
        <button class="icon-btn" title="حذف" onclick="deleteLeave('${l.id}')">🗑</button>
      </td>
    </tr>`;}).join('');
  if(recent.length===0) recentRows = `<tr class="empty-row"><td colspan="6">لسه مفيش إجازات مطابقة الأسبوع ده</td></tr>`;

  return `
    <h3 style="margin-top:0;color:var(--brand-dark);">${editing? 'تعديل سجل إجازة':'تسجيل إجازة جديدة'}</h3>
    <form class="grid-form" id="leaveForm">
      <div class="emp-field" style="position:relative;">
        <label>الموظف <span style="font-weight:400;color:var(--ink-soft);">(اكتب الاسم أو الكود)</span></label>
        <input type="text" id="lEmpSearch" autocomplete="off" placeholder="اكتب اسم الموظف أو كوده..." value="${editing? escapeHtml(empDisplayLabel(employees.find(x=>x.id===editing.employeeId)||{name:'',factory:'',code:''})) : ''}">
        <input type="hidden" id="lEmp" value="${editing? editing.employeeId : ''}">
        <div class="emp-suggest" id="empSuggest" style="display:none;"></div>
      </div>
      <div>
        <label>نوع الإجازة</label>
        <div class="type-toggle" id="typeToggle">
          ${LEAVE_TYPES.map(t=>`<button type="button" data-type="${t}" class="${t===selectedLeaveType?'sel':''}"><span class="type-dot type-${slug(t)}"></span>${t}</button>`).join('')}
        </div>
      </div>
      <div>
        <label>التاريخ</label>
        <input type="date" id="lDate" value="${editing? editing.date : todayStr()}" required>
      </div>
      <div>
        <label>ملاحظات (اختياري)</label>
        <input type="text" id="lNote" placeholder="ملاحظة قصيرة" value="${editing? (editing.note||''):''}">
      </div>
      <div style="display:flex;gap:8px;">
        <button type="submit" class="btn">${editing? 'حفظ التعديل':'تسجيل الإجازة'}</button>
        ${editing? `<button type="button" class="btn secondary" onclick="cancelLeaveEdit()">إلغاء</button>`:''}
      </div>
    </form>
    <h3 style="color:var(--brand-dark);">سجلات الأسبوع الحالي (${dateFmtShort(weekSat)} - ${dateFmtShort(weekFri)})</h3>
    <div class="filters" style="margin-bottom:10px;">
      <div class="search-field" style="position:relative;"><input type="text" id="recentLeaveSearchInput" placeholder="بحث بالاسم أو الكود" value="${escapeHtml(recentLeaveSearch)}" oninput="recentLeaveSearch=this.value; render();"><div class="emp-suggest" id="recentLeaveSearchSuggest" style="display:none;"></div></div>
      <select onchange="recentLeaveFactoryFilter=this.value; render();">
        <option value="">كل المصانع</option>
        ${FACTORIES.map(f=>`<option value="${f}" ${recentLeaveFactoryFilter===f?'selected':''}>${f}</option>`).join('')}
      </select>
      <select onchange="recentLeaveShiftFilter=this.value; render();">
        <option value="">كل الورديات</option>
        ${SHIFTS.map(s=>`<option value="${s}" ${recentLeaveShiftFilter===s?'selected':''}>${s}</option>`).join('')}
      </select>
    </div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr>
        <th style="cursor:pointer;" onclick="setRecentLeaveSort('name')">الموظف ${sortArrow(recentLeaveSortState,'name')}</th>
        <th style="cursor:pointer;" onclick="setRecentLeaveSort('factory')">المصنع ${sortArrow(recentLeaveSortState,'factory')}</th>
        <th style="cursor:pointer;" onclick="setRecentLeaveSort('type')">النوع ${sortArrow(recentLeaveSortState,'type')}</th>
        <th style="cursor:pointer;" onclick="setRecentLeaveSort('date')">التاريخ ${sortArrow(recentLeaveSortState,'date')}</th>
        <th>ملاحظات</th><th></th>
      </tr></thead>
      <tbody>${recentRows}</tbody>
    </table>
    </div>
  `;
}

function renderLog(){
  const typeOptions = `<option value="">كل الأنواع</option>` + LEAVE_TYPES.map(t=>`<option value="${t}" ${logTypeFilter===t?'selected':''}>${t}</option>`).join('') + `<option value="${TRANSFER_TYPE}" ${logTypeFilter===TRANSFER_TYPE?'selected':''}>🔁 ${TRANSFER_TYPE}</option>`;
  const factoryOptions = `<option value="">كل المصانع</option>` + FACTORIES.map(f=>`<option value="${f}" ${logFactoryFilter===f?'selected':''}>${f}</option>`).join('');
  const shiftOptions = `<option value="">كل الورديات</option>` + SHIFTS.map(s=>`<option value="${s}" ${logShiftFilter===s?'selected':''}>${s}</option>`).join('');
  return `
    <h3 style="margin-top:0;color:var(--brand-dark);">السجل الكامل</h3>
    <div class="filters no-print">
      <div class="search-field" style="position:relative;"><input type="text" id="logSearchInput" placeholder="بحث بالاسم أو الكود أو الملاحظات" value="${escapeHtml(logSearch)}" oninput="logSearch=this.value; applyLogFilters();"><div class="emp-suggest" id="logSearchSuggest" style="display:none;"></div></div>
      <select id="filterType" onchange="logTypeFilter=this.value; applyLogFilters();">${typeOptions}</select>
      <select id="filterFactory" onchange="logFactoryFilter=this.value; applyLogFilters();">${factoryOptions}</select>
      <select id="filterShift" onchange="logShiftFilter=this.value; applyLogFilters();">${shiftOptions}</select>
      <input type="month" id="filterMonth" value="${logMonthFilter}" onchange="logMonthFilter=this.value; applyLogFilters();">
      <button class="btn secondary" onclick="resetLogFilters()">إعادة تعيين</button>
      <button class="btn secondary" onclick="downloadPanelImage('السجل_الكامل.png', buildLogFilterSummary())">📷 تحميل صورة</button>
    </div>
    <div style="overflow-x:auto;">
    <table id="logTable">
      <thead><tr>
        <th style="cursor:pointer;" onclick="setLogSort('name')">الموظف ${sortArrow(logSortState,'name')}</th>
        <th style="cursor:pointer;" onclick="setLogSort('code')">الكود ${sortArrow(logSortState,'code')}</th>
        <th style="cursor:pointer;" onclick="setLogSort('factory')">المصنع ${sortArrow(logSortState,'factory')}</th>
        <th style="cursor:pointer;" onclick="setLogSort('shift')">الوردية ${sortArrow(logSortState,'shift')}</th>
        <th style="cursor:pointer;" onclick="setLogSort('type')">النوع ${sortArrow(logSortState,'type')}</th>
        <th style="cursor:pointer;" onclick="setLogSort('date')">التاريخ ${sortArrow(logSortState,'date')}</th>
        <th style="cursor:pointer;" onclick="setLogSort('note')">ملاحظات ${sortArrow(logSortState,'note')}</th>
        <th class="no-print"></th>
      </tr></thead>
      <tbody id="logBody"></tbody>
    </table>
    </div>
  `;
}

function fillLogTable(list){
  const body = document.getElementById('logBody');
  if(!body) return;
  const sorted = [...list].sort((a,b)=>{
    const ea = employees.find(x=>x.id===a.employeeId) || {};
    const eb = employees.find(x=>x.id===b.employeeId) || {};
    let av, bv;
    switch(logSortState.col){
      case 'name': av=ea.name||''; bv=eb.name||''; break;
      case 'code': av=ea.code||''; bv=eb.code||''; break;
      case 'factory': av=ea.factory||''; bv=eb.factory||''; break;
      case 'shift': av=currentShiftOf(ea.id)||''; bv=currentShiftOf(eb.id)||''; break;
      case 'type': av=a.type; bv=b.type; break;
      case 'note': av=a.note||''; bv=b.note||''; break;
      default: av=a.date; bv=b.date;
    }
    return compareVal(av,bv)*logSortState.dir;
  });
  if(sorted.length===0){
    body.innerHTML = `<tr class="empty-row"><td colspan="8">مفيش نتائج مطابقة</td></tr>`;
    return;
  }
  body.innerHTML = sorted.map(l=>{
    const e = employees.find(x=>x.id===l.employeeId);
    const isTransfer = l.type===TRANSFER_TYPE;
    const actions = isTransfer
      ? `<button class="icon-btn" title="حذف" onclick="deleteTransfer('${l.id}')">🗑</button>`
      : `<button class="icon-btn" title="تعديل" onclick="editLeave('${l.id}')">✎</button>
         <button class="icon-btn" title="حذف" onclick="deleteLeave('${l.id}')">🗑</button>`;
    return `<tr>
      <td>${e? escapeHtml(e.name):'—'}</td>
      <td>${e? (escapeHtml(e.code)||'—'):'—'}</td>
      <td>${e? `<span class="pill factory-pill" style="background:${factoryColor(e.factory)};">${e.factory||'—'}</span>` : '—'}</td>
      <td>${e? (currentShiftOf(e.id)||'—') : '—'}</td>
      <td><span class="type-dot type-${slug(l.type)}"></span> ${isTransfer?'🔁 ':''}${l.type}</td>
      <td>${l.date}</td>
      <td class="${isTransfer?'log-transfer-note':''}">${escapeHtml(l.note)||'—'}</td>
      <td class="no-print" style="white-space:nowrap;">${actions}</td>
    </tr>`;
  }).join('');
}

function applyLogFilters(){
  const type = document.getElementById('filterType').value;
  const month = document.getElementById('filterMonth').value;
  const factory = document.getElementById('filterFactory').value;
  const shift = document.getElementById('filterShift').value;
  logTypeFilter = type;
  logMonthFilter = month;
  logFactoryFilter = factory;
  logShiftFilter = shift;
  let list = [...leaves, ...transfers];
  if(type) list = list.filter(l=>l.type===type);
  if(month) list = list.filter(l=>l.date.slice(0,7)===month);
  if(factory) list = list.filter(l=>{ const e=employees.find(x=>x.id===l.employeeId); return e && e.factory===factory; });
  if(shift) list = list.filter(l=>{ const e=employees.find(x=>x.id===l.employeeId); return e && currentShiftOf(e.id)===shift; });
  if(logSearch){
    const q = logSearch.trim().toLowerCase();
    list = list.filter(l=>{
      const e = employees.find(x=>x.id===l.employeeId);
      return (e && e.name.toLowerCase().includes(q)) || (e && (e.code||'').toLowerCase().includes(q)) || (l.note||'').toLowerCase().includes(q);
    });
  }
  fillLogTable(list);
}
function resetLogFilters(){
  logTypeFilter='';
  logMonthFilter='';
  logFactoryFilter='';
  logShiftFilter='';
  logSearch='';
  render();
}

/* ---------- REWARDS & PENALTIES (المكافآت والجزاءات) ---------- */
function renderRewards(){
  if(employees.length===0){
    return `<div class="empty-state"><div class="big">👥</div>لازم تضيف موظفين الأول قبل ما تسجل مكافأة أو جزاء<br><br>
    <button class="btn" onclick="switchTab('emp')">روح لتبويب الموظفين</button></div>`;
  }
  const editing = citations.find(c=>c.id===editingCitationId);

  let list = citations.slice();
  if(citationKindFilter) list = list.filter(c=>c.kind===citationKindFilter);
  if(citationMonthFilter) list = list.filter(c=>c.date.slice(0,7)===citationMonthFilter);
  if(citationFactoryFilter){
    list = list.filter(c=>{ const e=employees.find(x=>x.id===c.employeeId); return e && e.factory===citationFactoryFilter; });
  }
  if(citationSearch){
    const q = citationSearch.trim().toLowerCase();
    list = list.filter(c=>{
      const e = employees.find(x=>x.id===c.employeeId);
      return e && (e.name.toLowerCase().includes(q) || (e.code||'').toLowerCase().includes(q));
    });
  }
  list.sort((a,b)=>{
    const ea = employees.find(x=>x.id===a.employeeId), eb = employees.find(x=>x.id===b.employeeId);
    let av, bv;
    switch(citationSortState.col){
      case 'name': av=ea?ea.name:''; bv=eb?eb.name:''; break;
      case 'code': av=ea?(ea.code||''):''; bv=eb?(eb.code||''):''; break;
      case 'factory': av=ea?(ea.factory||''):''; bv=eb?(eb.factory||''):''; break;
      case 'kind': av=a.kind; bv=b.kind; break;
      case 'amount': av=Number(a.amount)||0; bv=Number(b.amount)||0; break;
      case 'date': default: av=a.date; bv=b.date; break;
    }
    return compareVal(av,bv)*citationSortState.dir;
  });

  const totalRewards = citations.filter(c=>c.kind==='مكافأة').reduce((s,c)=>s+(Number(c.amount)||0),0);
  const totalPenalties = citations.filter(c=>c.kind==='جزاء').reduce((s,c)=>s+(Number(c.amount)||0),0);

  let rows = list.map(c=>{
    const e = employees.find(x=>x.id===c.employeeId);
    return `
    <tr>
      <td>${e? escapeHtml(e.name):'—'}</td>
      <td>${e? (escapeHtml(e.code)||'—'):'—'}</td>
      <td>${e? `<span class="pill factory-pill" style="background:${factoryColor(e.factory)};">${e.factory||'—'}</span>` : '—'}</td>
      <td><span class="citation-pill ${slug(c.kind)}"><span class="type-dot type-${slug(c.kind)}"></span>${c.kind}</span></td>
      <td class="citation-amount ${slug(c.kind)}">${c.kind==='جزاء'?'-':'+'}${Number(c.amount)||0} ج.م</td>
      <td>${escapeHtml(c.reason)||'—'}</td>
      <td>${c.date}</td>
      <td style="white-space:nowrap;">
        <button class="icon-btn" title="تعديل" onclick="editCitation('${c.id}')">✎</button>
        <button class="icon-btn" title="حذف" onclick="deleteCitation('${c.id}')">🗑</button>
      </td>
    </tr>`;
  }).join('');
  if(list.length===0) rows = `<tr class="empty-row"><td colspan="8">لسه مفيش سجلات مطابقة</td></tr>`;

  return `
    <h3 style="margin-top:0;color:var(--brand-dark);">${editing? 'تعديل سجل':'تسجيل مكافأة أو جزاء'}</h3>
    <form class="grid-form" id="citationForm">
      <div class="emp-field" style="position:relative;">
        <label>الموظف <span style="font-weight:400;color:var(--ink-soft);">(اكتب الاسم أو الكود)</span></label>
        <input type="text" id="ciEmpSearch" autocomplete="off" placeholder="اكتب اسم الموظف أو كوده..." value="${editing? escapeHtml(empDisplayLabel(employees.find(x=>x.id===editing.employeeId)||{name:'',factory:'',code:''})) : ''}">
        <input type="hidden" id="ciEmp" value="${editing? editing.employeeId : ''}">
        <div class="emp-suggest" id="ciEmpSuggest" style="display:none;"></div>
      </div>
      <div>
        <label>النوع</label>
        <div class="type-toggle" id="citationToggle">
          ${CITATION_KINDS.map(k=>`<button type="button" data-kind="${k}" class="${k===selectedCitationKind?'sel':''}"><span class="type-dot type-${slug(k)}"></span>${k}</button>`).join('')}
        </div>
      </div>
      <div>
        <label>القيمة (جنيه)</label>
        <input type="number" id="ciAmount" min="0" step="1" placeholder="مثلاً 100" value="${editing? (editing.amount||''):''}" required>
      </div>
      <div>
        <label>التاريخ</label>
        <input type="date" id="ciDate" value="${editing? editing.date : todayStr()}" required>
      </div>
      <div style="grid-column:1 / -1;">
        <label>السبب</label>
        <textarea id="ciReason" rows="3" placeholder="سبب المكافأة أو الجزاء">${editing? escapeHtml(editing.reason||''):''}</textarea>
      </div>
      <div style="display:flex;gap:8px;">
        <button type="submit" class="btn">${editing? 'حفظ التعديل':'تسجيل'}</button>
        ${editing? `<button type="button" class="btn secondary" onclick="cancelCitationEdit()">إلغاء</button>`:''}
      </div>
    </form>

    <div class="cards" style="margin-bottom:16px;">
      <div class="card"><div class="lbl">إجمالي المكافآت</div><div class="num" style="color:var(--success);">+${totalRewards} ج.م</div></div>
      <div class="card"><div class="lbl">إجمالي الجزاءات</div><div class="num" style="color:var(--danger);">-${totalPenalties} ج.م</div></div>
    </div>

    <h3 style="color:var(--brand-dark);">السجل الكامل</h3>
    <div class="filters">
      <div class="search-field" style="position:relative;"><input type="text" id="citationSearchInput" placeholder="بحث بالاسم أو الكود" value="${escapeHtml(citationSearch)}" oninput="citationSearch=this.value; render();"><div class="emp-suggest" id="citationSearchSuggest" style="display:none;"></div></div>
      <select onchange="citationKindFilter=this.value; render();">
        <option value="">كل الأنواع</option>
        ${CITATION_KINDS.map(k=>`<option value="${k}" ${citationKindFilter===k?'selected':''}>${k}</option>`).join('')}
      </select>
      <select onchange="citationFactoryFilter=this.value; render();">
        <option value="">كل المصانع</option>
        ${FACTORIES.map(f=>`<option value="${f}" ${citationFactoryFilter===f?'selected':''}>${f}</option>`).join('')}
      </select>
      <input type="month" value="${citationMonthFilter}" onchange="citationMonthFilter=this.value; render();">
    </div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr>
        <th style="cursor:pointer;" onclick="setCitationSort('name')">الموظف ${sortArrow(citationSortState,'name')}</th>
        <th style="cursor:pointer;" onclick="setCitationSort('code')">الكود ${sortArrow(citationSortState,'code')}</th>
        <th style="cursor:pointer;" onclick="setCitationSort('factory')">المصنع ${sortArrow(citationSortState,'factory')}</th>
        <th style="cursor:pointer;" onclick="setCitationSort('kind')">النوع ${sortArrow(citationSortState,'kind')}</th>
        <th style="cursor:pointer;" onclick="setCitationSort('amount')">القيمة ${sortArrow(citationSortState,'amount')}</th>
        <th>السبب</th>
        <th style="cursor:pointer;" onclick="setCitationSort('date')">التاريخ ${sortArrow(citationSortState,'date')}</th>
        <th></th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>
    </div>
  `;
}
function setCitationSort(col){ toggleSort(citationSortState, col); render(); }
function editCitation(id){
  const c = citations.find(x=>x.id===id);
  if(!c) return;
  editingCitationId = id;
  selectedCitationKind = c.kind;
  currentTab = 'rewards';
  document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('active', b.dataset.tab==='rewards'));
  render();
  window.scrollTo({top:0,behavior:'smooth'});
}
function cancelCitationEdit(){ editingCitationId = null; render(); }
async function deleteCitation(id){
  if(!confirm('تأكيد حذف السجل ده؟')) return;
  citations = citations.filter(c=>c.id!==id);
  await saveCitations();
  showToast('تم الحذف');
  render();
}

/* ---------- HANDLERS ---------- */
function attachHandlers(){
  if(currentTab==='reports'){
    attachSearchSuggestions('reportSearchInput', 'reportSearchSuggest', (v)=>{ reportSearch = v; }, render);
  }
  if(currentTab==='emp'){
    attachSearchSuggestions('empSearchInput', 'empSearchSuggest', (v)=>{ empSearch = v; }, render);
    document.getElementById('empForm').addEventListener('submit', async (ev)=>{
      ev.preventDefault();
      const name = document.getElementById('fName').value.trim();
      const code = document.getElementById('fCode').value.trim();
      const phone1 = document.getElementById('fPhone1').value.trim();
      const phone2 = document.getElementById('fPhone2').value.trim();
      const status = document.getElementById('fStatus').value;
      const factory = document.getElementById('fFactory').value;
      const rank = document.getElementById('fRank').value;
      const joinDate = document.getElementById('fJoinDate').value;
      if(!name) return;
      if(code){
        const dupCode = employees.find(x=>x.code && x.code.trim()===code && x.id!==editingEmpId);
        if(dupCode){
          showToast(`⚠️ الكود ده مستخدم بالفعل مع "${dupCode.name}"`);
          return;
        }
      }
      if(editingEmpId){
        const e = employees.find(x=>x.id===editingEmpId);
        if(!e){
          showToast('الموظف ده اتحذف أو اتغيّر من جهاز تاني — حاول تاني');
          editingEmpId = null;
          render();
          return;
        }
        const prevFactory = e.factory;
        e.name=name; e.code=code; e.phone1=phone1||null; e.phone2=phone2||null; e.status=status; e.factory=factory; e.rank=rank; e.joinDate=joinDate||null;
        editingEmpId = null;
        if(prevFactory && factory && prevFactory!==factory){
          transfers.push({id:uid(), employeeId:e.id, type:TRANSFER_TYPE, date:fmtDate(new Date()), fromFactory:prevFactory, toFactory:factory, note:`من ${prevFactory} إلى ${factory}`});
          await saveTransfers();
          showToast('تم حفظ التعديل وتسجيل انتقال المصنع');
        }else{
          showToast('تم حفظ التعديل');
        }
      }else{
        employees.push({id:uid(), name, code, phone1:phone1||null, phone2:phone2||null, status, factory, rank, joinDate:joinDate||null, shift:null});
        showToast('تم إضافة الموظف');
      }
      await saveEmployees();
      render();
    });
  }
  if(currentTab==='leave'){
    attachSearchSuggestions('recentLeaveSearchInput', 'recentLeaveSearchSuggest', (v)=>{ recentLeaveSearch = v; }, render);
    const toggle = document.getElementById('typeToggle');
    if(toggle){
      toggle.querySelectorAll('button').forEach(b=>{
        b.addEventListener('click', ()=>{
          selectedLeaveType = b.dataset.type;
          toggle.querySelectorAll('button').forEach(x=>x.classList.remove('sel'));
          b.classList.add('sel');
        });
      });
    }
    initEmpAutocomplete('lEmpSearch', 'lEmp', 'empSuggest', ()=>{
      const dateInput = document.getElementById('lDate');
      if(dateInput) dateInput.focus();
    });
    const form = document.getElementById('leaveForm');
    if(form){
      form.addEventListener('submit', async (ev)=>{
        ev.preventDefault();
        const employeeId = document.getElementById('lEmp').value;
        const date = document.getElementById('lDate').value;
        const note = document.getElementById('lNote').value.trim();
        if(!employeeId){
          showToast('اختار الموظف من قائمة الاقتراحات الأول');
          const empSearchInput = document.getElementById('lEmpSearch');
          if(empSearchInput) empSearchInput.focus();
          return;
        }
        if(!date) return;
        const isDup = leaves.some(l=>l.employeeId===employeeId && l.date===date && l.type===selectedLeaveType && l.id!==editingLeaveId);
        if(isDup){
          showToast('⚠️ في سجل إجازة مطابق لنفس الموظف واليوم والنوع ده متسجل بالفعل');
          return;
        }
        if(editingLeaveId){
          const l = leaves.find(x=>x.id===editingLeaveId);
          if(!l){
            showToast('السجل ده اتحذف أو اتغيّر من جهاز تاني — حاول تاني');
            editingLeaveId = null;
            render();
            return;
          }
          l.employeeId=employeeId; l.type=selectedLeaveType; l.date=date; l.note=note;
          editingLeaveId = null;
          showToast('تم حفظ التعديل');
        }else{
          leaves.push({id:uid(), employeeId, type:selectedLeaveType, date, note});
          showToast('تم تسجيل الإجازة');
        }
        await saveLeaves();
        render();
      });
    }
  }
  if(currentTab==='alexmsg'){
    for(let idx=0; idx<alexandriaOrder.length; idx++){
      initEmpAutocomplete(`alexOrderSearch${idx}`, null, `alexOrderSuggest${idx}`, (e)=>setAlexOrderPerson(idx, e.id));
    }
  }
  if(currentTab==='log'){
    attachSearchSuggestions('logSearchInput', 'logSearchSuggest', (v)=>{ logSearch = v; }, applyLogFilters);
    applyLogFilters();
  }
  if(currentTab==='rewards'){
    attachSearchSuggestions('citationSearchInput', 'citationSearchSuggest', (v)=>{ citationSearch = v; }, render);
    initEmpAutocomplete('ciEmpSearch', 'ciEmp', 'ciEmpSuggest');
    const toggle = document.getElementById('citationToggle');
    if(toggle){
      toggle.querySelectorAll('button').forEach(b=>{
        b.addEventListener('click', ()=>{
          selectedCitationKind = b.dataset.kind;
          toggle.querySelectorAll('button').forEach(x=>x.classList.remove('sel'));
          b.classList.add('sel');
        });
      });
    }
    const form = document.getElementById('citationForm');
    if(form){
      form.addEventListener('submit', async (ev)=>{
        ev.preventDefault();
        const employeeId = document.getElementById('ciEmp').value;
        const amount = document.getElementById('ciAmount').value;
        const date = document.getElementById('ciDate').value;
        const reason = document.getElementById('ciReason').value.trim();
        if(!employeeId){
          showToast('اختار الموظف من قائمة الاقتراحات الأول');
          const s = document.getElementById('ciEmpSearch');
          if(s) s.focus();
          return;
        }
        if(!amount || Number(amount)<=0){ showToast('اكتب قيمة صحيحة'); return; }
        if(!date) return;
        if(editingCitationId){
          const c = citations.find(x=>x.id===editingCitationId);
          if(c){
            c.employeeId=employeeId; c.kind=selectedCitationKind; c.amount=Number(amount); c.date=date; c.reason=reason;
          }
          editingCitationId = null;
          showToast('تم حفظ التعديل');
        }else{
          citations.push({id:uid(), employeeId, kind:selectedCitationKind, amount:Number(amount), date, reason});
          showToast(selectedCitationKind==='مكافأة' ? 'تم تسجيل المكافأة' : 'تم تسجيل الجزاء');
        }
        await saveCitations();
        render();
      });
    }
  }
  if(currentTab==='meeting'){
    meetingGroups.forEach(g=>{
      g.rows.forEach((r,idx)=>attachMeetingRowAutocomplete(g.id, idx));
    });
  }
}

function editEmployee(id){ editingEmpId = id; render(); window.scrollTo({top:0,behavior:'smooth'}); }
function cancelEdit(){ editingEmpId = null; render(); }
function editLeave(id){
  const l = leaves.find(x=>x.id===id);
  if(!l) return;
  editingLeaveId = id;
  selectedLeaveType = l.type;
  currentTab = 'leave';
  document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('active', b.dataset.tab==='leave'));
  render();
  window.scrollTo({top:0,behavior:'smooth'});
}
function cancelLeaveEdit(){ editingLeaveId = null; render(); }
async function deleteEmployee(id){
  if(!confirm('تأكيد حذف الموظف؟ هيتحذف معاه كل سجلات إجازاته ومكافآته وجزاءاته.')) return;
  employees = employees.filter(e=>e.id!==id);
  leaves = leaves.filter(l=>l.employeeId!==id);
  transfers = transfers.filter(t=>t.employeeId!==id);
  citations = citations.filter(c=>c.employeeId!==id);
  if(employeePhotos[id]){ delete employeePhotos[id]; await savePhotos(); }
  await saveEmployees(); await saveLeaves(); await saveTransfers(); await saveCitations();
  showToast('تم الحذف');
  render();
}
async function deleteLeave(id){
  if(!confirm('تأكيد حذف سجل الإجازة؟')) return;
  leaves = leaves.filter(l=>l.id!==id);
  await saveLeaves();
  showToast('تم الحذف');
  render();
}
async function deleteTransfer(id){
  if(!confirm('تأكيد حذف سجل الانتقال؟')) return;
  transfers = transfers.filter(t=>t.id!==id);
  await saveTransfers();
  showToast('تم الحذف');
  render();
}

function switchTab(tab){
  currentTab = tab;
  document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('active', b.dataset.tab===tab));
  updateMobileNavLabel();
  closeMobileNav();
  render();
}
function toggleMobileNav(){
  const nav = document.getElementById('tabs');
  const toggle = document.getElementById('mobileNavToggle');
  if(!nav || !toggle) return;
  const isOpen = nav.classList.toggle('mobile-open');
  toggle.classList.toggle('open', isOpen);
}
function closeMobileNav(){
  const nav = document.getElementById('tabs');
  const toggle = document.getElementById('mobileNavToggle');
  if(nav) nav.classList.remove('mobile-open');
  if(toggle) toggle.classList.remove('open');
}
function updateMobileNavLabel(){
  const activeBtn = document.querySelector('#tabs button.active');
  const label = document.getElementById('mobileNavCurrentLabel');
  if(!activeBtn || !label) return;
  const clone = activeBtn.cloneNode(true);
  const badge = clone.querySelector('.nav-badge');
  if(badge) badge.remove();
  label.textContent = clone.textContent.trim();
}

document.getElementById('tabs').addEventListener('click', (ev)=>{
  const btn = ev.target.closest('button[data-tab]');
  if(btn) switchTab(btn.dataset.tab);
});

/* ---------- EXPORT ---------- */
function exportExcel(){
  const empSheet = employees.map(e=>{
    const c = leaveCountsFor(e.id);
    const total = LEAVE_TYPES.reduce((s,t)=>s+c[t],0);
    const row = {'الاسم':e.name,'الكود':e.code||'','تليفون 1':e.phone1||'','تليفون 2':e.phone2||'','المصنع':e.factory||'','الحالة':e.status,'الرتبة':e.rank||'','الوردية':currentShiftOf(e.id)||''};
    LEAVE_TYPES.forEach(t=>row[t]=c[t]);
    row['الإجمالي']=total;
    return row;
  });
  const logSheet = [...leaves].sort((a,b)=>b.date.localeCompare(a.date)).map(l=>{
    const e = employees.find(x=>x.id===l.employeeId);
    return {'الاسم':e?e.name:'—','الكود':e?(e.code||''):'','المصنع':e?(e.factory||''):'','الوردية':e?(currentShiftOf(e.id)||''):'','النوع':l.type,'التاريخ':l.date,'ملاحظات':l.note||''};
  });
  const transferSheet = [...transfers].sort((a,b)=>b.date.localeCompare(a.date)).map(t=>{
    const e = employees.find(x=>x.id===t.employeeId);
    return {'الاسم':e?e.name:'—','الكود':e?(e.code||''):'','من مصنع':t.fromFactory||'','إلى مصنع':t.toFactory||'','التاريخ':t.date};
  });
  const citationSheet = [...citations].sort((a,b)=>b.date.localeCompare(a.date)).map(c=>{
    const e = employees.find(x=>x.id===c.employeeId);
    return {'الاسم':e?e.name:'—','الكود':e?(e.code||''):'','النوع':c.kind,'القيمة':c.amount||0,'السبب':c.reason||'','التاريخ':c.date};
  });
  const wb = XLSX.utils.book_new();
  const ws1 = XLSX.utils.json_to_sheet(empSheet);
  const ws2 = XLSX.utils.json_to_sheet(logSheet);
  XLSX.utils.book_append_sheet(wb, ws1, 'ملخص الموظفين');
  XLSX.utils.book_append_sheet(wb, ws2, 'سجل الإجازات');
  if(transferSheet.length>0){
    const ws3 = XLSX.utils.json_to_sheet(transferSheet);
    XLSX.utils.book_append_sheet(wb, ws3, 'سجل انتقال المصنع');
  }
  if(citationSheet.length>0){
    const ws4 = XLSX.utils.json_to_sheet(citationSheet);
    XLSX.utils.book_append_sheet(wb, ws4, 'المكافآت والجزاءات');
  }
  XLSX.writeFile(wb, 'سجل_الموظفين_والاجازات.xlsx');
  showToast('تم تحميل ملف Excel');
}

/* ---------- INIT ---------- */
/* ---------- APP ICON / MANIFEST (Add to Home Screen) ---------- */
function setupAppManifest(){
  try{
    const manifest = {
      name: "إدارة قسم التعبئة والروبوت - سجل الموظفين والإجازات",
      short_name: "التعبئة والروبوت",
      start_url: ".",
      display: "standalone",
      background_color: "#EEF1EF",
      theme_color: "#1B3A34",
      icons: [
        { src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAABvy0lEQVR4nO2dd4BeVZn/P+fc8tbpJZNeSSMhQEIJLaH3IhgQFAuudW3rupZ1V8SyumtbV/2JqNiwYABRaVI0oZMQCCEFSO8zyfR5+73nnN8f977vvDNJqDPJDOSb3HnvvW+57Xme8/QjOHgQCxYssJY2NhoWL1blb0x/15Wz7Eh8pPLyF0hpjTFKaQQLhZSNRmsDiIN4nm8V+NJ17VFVtZ/527e/e+PO9vba0bW1au3mzc7MiRP3vPurXz7/mS2bbjVKCYyxXucxjJBSGK33YFgiLEtqrXZYTuQeP5/Z/cItf1zd59OLFlkL9uwRS5cuVYB5w1f4KjD4hHX99XIBS+TSG5b6xV3T3/nOkbbLmUjmaF+fbzQTLceOB2cUnJLxfYw5KPfgrQglbNtyhXjkmZ/96nLABWjLtMm6eF3+Dw88UP+NP/zmDqX19EAYCflGDiaEQNh2sBE+U+X5GSHZLG15L5rn/AIPvfDb3+4ufmfB9QvspSzU3HCDfiPHfsVzG7Rfvv56ydq1oijtZy5alDQx9zKEXiQQCyzHqUIIjPLRSoPWGsAIYcKTkoN6fm9dGKTQQoiet5+24Pwvv/cDL+xs31kxuna02tnebo2ure04/kPX/Taj9SWmUFDA65X+fY8JwVBuwscrpZSWRFg2GIPyvC6DWYqRi0W2cOfaxYtTACxaZDFzphksRhgMAhOLFi2Si0PCP/L9185A6Q8bYy60XHey0Rrj+2hjFMYYARIhxCCdy2HsC1+4rl0biXzv4R/+5HNrd+8eNXPkyMKmXbucSaNGtV387//2rs0tLTcaz/MRwh7E8zAYYwxohBBSCEvYNkJKVKGwUQhxN5a8cc3Pf7MOYNGiRdbixYs1A6waDSjRhSepAKZf965ZUul/E0JcJR0non0P7SsfIYQ4LN0PFTSWFLaQ6/701W+eP2nUKD+TyQiAeDzu3b5kSe2Xf/Wzx7Qx1QSS+mA+o4AZjDHStmxpO2jPyxtjbtWW/NYLN9+yGvrS2EBgoC5QcP31ghtu0DMXLUoSdf5HWOL9wrZcnS9gwA+J/g3pkofxhqGEbVtTR4257o6vfeMPm3btapg0apQfqj5tx33gPX/Man2h8fyBUn1eL7QBLcCWERfjq4JR5ufkvM+uXbw4xfXXS264wTAAo8EbZ4DgZDTAzPdc80Eh5OeEFJO052EMvhBYA3Kcw3iDEEpYUtrIVSt/8euz2toy0bq6uN60a5c9adSotgs/+5n3bG1t/pHx1aEm/nIYY1BCYEvHwWizyRj932t/9bubgD6093rxhghz7gfnOituWuEd9a6zE76s/4Pl2BdppdG+r0TgOThM+EMFxmjhOPKIkSPf/6ev/88fd7a314yurS2qEmbO+971iDJmslFaI4bcSG2MMVratiUtifL8u2zd+o5VtzyQLtLg6/3h10+gCxbYLF3qT3vnVQttx7pRSGua8jwljBFv1G12GAMOJSzLsg3Pr/zlLWdkIBIHE0r/1vP/7dMf3N6+93tDQPV5eRijjRDGchzLaPWi76kPv/jbW5cUafH1/OTrIVSxaNEii6VL/ZnXXv1527HuElJOU4WCL8A6TPxDFUZPHjvmu0CuedcuC2DSqFE+UL1rb8vHh0XAUQgpwFKFgi+knGY71l0zr7368yxd6i9atOh1qdqv9QtBNHfpUn/Gu6/8jhOJf9rP5TBaayGFPDixu8N4jdBIKaXRrbfe8L15MyeOzAOyKP0v+Oy/fGBb697/NZ7vI7CHxTMUYLTRQkppR6N4+cx31/36j/+6YMEC+7VGkV+LtO4l/ndd+R3biX7ay2Q8tDFCHCb+IQwjLElNReWvZ04c2bpp1y43k8mISaNGeTvb2+t2tuz5BEqDMcPnGRoQQki0MV4m49lO9NMz3nXld5YuXeovWLDgNY0Er5YB+hJ/JPppP5/3EMIxAlH0Rx1eht4CSJQpnHjkrL8ATlV1te7IdUgg/e8/+dExvjCTtFLGCCEP9bm+5kUgEMLx83nPjrw+Jng1DCBYtEgWid+KRj/t5fI+4LyaAxzGIYRBY1nCErzwPx/9xNpMJpOoi8c1xADM6k0bPoSQBiEGNd/mIMDxcnnfivYyAYsWvSov5CsywNwPftBm8WI1/V1XfduKRj/tZ3OeEAxmiPwwBgoCjZRUV1bcA6SaOzutTCYjRtfW5n5+/13j83nvJJQCM+Tcnq8ZQmD72ZxnRaOfnv6uq77N4sVq7gc/+Ip0+rIXvuD6BfaKm27ypl+z6HNOLPqvfi5fEAJnCAx+h5dXt9jGK5g5U6beD0SrqiO6ubPTAtK3//2hBcYS1cZojTBiCJzrG16EwPFz+YITi/7r9GsWfW7FTTd5C65f8LJMcOAhYtEii8WL1YxrrjxNOPIeo0wkzAsf2q6ywwhgjBa2JS0h16z65W9Pz4AbBxOmPXQf+/733JpX3jlh5PfNNKIbhFDCEnnj6QvW/e6PDxdpeX8f3v8IYIxgzx4x7ZJLKhD8UiATaH04sjucIIRBCmKu+yyQ7Whvl6H6U1jyzDMN+XzuBKO0YCgHvl4fBFpLgUwg+OW0Sy6pYM8eQTENux/2zwBf/rJg6VJfJCN/kI4zUQWpscNeT3yLwYBgRFXt44DO53KiI5eTQPbmu/90lLFkAlC8GYWaEFJ5ni8dZ6JIRv7A0qU+X/7yq2OARYsWWdxwg55xzaL32657gfI8XwxuXvhhDDwMQlhGqfQpx85ZDsSbqqtVPpcTgNresvdoIaXzZi65E0LYyvN823UvmHHNovdzww06jBb3QX/CFotnzjRjFi2KCclXtVJGYA5L/mEJIaQ2ueOnzeokVHMi0agBRFc2dRpGA/tXC94sECC1UkZIvjpm0aLfLZ45Mx/spsT4fYl70SLJDTfopMN3hO2ONEppDHIIGPiHl9e2KGFJopHo0oXHHrt7Z3u7CzC6tjb/87vumlDIezOM0rwFnq00SmlhuyOTDt/hhht0GB8ooXfj+uslM2eaqVdfPV0I8SFdKGjefAbSWxEqn8uJbDYrAH/ztm2VGhqDCt03of6/LyxdKGghxIemXn31dGbONFx/fYnuSyuL1q4V3HCDFnifl44jjTHDPTr41oUxEm0YUVP3EGBHolGTC/R//6Vd28cjStkrbwkYY7R0HCnwPs8NN+hFa9eWGD9ggOuvl4sXL1ZHXHvVDGlZV+lCQSOEdehHsGG4GDO4y6s/F9NUVbODUMrng8YDhR1te07CsoQBdcjv1UFaEMLShYKWlnXVEddeNWPx4sWqOApIgAVLlkgAy9cfkY4d1YGF9KaIDg7QLSxDv/dMvyXcH/zrXXtj/9jP8fQ+x+w9VwMC0ZNNJ/ufvGtZ3fu9jjf1gtAYLR07avn6I9BL8zYgli5dqsZfemk1mIt1wTPCIPd98G9lhPfiZbyGZr9bZmBuozD7/RlROq8+xzYIIYTSPROaGncSNr0KPUCRdDY7FR16gN7cTqAymMAjVPAMmIvHX3rpl5b++c9dgJALrl9gASYSsy+yIu4ErbXicPeGAPtI936ypUw16fM5HS4m0D+KZGYJgSUlljjAIoNFAKL8u2W/V36c/alGgEEIIQ0t//OJT69ra2uLRY0xNdGozmQyFZlC/kSjNRjxVqH+IqTWWlkRd0IkZl8EmAXXL7DspWsbDYBEXGG0CcXCW+3elGE/Ur6/gO37jgj2CYEMaUqEr57vE9SYB5/symbRxvR1RJehuD8WiWBbVvHXcV0XgehVhopMJ3qPXc6gGIMW2Dt37oyU/35dXZ2WRuTfqt4NgRFGGyMRVwC3LF3baGwWL9ZHvettjQXFmcb3BbxFUx76Eb45wP7ithBB7b8AlDYo5dOTywV9PJRCa019dTUViWTp1y6YfzLxaPQVT2XFC+vY29GBY1tobdjVuhdtDJaUSClxHYeI4yCEQFoWWusS4ZddgMlms0gpRegB0m1tbdIU1dsi47ylIKTxfYHgzKPe9bbGVbcs3msDxlfW2dJ1KlQhrwTireX7LyOaA0r6cFXKgOiVVuRyefJeAaUUiVicZCzGvOkzGFlfz2nHzCVfKHD01OmMaqjHGINAUJFIvKpTKnge2XweKSW+7/PIs8/gacX25maeWL2KvR0dbN61A89XFHyPWCRKxHFwHKfXbDaG7u5uWSgURHA5RlRHIvTxI5lwjHnr8IHQRivLjVT4Bc4GfmsDQmt9vAUGI968wa/iQzalP300mD77ylhBCoGQAs/3SaWzeL5PzI0wbuRIZk8+gtmTJ7Nw3nFUxpOMamh42VNQWr+q9BvXcXCd3oK7SxYsLK1/ineSymRobmtj9aYNrFr/Io899xw79u5hb3s7UggSyQRx1xU9PT1uLpczlmUVtR6N1oHtG44Aos/5iH736c0IoQVIpfXxwO9sAlPtdOMrIYyx3rTDYskx00/i63JJ37tuSYmvFN2ZNJ7vU1NRyYJj5jJt/ATOP+kUjp02HcvqKyvKVRFDOGKUiVdLvjrtsj+TFH9XiODXkvE4U+Jxpowdy2ULTgdg444d/OPpZazasJ7l69aybdcu/etf/zo9b9686Lhx4yLGGL9QKPglqR8a1EaERd2lO/Imff4hhDGW8ZUAcTpg7OlXvm0WlhxntDIl6+3NiP6Eb/oSviGQ9lIIcvk8bek0VYkkpx0zl3NOOJEFc+cxcdToPj+pjUZrgww9N/JVEvgrof9j6M9oJa9P6A2yLIvJY8YwecwYAJHKZMyyNasbJzeNvGbdmjWPffOb39y8cOFC98QTT4xJIaUqxhDK70fRgC+/L29GchBCGK0Mlhw3/cq3zRLT3/G2s4Xt3m887w1PhDAksT8dv7jPGIwpSmpIZTJk83kmjRrNRaecxoWnnMqx02eU/ZRBax1I4pDohwq0MZhgioU+DKOU6uzu7v5Tc3Pz/d/85jcfeWDPziUVFRVTbCG1Mjp83mWqT5ERSr/wJrQRwjaRxi+cI2Zcffn3hGV/Uvu+5s1kAB9Q4pvwv0GGXpyedBqlFCccOYuF847jmnMvoKGmBuglLCFlyc051GGMKXqN+rQ6VJ731xt+dtPI25b8fV5bR7uuqqyUjm2himqgKP0J6b7seofJtb86GCVtWxrlf19Me8fld0rbvlR7nnrTMMArEH+grgh60ml8X3HCrNl8+IpFnDf/5NL3lFKBm3GA1JpDCKO11lLK0rN9cesWbv7zn/jTkn/QlUlRlUxiWVYYsxC9xL4PE5T+DHMYJR3H0r7/ZzH1yrf91nKda94UDFDmwelD+KHEB7ClJJvLk8llOWn2HD74tis4/+RTSt/RSgU6/ZtK4pWglNbSklJAwAg//dMd3Ln072RyeaoqksGIR5HWS3pR3wFg2N+bgAFUwfudmHbV5S1CiMZgtpphzN4HkvrGhOqOwGhDZ08Po+sb+ODlV/DhK64sfUdp/aq9NMMd2miMNiVb4YlVz/Ffv/g5T7+whogTIRaNBKNBaSTofS0RyPBmAiOEEMaYPWL61W83ReNp2MLsT+r3SjJLSHoyaTDwiauu5rpLL6OuqrpcVz5EJ35oocOUiuL1/+3xx/jKz3/Chu07qK6sREhRMvr3ywTh9nCFkBIx7aq36TCZ5FCfz2tAWTaNMZSya4oqkAkMQSkFWmk6e7o5+ohpfPPjnyp5dZRS+7gX36ooebaEoLOnh6/9/CZ+f/992JYkEU/gKx+ELNOIgjQ9URQxJdtg2NGQEdOuettwOutelKs8/dyaYHAsm+50CikEH7787Xzm2vfh2DZK6yC6O4wl12BBaYUV2sr3Pv4oX/v5Tby0dQsNtXVBFJuiwA+Jvs9oMDzdpWLalcOQAQ6k8oQeHltKdre1cuy06fzXP3+C42fNBgJJ9ybw6gwqytXCtq5OvvWrX/DTO++gtqoK23ZQWh1YJRqGQmWYMYDp1XzKi01CXVaKIHmsq6eHa847n//4pw/RUFODrxT2YXXnNaHcKfCrv/6Zb/7qZjpTKWoqKvFLTAClqoXyAWAYMcLwYoADSn6DLS2yuRyu6/Cpq9/JR95+FdB3WD+M1wZjDEprbMti2ZrVfOnHP+S59S9RW1WNp/xe6d+vDoKyfUMdw0Mf6FORVVzvrYaypaSzpxvbkvz6hq/zkbdfha9U6OE4TPyvF0IIbMvCV4rjj5zFnd/9PxYcO5cdLbuxhEQUC3Moex7FL7+KrNehAFnKDR+qS9DBLPhXKgQP04q1xpaS9q5O5s2YyR//+9ucMGs2nu9jW9ZhQ3eAYFsWSimirssvv/w1PnXNtXSnezAmrHbTvUIJo3trDsJnN5SXoT0pWr+MzeKrAdAG27LY297GmcedwK+/+g1cx0FpjWMfbmU60LAsC2MMkUiEGz70UcaNaOILP/hfaiqrwopMEbQbCsszTVE9GuKVZ/ZQpv8i9nFzGoNjW+xpa+es40/klzd8rUT8b9Wg1sGAEAJjDJ5SvP+yyxFC8Ln/+x41VVUIDNqEsYFhxARDk1pCIof9E78dEv+Zxx/PL7/yNaKRCHpYEv9wED99IYTAsW18pbju0rfx35/4F9o7u8KQWO8zAnpHa2Co2gRDkGKK+llo8ELJ04PR2JZkb1sbZx5/PL/+yn8RdSNoY4apf39oSsVXg6JxHDDBp+jo7ARjQiYwfZighCHIBPaQk0L9XZ0m3DIay5LsbW/nrONP4Jc3fJ2I6wbEP0SH174IZaT2ENLCkA3JP+wSYaygGdAwYgrbsvB9P1SH4HPf/x7VVZVlSRKB6lNs4TIU1aGhZQS/jJ/fEhbdPSnOPC4g/qLaM3wkv8D4HoI8KtuCZXajs61o5WJXjMVEmhCyCmMkwho+RrxdUocuB+A/fvQDKpPJIHWimD8UFuEbIYYcew+dO30g4tcmLF5JMbq+gV9/9b96Jf+wIP5QqpsCws5SaN9CvnMj2c6VtG5fhijYjD3yLKINR2LsCTg1E8F4IOzwm0ONZPaFbVl4vs91l17Ott3NfPeWXzJmxEg85WOQYZFN2ReG0CgwNCjoZSS/EALP84hHovzg818k4rqlhLahjyLxeyDa6Nr5F7atuQ2VaSbf001nRwZPC/J7tqA2PEnn07eS2vAgCA8dqn/DpUt90Sb4zLvfywUnn0Z7V1eQflKMBYTG8VAzisXUt1966M+keGP6EX/o8KenJ82fvvd/zD9qzvBLY9YKZJ7cngd4ccXv6GrrZlT1BMZMGYtRaSytcSqq6XpxIzte2k60aTpjT7uayIhjCHsXlwTBUEfxPHP5PJd86mOs2rCe6opKlAlLLeXQS6A79JHgUrSwKCmKnc00loTunhSfeue1zD9qDv5wIv6Qmb1sB/nWZ0nt2khtfBSjq5qojTuY1m3ktq6ha8eLpNt3YSJx4qOm0DBxItmuF3h4yU9YvWEJvsohhEAPg5FACIHSmmgkwjc/+WmqEnE8rxB2NdVlo8HQiRYf2jmidHGYp4z+DYQ+/c6ubk6eczSfv+6f0GFS1nBBcbD38j1kWtbhRiRjx4xj0qSp1I4aSb5lN63r17N36yZat2+iauQIxsycSWVDBY7tsXPzs9z8i+9x75K7yOULSOSwYIJiQ7Fjp8/gPz/wEdo6O7GEBB3Yc327XHPIl0NnBB9A70cHw2g2m2N0YyM//uL1aK0P+VD5WlFUWSKJKqITZtO89nZ27FlJREWpq5tKcspcohWj0bZCNFWTze2mdesKclmLuslzufSq9/PC//4/vv7Dr1CIW1x4wgVEZQRtNHKIt28qGsXvuvBi1mxYz0133EZjXV2QoFgssDf09iE/hEbxob+T5Z0bwoQqAWRyOb72z59kRF0dBoaJ0VuEAQT4CksAuQxKpWjZs4H21u0obbArG3HjtUST1cQqqsj3tNKxdz2p9mZ0Zxdx5XPaKSeSNe189w/fYun2p8jqAlIMk5HAstDG8Nn3vZ+p48aTSmdCxjVl0n//E38cTByaXKDy1OZwu5jmbEtJa0cH15x/IeefcuqwLGYpGoPKS9Gxczntu55kwoQJ1FZcAlQgC1H2rlyCl9qOMppYSwMVYycy6bhzkXYNiWg9O1c9Qq6zgwmTG3nwhee5+b5baHjPaI6KTsburcYdspChPVBTWcXXP/4prvnCv2FMpKR9lEori1dyiEaBQ2AE96Y3l/L6w3UhIJPLMm5kE9d/6KPDLNDVi1LtuK2x3QyRuMHPZfF7FIloLdK26UrvJU0nBatATzaLjFYQqxxBpqeHXLYdOyKpra0EW2BXuLywbR3Ltiyn0+sOo6vDYBSQEqU1Zxx/Au+++BLaujqDfK1iOnu4HEqD+OBTV3HI6af3ow3CQC6f5ysf+QR11dXDUPUJISTGeEg7QfW4qVQk4mxf9RTt659iy/J78EWOiedeBtMWImadzoTzLidVyLJ1+f20Pf8Qu59fQsPYMTQecTxZEaemsZH6ERWsWv0YKb8tOMSQlv+9KHqGvvhPH2bKmHFks9ng3A+YL3Rwz+/geoHKvT7hYBAwfVCE3dndzeWnn8VFpy0IXJ7DUPoXn6AQGq07ye7ZjilotKco5FNkdY5u5bGmrYcVPYYn2/Os6ughA/jpNK7wwVLktOapdWvZ0bGHEaNrcWOa1vatdPsdJdXx0GvQrwwZpkZXJZP818c/RS6fK+0zReFXThMH2Tt00L1ABuhrAwTrSgXejY9d/c5hE/jZFwYQaO0jpc+e5/7EtpdWMnPOLCbPPYeejp1YjaNYtrWFe555EFNjozU89uxjXDXvZOYveDvp3S1UjR3Dyr07+eO9v8GtSjFywhiyhTQ96Rx7sh3oiqDj7dAn/wDFvqMLjzue4488iuVrV1NVURl0qKM4mh2aXKGDJ2L7h77LdEApgpreDy+6illTjhj23dqklKAVMp+joSqJqxV+LoNwozjJWnq0zc72LrZs3cmGlzaxe1sLiDhEqslFK2n14dHVT9LFLqYcVYeTyIDswbY0hUIOhRp+bmECm+CGj36MWCSCUn7Zu6bv60FMkziI6dDFdIdw3fQavvlCjjENDXzmPe8bvno/0Gv+SjCShnlX0tj1DO3P/YXOHcuI2nnadk9lxqRTeOdF72Tl2hdwsprTZxzFtKRg6/L7SUmPJ5/YxJrULqYdPw6vKkpnNo0jDbXxCDWOwUIxlPIYXw1kaBDPnXkkV55zLj//0x3U19aEDbcEAgnBPI4HNTZwcNKh+xdF9JP+PT0p/vVd7yUZjw/zssZQBcIDy0Gl2jFdHXgqjyMUMpdCpNoZn4wyun4Uk9wolU4FExpHkGl7gR2ik5XbN7Kxp5XEuGpEfZy2godruXi+R31VLVNrJ2IRTIY33MSEEEGv0Q+9/Spuu/9veJ6PtEJHpAh1//7t2AeZPg+uGOlV+YFA98vmcoxrGsm7LroEM2yKW14eEtDpl9j46E3UVEapHXsULSaBn+9h3IRJ5Fr20LZjCZVeG50IVnaOQlUleCzbyiZyJKZPQFc45BS4Ko6XtbDSWUTUpSOjqK4MbYBh1o2wGBuYPHYcV5x1Lj//021B20Wjg6J6oI8toAd/FBh8UVue8hByQK/6I0hns1z3tiuorarq7UT8JoAptJPau51Ux16caJymsVNpnHosbsM4Up1ddOxajyv2YuIdPLP3Wf689hFWFXrINlZQSFgUlIfOF4hqh0jeZUL9Ediqkl/edjsvtGxFhZPbDQdPUDmECIJ4H73qauqqqvH80BYwZdLRHDzF/KDoGiXdv9+FeZ5HfVUV77zwYiBoV/1mgUhMYercRYwYMY3Orc+xa/Xd7HrmdtJbV1Izdgw1x5zEWqeGR3s8VuY063IZcgkbN+Fg8mlclSWBws6lsb0Cp8w+k3df8HHWbtvIF3/w76zPbEQJgzDDS2BIKVFKMXHMGM484US6Uz1BspzpFYwH0791ECPBmpLj3wQFLT3pHhbMO46aysphVOTyytDaRzgJKqfMRMRj7Nq5iUy+lbzpYFvXVnZbedYUfP62bQ9PtWfYiQU19SjHpeBrHMvCEQ6yYENGcOpRp7BwyulMr5zOuMkTuf/J+/jZHTfRTju+UMDwGgmKo/xlZ5wVtlN5mQjwIEeHBzcXqNTahPLRDQz4WpGIxfjEO99d8hAMewQ2MMIUyLQ8QW73MioSBtnQRMqPkTJpVu7eyvoNG+j0DZ4VQScq8KXG8iJBopuTxZc+mZQhRg2nHHUm58x+Ow4NaKOZUDuGkZMnsPSppSw44SROn3wmSZksHXs4wJISYwznnXIqpxw7jydXrSSZKJ+eKbQGStmiDNq1DXokuNQnxvTmgwsE6XSaIycfwawpR2CGud8/QNFg89AmzcYXl/PSxhV0yjxy6lSWtHbx6xWreaxlLy9kOtlrCzKJCjLCpaAdjHaIWDEsHSHTAZXuWObPuYxLjvogccZjmwQ2Eo1HrDKKiMOytU+RJR8cfphNcVIUeBcvOJ10Nhd0kigJ+5Bw+mwz8ItGD54XqCzNuT8EBJ0ELrucUj/6N4H6U3RNWraNU1dNc6vLshWrWK8Nq5ubUbEqYvE4tmUhYw5pVUDoCPFoAl/nSafaiWiLKfUzOP2ERRxRdRqWqUWjEcKQFmm2ZjbjixRNk8axo307O1M7qa+sC8Xl8BkGiqPAxQtP5we/u4W2rk5c1w1ofXAvJWgyK4TEkvIguEFD6R+uCiDvFRhZ38Dpx58YTEU6+CcxqAgIPxi48yZPT76NZ/c2s2TtC2zyMjRHIzjVSWxXooUDnofl+UhXYnwfk1OgC2hPM37kkVx1+nsYFZuHRSUGDVoipOLJTQ+y9qXHmDq9kUhc096xh858Z+kshhOKSXINNbUsmHccv/7rn6mLRHprwUPiN2887a9X3hsjkVIK27JM0Fh5zaAawaZ82wRGsBCQzqQ5+ehjqKuuHtauz2B01ggj8PFIkeHOl5byqd/+iO8/9CBr/CyZqiQ6GgPbQqLJ+D2YmMAXBqMMcST5tlYqjMuxU4/nmtM/wtjYaSHx985kv71zDX+576dUxtI01hpS2T1EKh0qKioCBhyGt7DY3v6CU09DgjZaK2O0Ct+hTIfmNRjDGmMUwe/4gEAKKWxpC9uSUtKSiERuPWv+yWeuW3zn2YMzAhxA/QkuK/BfX3DaAiCYqXC4jQDBaFacVFqiyPPQpr9z97K/88RLz7M73Ul1lU3ESuIZiROJ4xdy2FGwXEFBZYnrKLrDJxKr4tTZp3DUjBns3LGDjq4uvFgBgUZigfDY0rmWW+77Djqyh6mTG2nJ9GAZTVP9KCqcJGUz+w4rWOF8zCfOOZoJY8fKPZ0duI5b5g4VIIwxCPUKV9dLx1LK3uldAaWzlhBbYm70mVFNTX//5KIrHjn7xAW7w+/EBycVwvR6e4BS0bswQY+f+uoaTjl2LsCwM35LUllIChg2pXex+OHfcc/ye9idasaK2SSrHCxb4vsWUkbwCwpjC6QTQekUXiaDKNjMGXEMpx51DmfMPoe41Pxm9Q94aPO9TLh8HHXOFAx5ntp6Hw88dSvtej3JsZCVXUjbISYiTB81nWpdFejT4kDKwtBljlAN0hXxhPzwpZf//gs/+N9cZeOIGTkvP9kI2RDkA0khLNsun4mmP4zyw8sU2Eastxx7d1U8+VgiEd+x4Ljjln3x3e/fBbQDDhDf2d5eE40aUxevG0QjODi1Xoue3p4xs6dMoSKeGPIVX8XaW9Hb3w9MENJvTbWzdMvT/Oru37Fq63PYNRbRuiTaFNCqQMG3AIHQPtFIHMeOIHsUOgcTqsZy0oyTuPKkdzEmPglLOeRNO1VVCdZsXsn6jvXk6mwee/FhHn/yz/iymYpGgZZ5BBHIwZjEaI5smEq9U4lHFt/4RElihEH2GVNFyUYZihBghBBcc8FF6f/32c9f/7UPfTp57/MrGjqVqqhIJrN7uzsat7a3zbeEMcYIIYQIxaowSJAGf+7MmX+LRZN5YRn57gsu2T5z4sS28Oc1EAecTbt2NUaiUVMTjerRtbWqLdMmd7a3D0ITygOksgZSEwqex0ULTsd1HHylhqT6U6xHKHVfMKGhKwRaGFpy7fzoth9y2yO3kxEFqkbWI2Iu3ekUWkoiERfhCpT2cG2BJTRee4GE73Lq1IWcP/9M5k9cgGMiWMYBS+CrHvZkN5GO5/jTpvvJb7iLbZs2Eo8oqiIxPC9DVMbxchYJXcEZ0xdwzIjpbOx4nFU7VjJl5Azm1J8MJh5WpBVVNEPRzTBExwIJYEUiF531jnfc8rcVT6TmTJvWPmXUqJ1jRo9WU4477gXgPoqGbK+yX4Qg6DBcvLTIzvb2GoB8LieaqqtVPB43TdXVqiOXk82dndakeNyvi9f1EMcfhHTocv2/PLwdJDy5tmTukbOCMx+ClpsxBoWmM9tNa2cbNfEqaqtqcbDo9lOs2LGKn93yK55c8yh+Mo9bFaOgc5i8TyQSJackGa9Awo3gShuTKuBnM0wfeQQXn3ghFx59AVVOLZ7O4xkPy4rQodt5dPODLN+8nC4LNq3vJOdnqYq7RJ0IWkLUjaFTOaxCjONmnMLC2aeRSbey5Lk7eH7bM6zdPpI9MzZz8sRLsanEFVFA0W42oZVNnT0eg4UYYmnUUgbt4iKRSNP8+fNH/f73v189cuTIaE8+L3ekUv7a9t0Rx0kmKyoqTLKiQruRiAGIhq8AVZFIKYoai8VMTTSqAZpzOasjl5MduRyja2sL8Xg8A/hA1XVf+eJJazZvPn9Q7oYp/e1dBIJsPse4kaM4csoRwBDU/03AlLu8dr564zd5bs3znDT/RM5YcCoTx43n8RVPcvMtv2Tz7h1EG2J4bgE3JrBcgWc8jDBoqUFY6Jyguy3FKLeGt59yEecefxazGufgax+MwJFRoEArnfx+xW3cs/xXdIqdRCqq8VWcaCRCLOIgVAG0Id3jkZRx5s1cyMI5l9LW1czDT9/Lls41yNo0OzKrueuZXexq287JR52D59ls3PESL+x4np7uLhbMOZOFky7CmCRCDC0m0ForKaWcNWvW3GeffXbZnDlz6rK+r1KplLETCVPf4PqO1iWCj0YiJhKNlrZzIPK5XFGa6rq6ugLApHi8g2BkkHc9ubTpx7+/9aL27u6jOnu6z/aVmiEsOcD1AP2Lm8sWgaCQ95g9ZSrxaHQIlj0Gkr/F6+JbP/8+dzx4F9GKGL+/7zb+8fTfGdFQR/Oe3bR2dhEbkSRvF9C2RUFrHGnwcjm0gngsSTpVwMtoTp+9gAuPPYOL5pxNjBhaG2zpYIAd3m5e6HqRux+5h+XrlpGz20g2xlFKELMjGOODD34O2lJZpo2ewNnzzuXIkcezvW0Hf192D1v3rMJUpiGqiUYt/EwXK9YvoblzF6msYU97K8opkM6k6VzWTjxewQlN56AMWEOICUI7UNTU1MypGzOmfnJjY8fkceOyM8dM8xLj6w3JpAYU/eO4AUTZexqI/fnvf29saWtz71j64OWZXL6hvavzLM/zphtLNgZzNGjQxhjl60HJBdq3/sXgSEk2n2P21GkApflnhwKKk257QvG9n/wvt951O4nGKnxX4xhBS0cLzXt2EI1FSNYkyEofTyssy8UzAs/TJOIJ/IJHz85Wxo6YwIK5p/LB865jQmw0QhsQEimhOdvK5kILv1/6O1ZseJLunlYScYeGqlr8TAplJHbMxnYk2Y4sFfE65h51BmfOOpeGWCMr1j/NQ8/dQ3NmC1a1B6YAPT6WpYnYNjqa4cXmZ5GyCuXaaNdHOpJNuzdz55I/UXXGOKbWzQZr6NgE2hhLCkHGK5y1w3jH3XDn7Y9LR+aEtEVVPP70iIbGF31fOW7EVQBCSiOEMBolo240t2nHtlMyeW+iMDrvK9WU97zjjDECKSvKi2qM52uE0AR2h0QM6kwMpkwVClIfErE40yZOAoaY/h+qPrlslnw6aNuRyWZwHAfLkVixCJFkHGEU6XQPKmaBI/GUpiJSja0NqeYuokayYOp8Lj/ncs6cejrVpgqjDNKy6NEZtqd2c8uDt/LUC0+zK7UVE8tTWRNFWhZp3yci40SEQ6FHYaTN2IYpnDbzVM4/6mLqGcUTm5/gzw89yJaul4iPttC+j6MtEnaMXDZFdz5NZUUVxoFsIYuMxOjJZkHYpLOGrm6PQsbH1JreCx8CLBDMn2FIxuNmwthxVZt37zw/KmMYVSDT7V3W3NMVuEBLRfNllUDhsyNstNVneibfVwhhgmobIREiIPwyDLARbPrq/6Z33WiDbUlmHxHo/0OJAYrnUhlJ8sWPf5bkqCpuvf9O0oUCRmiEpzBKo9G4wsI3Fvl8AWk7SC3xugpUm1pOnXEcn7rmo0yumgg6aAeuMewstPC7x2/jweVL2LZ3B8r2SCQEjmtjWTYFJJYUGCnIdWaojdYxdfQMLpp/Hic1nkzSVKLRTKibzGknnUXPM13sbN9OtMIF2yIrLYypQOsI3d3BU/C1BxqyBfCzhkmjj+Gdp1/HnNHzgrkHGAqkH6BYKllbVS1GNdSbdRvX65jjoI1BSEng/RR94wBl6yYwMoukJ0puLxGOc6WU0n0xiMlwpVNDIsgUssyYNJmqisoho//rsENZb+RQMCLewMev/RjbUi3cef9dJIhSGYthvAJKG4wUKG1wLReURa41zehoI+++5B1cdcpl1DlVYXxD0Op38NTWZdz819+wets6fFdDTGJFLEzEwtMGrQSWY+P1ZBDKYu7kEznvuEsZWVvD5g0vkq7qJhFPIo1kZMUoLj3qCo6YMJm7n/wrT6x6nC6RI5IUGEdgWTHy2SyWbQGanlQKTZyorOS8hVcwd/RJeMbHFjbFxL2hEiMwYYe442fPEQ888bjVp86nGIZhP6/98RovZeCM4H4GcHk2hBSCQsFjZH0DlclkQCBDgAGkkP2m7gnOd+22NWzctBHHdRG2S3c2iyUhGo3hKx9fKSKRKOnONGPrR/DZaz/OWUctoFL2Bvee3/Eitz39V25/8Da6dQex+hjSNuAatAV5aSOIozN5HJNjUvUILjr2HE6cfg5Tq2aRopWlu+/kj607uPbM91NtBfUAUZPg2MqTGXPaOBpjI7l35f3s6m7GqXLIZbIk3Qg675PTPtgxjO+ST3ms27SZ00ZmaJTVfe7BoX8KAQJlTHDE+PEopXq7x2HAiL6fG8Bi+UEIhAUvAkpd30xpnxgwfnuj0EBnqot0Jo3rOERjUaLRCM35Pdz4m5/y/No1ROuS4FpoY4GAXMFDSIEtXTp3djB9/BRu+Of/4NwppyFC3VNJwcrm9fzPLd9n6aqlkNDUjKhCRgx5P4fyg2Fd530KXVkaqxo4Y+7JLJw+j7PHLQgivVqhRQoTTbN81UrOPflsKhJVWLhoESTfNbpjufbU91M3fhw/vfcX7GzfiVPhksprhJTkpYMxNtpAPpvhL/+4i8kjxnPxtHPIelkcO4oWYHyPpB0nSuRQPxIAtNKl+QRKJoopI6pi4cMAce6AMoDZZz3UNYXA9xUXLjg98Fkd0gS4gCFzQvHrB+9gxepnGd3YQKIiRl1DDSvWPMtjzzxFvCaJcS0yuTSOE0X7GjTYSDI9aWaOn87XPvYlzppyIlpphCXJkOfuZ/7Ot2/+P7a078CqihBN2MHkFuk8EccFxyKTypHPZJg79WjOmXM+i054OzUketVGqTAqTY+3G092sW7HM4ycMoEKq46gmYBEC43ru5w97mzExXH+359vZGfnVty4ha8VyrFIZ3I4dhQrYdOd6uZX99/CC80vEnNitOxpJ9Xew8iqRi5feDGzq6Zj27IkiQ82ijGhBccfz6gRjXSn0jiuM+jHHUAjuFwF0mXDlwmrGzSRg3BBrwQTeg1WbVjLb/96K8++8Bz19XUor4CvCrhxh0gyipEqSNXQIJQGpYnZMVJtXUwdO4Gvf+I/OHPyiRilkZak3aT53T/u4Ps//QFdqododRTf8sCS5I3Gtm2EsMnsTVNXWc15p5/J2067lJkVM4kaF0M4CYgxCDx2dKylJ9WOlIrOrr3k81kq4iBE4DoWSAo6R9KLceGoc+ASmx/c+kN2d27DqrDx/AKWkKiCj9QOnmVYtekF1m/dBtpQ8Dz8dIGGWC2xSJTpF03BJhLeoEP3fBzbwRKCYjp06XT6n9MANc4aBCN4PwxlDFobCoXCwB/uNaBo8KayWf56793s6m4lPqYOHbFxsBF5iZCCgiqgtI8RkqjtInxDREbw2lJMrhvFFz/4ac6cfFJJ8neYDDf/4za+deP3UBSoqo7jmxzCK+B5Gjtega8FqdY0syZO49KTzuNd868mSTxUcQO5a4xCCp+O7AaeXLMU42mS8RhCB14oAOVnkNJFSpu4G9QMRDWcN3oh/kU+P77zRrZ3bsVKSIz28AqavNYUPIGIRskqEDaIiEU8WUmmJ8ez61eyMb2FI+NTD7lRYMrTZw6Cl3ZgNJGXHUQC4o9HojTW1QGH1gVqjCGnPVauXEnzlp04xgIkab+AcSSWK9EoHMtCWgKlfRCCbHea6kgVH3/PRzl/zllobZCWJEuBPzz8V3740x+TF4pETUXAPFohjcTWNlYGrG7DZadczNf+6XreN//dJE0cY3RI/DpMFvRJm63c/dwv2NS8BjeqcWxBMp7EjQQ6utIFtPbCYpKAKYyEuJacN/U03rbgYiJelHxKk8lqfCPwjcTTBt8IPKPJexpPWSht0dOdZeOLm3nm6RV4ygMT+tIPIUyfVzOo9c4D4wU6QAqE0WEKhFegqa6eE+YcAxy63p9CBA9Xez7XLLqaZGM1S599jHQmH6gsKoc2HpYQ+FrhWwLbiaIK4Bc0F19wMZeddgm2tkGAr32e3LyCH938Y7oLPcSrY+QLGRwJhYIiGo0geqDWreac+Qv56GUfoMGtCyaMk4agK41GYCEEbM+9yENrf8PyLf/ASRikdqmIjGDCiEnE3QTGgO1WYFGMoPfeRy00Cc/i7XMvZPVLq/nzigehNoHv+2hPoTVo7SF9iVAWubxPPltg+uipnHHUiUxvmoYlrLAG5RAOA31yPsMhQBNm9Az84QYxGa4vlNH4vr+fdw4uhBDUV9XwzvMuY+6cOTy2dgV3PHw3j69ehhUNCFtohbGCwIv2Fd0tXVxw8rm874prSRJDobCExYu7N/GDX/yYlrbduFURlJ/DckTgJnVjZNqyTBs7mQ9c+l4uOvYc6pxatNGIcL5cE/ZG9Snw7K7HeWLLPSxb+wAV9RrbjpJr1cyeMJMZjfOwcBACNBl6sh14fgqETWVyNDYRtDH4ymNEtI6rzryc9c1bWde6OYj8a40tbAoFD2EMlmeYWDeGY2Yew6KTLmDB5HkkcHp9dEPCN3pgyTyQmpE9MA2VTL+/pvSvfAqcoRD8gmAEMsYwfeREpo+cyKhJo9n1rR28sPUlKqqTIAXGVzi2Q6q9h3F1o7n49PM4onY8WmssadHppbj98Xt4bOVTxCtchAsZVUBj40ajpJq7mTZyMh+56gO87cQLiMsYKmwIZrRBShlI/fR6ntm6nNv+fgudahd1TS4ITarNMKFmGqfPvoKYaMQzCkOOp1/6Ow8+81fyhQ5GjR3JwuPfwRHJE9BCE4smMMZwyqjjOGvOfLbdvZmcbfCkxPf8oP+y9tF5xRnz5vNvV3yMJqrwlIeWoftxCKCXYop2wOCpZAcnJXCoOP/LIYJIsK98HA1JJ46tBNrTKO0TjcaCStSM4fQzTuGCE85CaB2kNxjNut2b+d1fb0dHDE5EkPVyCDvQ+9r3tDFt5BQ++4F/4eJjzsE2EqVVIABMkP2YNu2s2/IsP7/7lzy7YRWROptojUtnp0FZcY6bfBwXH3MVE6qPwRiJIyxWb3+Ku564g9bcdoTtsf7pTbR12/zTxRNoskaXoqkR7XLJCRfwxKqnWb7peayKKAXjIR0LjcJojattYtqmgIct5ZAh/hL2MYLDgFgfGfrGx4IBY4B9aNyUeLh3cwigmP4QGJ0CrQ3rX1hP89adxKwYtnDxpYVRgmxPlqbqRk6afRxNkbpSU6/OXIrb77uT1kwHdtIhlU8jLQvHdkj3ZKhL1PCRaz/AeUctxDIChUKKoABcY3j8xcdYsvJv/OWBP9GcaSc5oho7UkFnV55kTSPHzTyFhVPPYGL1CXi6gC0lGEFBeqhInp3btpNIJOhoy9Gycy+elw/K7Uq554KpVVM4Ydo8ntm4jmy+gBVxUVpTkBLLdmjZu4d21cUEuwlhBMoEDCqEHAIaUF+9pE+6Rrn7cwB0oQEygvuu77eDxVCA2U/6gw2bNq6nfe9eolUJdF7haQ/Py5JuT3Ha6cdzzklnIowpReS3dTTz0GP/QMnApnEcB60NZBVWTvDBa9/HouMvLk1sbcnAaF21ax1Prn2S39z6C9ZuW4dV7xBvqKAQt9mbSTOqfgTHzjuFi4+/iokEWbOOdEtq5ISGqZw88xx6WjLs2LWLMbWTOfvUMxkTrSNgrSAPzBhN1DicesxC7njqIZ5vfonqWASv4OMbsCybDTs2s7ujhcmNo8L7MTRS04H+bqBBpZ+DVBVx6DmgGANIexma9zbTsncPGZVnS/N2nnxmGcYo8tk0xhNoIRBaUhFJMG3sVEYkGgK3p5SkcmmWLF9Kc2cLJhb0WsIIpJGkWru59JyLee+ZV1MlEyijsKRFmgL/eP4R/vfX/8czzy8nWR2lceZY8jGDjkqciji2JXErKujJ5Lhn+f1Mqz2CumgdTdWjqE/U4WBRYzdx5vQrmD36eLZu34xTDRXVMZ7Y9CD1VaOprxpPrdWEDINl40dNZfy46axt2YJf8DBa4dpRLFeyu2MPtz54J63HdlBrV1DlxBk/chwVbgVyKCQrHiSSGaBIcP8kiP2IfjMw5vbrhTaaTXu3cttdd/Dc6lXsTXex+sUXyeWyJJJRLNcB4+MKF8eyyeRyjKgbwXFHH4fUlHzjHel2nnjmSXzjYWOwsNBKkG/PMHvyHD709g8wOtZYSorbkW/mtw8t5he3/ZKUSTF27ngSVXFEVOJbmoIIRhzf99jTvosle/ZgMpqYjDBh1ETGjZ/E7EmzmTfyWJpiDcQjVUyIVDGhfiobUk9w14O3sW3XFpxEkuOPXsipU86nIT4WgJGygnlHHMOSp5YgsgUc2+DaAq00aS/Drff9iTvu/yt1yVqOGDORmZNmcv78Mzl29Ayi4lBG7Q+kOgw8BR20ujghxCGtAbakxbqNG7jp5pvZ0bybeFMtnjTIuEMWH0sa4k4EpTQChZfJUjWugulTj0BKiQ6bufq2z+Zd2/C0IipddN7HJkaVW815x53N3HGzg9FGStZ3b+Snd/+CO/7xV5Kjk9Q31lOwPNK6gNEFbB+kHXYotkChyUmFtAU5VaC19VmW7V3J3c/cy/SR07h8/qUc1TiTyZUTaMm9yCMr7mPd+hU4CZu9ba38+f7baEqOpmpcAxEnRhQYVzOKGqeSrlwrTlxAIQ8GfEegJfiWYGuulc0rd/Pgw49QEU0yb+ysgxKFHQo4KAwgRNAQK5VOk4zHD8Yh94uKikpqRjbS6mepqq8n5efI5jPYUmDbhnw+h0RiWS5SSEY2NlGVrCxdg8GwtXkH6UIGJUKXpgfpzi7OPeFszpx3GjEcfO3zUvsmbrr3F9z35P3UT65FJAQ9uoe80ORtRUzaiIJC+wrhWNiWjfYNPhppg5ESaVlorUjlszy36znW/+EFFsw5lfeccRU1MU0qk6GjOwMZSTqnsJH4nodlBYJGG011NEZDdT1dzZ0YIcj7BYQUWLYEKbAiDolEEt/OY/xsn1ln3go8MChGcOnVgNEG13bYtWcPj6xYzqLzLjhk9cD5fJ58Jkdqbzs+JujPaYMbsdEiSMWVlkSaIOhYW1tLRSwJBAyQ93Ps2LmdnlQXSvnkUjlsZWEXBCMr6zl6+iyMMOzu3sv//vJH/GXZPdRPbaAgC1gChKNQlsYXhpxWCDscETUorUDIIFU67D+ktaJg8jhxG7cySnd7ir8+dxcvtq3i3WdcxtwTF5AqwMoVq2msrOXc089l3hEnIKUHxkIKyYi6amoqqvB3S6R0AwYLm2f5vk863YWlLFRLN/G8hfAUwgSdLQ4Z+mtAw94ILnmwDp0VoLRiyrgJXHL+xdTXN1JAkcrmaG5tppBL49uaeDyGNoZsvgBCEItEscuqx/P5Ajt37iKdyqCNQQtNLl1g/IixHD1jJnHHpdNL86vbf8sf77wdOcolk80gLIP0wU04SCFxHBtjBFkjiESiSGUwygvTIkAYjfE9bNvGtWIU8j75nEc0VoGyfdZu2cFP71jMh694L1de8lHOnNOO8jSzJ88iJiOAQeMjsahwokgM2YKHbSLYbgLjF9AZjworjrENoxtHkqh1mD5iPCfOOBZLS7AOjfQv0Uh5FdggYlCMYNFnEC1VNRBx3QE41uuDFJIJDWP48JXv4fKzLiRf8OjpSdHjZXho2UPced+d5H0fISUFo5G2HVSEldoKCJTvk+pO43uBnh5zYnSmW2iaWcfJ809Ca83Dzz7Cj39xI07cxXGjdHZ0UxevQSpBpiuPk4gRTThgRyloQ7ong/QUESlwpEFaYDsS13aDmm4PknYFShl8T2G5SaobKmlp7WHxfQ8w4ooZnDRhfuk6i3dbhwk1rmMRi7lBtzgtQYHJKOZMnM01511Ok1NLTEnqEzXUVVTTVNNYStU4FHAdByllKRbciwEsAyvDgI0A+5yeAExvDZiUgvVbNpfeOtgQQmBjMb5xDOMbx/R575ijZ/Hc2udYvmo5NY11WFGHQt7DL/TVgqW0iEUSWNgIpQNVyQiUKhCrjfDUxhX81//+F2kvRdKtxFECiyip1gxVTdVYAshqRC5HLtNNLJJkZKKaiooEWilS2R7S+RQF28dKWCg7yOdXKh8EqRyBlhnyRuHW2LzQ8hJ/euwOJp03iianMXC7CqsscCTBtqmIJomF7dnzbZ1UGJeLjjmNa4+5mAoOnVAqR9FNvXXXTnrSKewwdhI0gNh/MfxAYED7Au3PGQph0pe0ePTpp/nM+z94yHzMhqA7RTFlwBiwpaTeraKpthE3EsEzCtuJ4lMglUrjKx+swCXo2g51VbU4tks6k0HZBaQdRFE3tW/l3if/xlOrltPQ1IhWPuQEjuPiC0W6q0CiMoZJ5/F7Msw9YiYL55/KtNFTqYs1kvMLtBe6Wbt3PQ8+/Q82tGwiWhcHV5HOZYhGHGxLkvfSCCkwERcdU6x4cRkvzl9PdW1VKfAmhSyNwemeLO0texH5PFbeQHc3I6rGMKdxCglloYVGhzk3QT9UcUieT7FN/oo1q9nT3k5TQyO+0b30vj+VaEAKYgYxDFAaFUxwgfFD6AGCQJKUD+/aBNFTF4eFx5/KmvVr2dm5B5Vw8IWhpbWFvF8AKwaA47rU1zcQiUYha9AqhxEeVtzh/qX/4PY//5l4RRIpbYQUKAxCK1zLxvIFVlqi05JFF1zN5SddyKTacVSIyj79Oo8bOZcj62Zwx7P38OSa5cSqIkQrouT9LD4Ky4ogrUDLd5NRuruz/OWJ+5h57kyibqRMZQsYPtXRQU9HJyrvITMCmZdMmzCdyeMmY6RAIrCHUB5QIhbvZeCSBh3mAQ0CDs48wcaQiMZYuXYNu/fsKeXlH3KY4N4m4gnmzTmGqOWgfY3tOihhaO3cy+69uwHQWmNbNpOmTEaaYEI3yxZIB3a1NfOPx5eye+8eLMfFhCWHOqi1QXk+ZBWqLcu5J5zNP537fo6uO5pKahHGLs2UYoyhQdRy/tjT+ejp72dMbBSZ3RlUVuPlNX5BgLbwcwZV0BilSReyrN+5hU6TDsheBPXkReRTKTKpHnzPw/gGxzhMGD+ZifUTsEJCGwrPojjqPPjoI1hWWTuf4N2+nx3A4w7MFEmlxkP7WwJJZNsW7V2dpHOZIcEAxUitkYInVj/JT391E209nbjxCL4qYFuSdDbN82ueRylVaiYVJ0JTdSOudtDKxo3EyGTTtHe0YbsC4QRGtBKCfEGRzuSwLRuVzxN3XC5ZcCFj3Sa01mgRVoQVh3cRBMN8rZhWMZGz5p2K6s6TaunGyoPOemQ7M3hpDz+nSKcyZDM52traWbt1LQVdCDtvBOeqlWJ3+x66Cil8ocGxsCI2y59Zzo/vupmtXbuDJL0h0K2jSNS79rSEzGDK0qCLfa8GfhmkEWBfhU1KSSaXZcmTTwK9k08cbBQnYZNS8tKuTXz7lu/x2W/+O3c+cDfduR6UUKAUEdehubmZ1eueR1pWyRCrTlQy/+jjiGCTyyk8beFEIlRWxrFtgxA6KHqxbAo+KA1eoUB3eyezZ85kXP1IikJDEhBf+T8pBHbog587dTbjGkYiCwaTVeicCnz2OY3OaXQeMBbdXSladrbgFbziRQbBR+Hz3IY1tKa7iFbGUULhJmKs3biOb934Xb5y07d4dOMzpEVhMFPuXxGltJHmZp5f/yKJWLQUeR9sc2SQVaDe/G0pBEop9rS1HTLpXzxuwStw219u59+/8R98+0ff4alnl+EkXdx4BMuygma2SpFLp1n74jp2tO9GyiCXv76mjjNOOoWIcIEoOU+TyWZxXIuq6gS5fBopTNBGRQksY4FvQEPEdiCvwlY3B74HBoNlJBI7KE/UIIWNMBYGiW07WDhY2sa2XIyWFPJe0PUYKN70vfl21mxfT1c2QyQaQSsPT/tYyRgZUWDxvbfzz//5Cb5/y4/Y1rrjkKtDPekeetKpQAXqQ/iDxwUDP1F2eLLldQwQ9AKKRaIsXfZk4JIczL68L4NA/dJs3LaZJUv+joeicVwTWgZNbIU2mJxHdTxBPBZl/eaN3PPQfcHEGVphCckRTRM5cvJMtAIpXVLpFLlChsameqJRC6ULGK0RRqPzCsvY1FZUs2rFKl7ctYnipKr7Sw80xoRz5ArWbV/Pzta9SMfBCAspbbQOjimwgtpgLbBsm2gsirRkr9KpNX9/6lFe2r4VN+Kis3liwsFojXRsIlUJknWVrHnpBR5d9ijEg3l7D0VPoKI28PDy5aTSGSxphfUjooy2xL50NgD0OqAjQL8ug333anAdl807drCjuTn4zEGWNkXbIxKJcsXll3PMvLlks3l8H3zP0NnaQaE7i8wruvd2ELUjdLR38PjK5ezq2Vsy1MY2jebyt12G1KCURmtBTzqFE3UY0VSH0h6W1EQtic4WyHdn0R4072nl7qUP0Ox1BT3xwxQIbTQqLNSROmiS+1zPev669D6UY7ASLjk/jxECiY1XUCg/aHpc8HyisQgjRtTjOE7ozpS0mTQPPf0ELXtbqYjEoTMLnTm8VJ5UTw/K88nl8kw5Ygpnnn4WNW5VH/fpwURxKqqnn1+FbVmB46dETYPLkIM2T3BY9k2vIaxxXYfmvS28sGkjQMmwPNgwxjBh1HguOOcCotoh1dJF0k0yun40Z5x8Ou+7+j0cd+Qx4Hn4eY+Hn3iMx9atKGWFxmNx5h99PEcdORvbCKSW7G1po+B5NI0dRW1jFelcN76XJ+q66LyikPMx0uJvf7+f7/3uh7zYsw0tDZYMcnassGIsb8H92x/n+3/8MWu3r0dWOORUHiWCloeWEFgEnRuMtDBKkYhEGdPUhCudsLeWYfn653lh20ZyqSzj68fwoSvfy9sWXsCUUeNpqKxDpX0ybWmmTTyCyy+4jAonqCc+FBMOSylRSrFy3ZpwtvhiRRWAQYjQIH5ZZ8vrWwZODwm7mvXbGbZnJzAHhMAgeODRhzlz/kmHRt8sOhgUXH3pO9DKsLeznYWnLKQ2UYUjJCMbR9Ce7eTf/v1zLH3sMZpbWvjd7X9k3oxjGV/RAEYzdewEPnTtu/jCl9fSme3EB1r2tjN+8jjGz5hAzs/TuaeDylg1jnQxmiDHiAK/u/sPbN+7hZNmzGPymClU1dSCMezu2svmjp08uOxB1u/YgKyyyOoMPj5Rx0EqBb6Pg8BzBMoYbCMZ19DE+KoxBM21DJ35Lv5y712sXbmaGeMm88l3f5CzZp1CKpWiq5AlK32eXruSVHsXR8+YzUi3vs/tOZhQWmNJydPPr2LLjh3EYrEwnVyUTsiUnddAn9+gTpBRTIcovmqtiUWj/P2Jx8kXCkQikYPeKl2EhrmUksZ4LR98+3UoraiOV/T5XFNlI1/63H/y+Rv+g0efXsZDDz3EX0+5h49deh1a+cScKGfOmc81l1zKjb/5FTg2HR0Z3NY26kdUc8TRU9m9aTet29rJ5T1cJ4axw+u089z/+IM8s/ZZxo2bgBuJYTsObZ3t7Ni7AxET2JU2ylaBQFYKv2CwhIMjZTj3gI3KayqEy7knnkqFSJayWR94cgn33HMPtfEqPv7eD3PpcedSYSUg2Vi6vmNHz0D5PlEngqVFSUAdbBSF4H2PLCWTy5JMJlEmbARU4oHBNIIHGOXBC7Gf/RHHYffePWzfvfsVvSGDCSGCKGhFNE51vAKjDVrrwOevNVprTph6LF/98lc5ft5csj1pbv7FzTy67ilsyyafSzOyqob3ve19nHbMfHKtWSwTo6srQ1tXFzLuMnbqBEaMH0m8IoFCUfA9lPbRwsOqdGjze3jmpVU8tvIxHnvmcba0bEXGAMeQLaTIexm08YKR1RYI20ILiRIS5Ql0znDqrONYMP14hBFIS/L0xmf5xW9+heXDFz7xGS4/+UIqZAKlFUrrUlOAuHCpcOI4WId0rubi5BirX3oJx3b70EM/d0r5twbs+LLUhnEgl2LYwvTR5NAGbNuhvbOLe5f+Azh0dkAR2pjgHKRASollBQQhpQRjmH/EXP7vO9/nsksu4fnHn+J3t/yW9lQHjhulUCgwbcJUPvvRf2X6hOl07uog056lo6OHlj2t9GRSjBjTxMSpE6muryYSc7Bdi1S2h450BxmTx3MVVtKFmKQgCmT9LJlcCl97CGHQSmFZEsuyUcbga4OUEbJdeZqqRvDOc69mlDUOSwi2dezghz/7Me1tHXzlP77ENWddRl0s6B9qSQtLylJ3ivLo8yG796H6s6O5mSeffYZELB40FzCBqmzC9IciXWF6aWqgaHXQjOBe0g/XQiNGGU0k4nLf0iV4vn/IJ8qQxQSw/bxnBAitmds0na98/Av888c+yZ233cl3vv89POXjuEmM0ZxwzIl840tfZ3rTZDLNPehuTb4zR0drB+0d7eS8LLFklIamehpH1NPYOIJkZRLHEbiug+s6WI5A2OBEI8QrkkQiERzLwXEiSGFjGQdLRDDGJtOZZWLNWD7/nn9hzqg5gMX2vTv5v5/9P5Sv+e+v/heXL7yAKjcRMPd+7rEIk94OZfF7Ufjd/8hS2ru6cNxg5pqwKKLX6C3FVXvF6dAzguEAhnDfVGljDIl4nGfXrWHbrp1MHje+FAkcaigmzxltOHLCNL78L19kyuhJLL7lVsaPHs2733ktUSeOC5x3wkJqv/sTPv/Nf+fhZ5aQbEpSUZtECYWFRBiBFY3gRiPE7SQO0YD5pR0eJyhRFDYoqYKqMBQocKSNLECuK4MjI0xsGMcH3/FBzht3KnFts6t5G3/5+93E4hX8y/uu4tiZc0rS/VALmJdD8dzuXbokLBLqr/4Uzd9yM7h8/Y1DTDj39IEdA8OLMOF6sdW10QaMDtoCCkF7Rwefvu6fuOGTnw4CTHII9aXpB0PQ4dqSEo1hxYqV/OnuOznp9Pmcc+rZOCack00IVqx9llvu/j133H8H3aobK2oRTUSRro2MuIhEDF8ohNBEXBdlwNMGy3GxIw4KhS88LEsjMEgNjpKolE/Ud5g3ex7vvew9HNM4mwoTZfu2razf9BKRplomNo1jdE1jEBGW4pAEtV4tlFJIKXl27Wou/Kf3YVk2wpIgAqEjRLhenAGyfJQeQKYe9HBsiX8FgU4nAqaIRqL85aEH+M+PfXLIzBd8IAgEVtgSUSI4bu4xxCvj9EiPvT2dNCVqwi5zmrkzj2HKxEmcc+aZ/OzWm3l23TO0tbbjVsSIChtt8hjHQkjwMEjHRvkFjAR8Q94vYNkSP6eRSuFi4yrBxIbJnH/qOVxywkU0uo1Bu0WlSCYrGD9+MhMnTcIiOAchhjbxQyBUhBD85cEH6ejupqmxEaV1r+FbliB4oNkhBwJiwjkDPAIApR5ARekfWi7G6KA1eFi00dHZyc++8d9cecFF+EoNeUYAelULKclrhVcokIjGSh6t4nsA65s3srN7F3fdfw8rX1jNrrYWerJZlDQQkXi2whMG6TpIGXSGsGxJ1I5QabvUxSuZPnoi82fP5dRZJ1Mdq6bSrgyS7YJW0UHnuTB9WKNLUdWhjKLru6Ori9Pe8Xb2dHTgum7oig0mKemV/mLQpD8M+DzBRYS/KfrtK1PpjAk6Q/zoN7/i8nPOQw4D4ode49FoQ0RaRKKxfd8L1cAjmiZzRNNkZo+eTdYr8NzW1WzcvpkdzbvpyvXQmmol5WUxtoXruCQTCUY1jqIynmD62MnMHTsL14Om6hFE7GCCjGJLdQAkWFil4w0H4gdKXUF+fcdtrN+6haaGxjLff38dv4w+B3J6yBCDpgKVn2ofNSjcobUhEY+xdsN61m7YwFHTp5eigsMBQoaELvYN1JQm4gjVkbpENQCjq88gMzNDNpfH8wp4Jk80HqNbpah0q8lls0StICM1GY2HGacBSsc6gEdnOEEKgdKaex9eQiwaLSXDBZfRT/0ZZAwOA/T3BpUoHwh1P0RQJ5zL5/j+L37Gz//724NyKi+HYtndKxHQyxH6gVAaDejra084cRJO39LQRhqCFbdm3+O+imO9Evqf//6u59XeizcKpRSWZfG3h5fy2Iqnqa2uRhVTH4QoaTjlKs9gntGgits+keCQo0UZe2utqa6s4i8PPcBz69aVagYOFgLP1MsPqaX2HK9z5BWU+dtF4PtWWodR2d5glDEGbXRpKRqJb9RXX2Ki0kvf7X0+N8gQ4TP+3s0/K9l8ATWUZ/uI/ej6g8MGA18PsE8sLJT+RgRL2YUGAVhJLpfn+7/8+UEPzEgZdGJ7ZRS90m+MSIoVX5aUYVS2lzGCjgyytAyk3CuOQkoHaR69XZvC17AOoG/4cuBRdH0+8NijPPb0ciqTFShtygzdsuSHkGZE+UkNAn0Onhu0v71SHscIs0SLkeHqqkr+8sD9rHn/ixw5ddqg2QJF74NSitauVp5du4ZCPs/8Y4+jtrIm8KbQ21Unk8uyoXkLqze+RF1NDbMnTqOpquFVBe1ejfpiQm9ZMSBU9Jz1//z+pPMBf7P414AQhhVrn+WFTeupq6th+oyp7Gndy4ZNm6mtbuCk404k6lm0dDTz1LpVWLbFvOlzGF3bFN6LgUXxnP/35p9h23a47+W+MOCnsA9k72xeA/2v92EExTwmXA8IPxgQQoNHSpTRfPKrX6bgeYOXJGeC/BNjDM+tXc0XvvgFvvil/2Tl2ud71RBtSqWFmUyG39/1J774lf/kG9//NitfXBNMVKeLV9jv5/sRff8RzRCoQIbgPPJaUTC9Kp9gX8Iu/mZxf1GlKvY26v9Zo8OgI5DKpvjFH3/D57/2Rb714++y4sVV3P7AX/ncl/+db3zvf9iwbTOgWfLUI9zwtS/ztW9+naeeW/567+7Lwg+l/49+/UseWf4UlRVB1mcgD0WJJnppA0pUE9LPYPwb3EBYn1FAlG0Hrq7ANg761VcmkzyyfBl/eeB+3n7BhQMeF/CVHxaUBMlgY8eM4azzzsUATU2NaBPMpFicxwuC0WlXWzN7OlqRUYdMIY8QEoOmz3xVpq86YTCocGLrwN0b9Akq/q4AtjXvxnclNfEEbjQZNMXVCqNNUJdcJHgRzP3i+x5CSowOiMa19+3fL0pGZPDdrJ9ld+dedra14DbH6cyk2dPdye69LcTiSbpzaYSw2NvZzp6udpyMS3cqPeBBNGOCKHpndzff/+XNJOJxVGiII4v3sdwGOHg4CIW5YfVrSPxFoheY0P4MJJo2hmQiwXd+fhPnnraARDw+oLUCLe2tPLdpHePGj+OIEeOYOGYCX/6XL4AQOJZFRuVYvm4VoxubaKqqJ2JHkALiiQRuVZxIZRwrEhCdLOunI0Qws3x3roddO3dx1LTZ7OhsYdmKpxFIEsk4x86cQ0NFDUaA8jxwbDa1bOeRp59g3IiRHHvkbGZOmsb6LZvY29nKhPoxjBs3DmMMO1KtLFu7kq0vbSDiuHT5aSKxOKfMPZEjmyaSDGeG1FqzesuLeK5gTONIqkUUZRR2RRSrOkG8pgIdkeSlwqmvxKpIIJ0g+cyJODiVURzXxYrYA06DRb///7vlV+xo2U1DbT2+DqaLLTlFguGvxAy9XqCBPZf+GJjOcC+HMqlXTG8NiF+UCdDAI5SMJ3h29Wq+eeOP+PpnPldymb2hw4dE2tK6h+/84Hu0dXfwtvMv4l/+6eNURuPFwYi1uzZyw7e/QcvO7Vx79Tv59Hs+jhQWjmOhC3kMmmgkQq6QI6WzFNJ5RlTVIyxJa6qN3/z+t2TyeerHj+bJ51bw+ztupaaqhsbRI5g9cxapQo4Xdm1kw5oXmTZ9GkuXP8rjK5bRWFlDR0crU8ZPZsOWTTz27JNcceZFjBs3jqwo8Pu/3c4PfvwjhDHUVFSSNj492RS/rxzB9Z/+AufOPx1XOBgJ9yy5n5t//xuOmDKJGz7xWapqK+nOpFFGk1EexhJoW+AbH2W80qjlY1DaBy3x96vcvX7okPhXrH6eb/3kRmoqq/GVKiP+kNxNWfpGSVMY/NFgkNOhDeXNjfpA9F2EDCaYbqiv44e/+gWPrViOZVkoPTD9g3KqwK7du3lu2TKeXLGMgl8oeUYA0vkMO1p3s2rVSlasWUlK9SAESHQY1tDEE3E6Ojv54a9v5K8P3YNl2/RkU/zl/nt5+InHWLv+RX53x+/Z07mXSDyCbyl2NO/AqYjx1IvP8vVv/RfPvLCKjmwP3dkUTtRGWILm5t1YdoRuk2Xn7h1YoYHYk0+zYetGduzYQrIiznXXvZu3X34Znpdn7brVPPvCKnrSPSAgg4dnGbbs3Mqjjz9OS2vQYCqdzyIci0gkgq+LxT4q1LWLaptGS4OR4ag2IHe8F75SfPKGLyHCmotylaek+IheWul1CQz+clDDrqLIDOXED2WuwGDbdhw+dcP1ZPM5SrlEbxDSsnAq48jaKmIVCbyw43LQijtQ6d3KJLKxlkgsim+CGSCN8hHCUChk8bwCWmueXLac+/7xAM9sW8uzm9dy7wN/I5XP4EvF+k3rqaqvoqaxlpbWFlr2tPCPpx7mjnv+zOZtW5h25DRGjBnBEdOPoLa+lvbWFrZv2cwDT/6N1S88j/G9YH4AY9CejyslVsSlsbaWhfNP4vg5R1MdS2BFHTwHCA3ijMqhbE20JkmsOonBILQhk05jWveST2dwpYWtBZawg0AkRWFroJ+xPRDwfB8pJd/4fz9gxfOrqEgkwjwm9hGAlEv/4rB8MLxAg38I9nOB5Zxfrv8FtkAinmD1+pf4yve/N2CjQDafxTca7QiwBZ4pD7gFjayMMeh8HikMUTuG9oOmVwqDG4+hjKKmtoYrF11J/Ygmbrv7z9z90H1U1lczctxoYpVxTjrtJKZNn0qiIk40HmHEyAYeWnI/7Z1tzJg9k+XPLmfDpvVMPXIalfVVJKsrqK2v4W9/v58X17/E3BOOY9TYUQghiMQjFIyHQhNNxPCUT09PF0ZqPAo4FVHceAQhBDV2Nb6AdDaDRqF8H9d2OGrWbCbOm8esI4+ksaoO4/lII8IKsVDWFqviBAg5MAqQUgrHtnl61XN87+c/o7a6JtD7iz7/smS3XoYQ/caFwceh6U7Vh7tNoP+JwFAWQqC0ora6mp/87receMxcLj37nDdcNCOlhbQkqAI5v4Bl2SWPjTACV1pIwHIcbAiaW2FIZTMoGzp7enhq5VM0NdQyZdIE3IiLpzVGCI45bi6WLdFoqqoq2du2l6OPmcPso2YRj8fJZLKgIRaL0NXVjUbR2d3JnOPmUnn8fJxsgZwweLakKpJgS1cz7SbFSzs3s3brZkTMYeve3Tyx6hnWb99MNx5+MsKyZ5/mqSOPZlLTWF7Ytok1a1cTq0qCJUH51FRVcNoppzDl2KMYnaiip72T9pZWbAQojfL9MFNXBc6Y0hzKb4wJijlQLa2tfOKGL2EwSEuWqtNEmbHbRxUox0HigcE3gsthyvqhmaJ/KPQMGYlAl3mLgojpp274EvOPnUtDbW3QQ/51DtG+9vG9fOBulCCdwOUpiu5MB1QhD0rjKx3U3toWTSNHYUmXPTubuenGm/jDr36LLQRONIYnDJYdpCKnMilsN2CqfCFHLBrFkXbAuFYw+7pWgZTVviKrfHAtHC1IShdPGnLGxzUWJu+jjU9a++zo3IuxLXbu2s1/feO/KQhNVz4FSB564EE2Pr0Kx0B3LktnLk0mncaKJyDi0tbVxZ9vu5NnX1hNHItsKkPeK5DvyqLrFFEnCkAunSfflkEkQGW9N0r/KK1xbJvrv/cdlq96jlFNTcFsN7Ko5/aL+oZrJXOxj/t8cHFIRoDg+sr/hvtCH7wQQTAnFovR0d3FOz72Ef7++z+GYfzXp6d6voefy5FIJOjOdLNi6xqOmTwLYQy+8lm64jF6OjqJShvsCAUk9ZVJ3n7h5ax/aTN797SQy2bJp9No2yLj5TCAbSzSmTTSsohFk6R6eojaEZSvsVxACtKZDI7thLGB4Mm60sbP+WgjyFh5tAlm0fFM0OMzFosRsSxGjRqNG3Xpae8kl8kgHZtRdhOjR49GSpudm7aiPJ/amiSVugbpOEybcgRHzJhF1hJE3Agi65OsriTpxNEYJo+ZxCknnswRoyahPM3YEeM4auJsqmurGV3TVJqs4vXA830c2+ZHv/4lv1x8K6NGhMRflu5QrgYVDb9yRjiYEOPPPPVgjgGlQJgpX+9TNlncDsonLSFp7+zgMx/4EF/+l8/g+z6Wbb/q21R0gz6xfiXv/ej7WL9lA3WjRjB2whjqa2pwpE0qnWX31p10tXfS2dbJO995Ld+54X+oEVF8o0irArvaW8jks2hL4ysf27JQgO8VcG2HSCSKr3wKhQLStjBKY9sWsUiMbC6Lp4LzLnViMAa0xnYctNIgCKY3CvPiHdvBtizibgxPKNo6WjFAxHbxPI+mhtE4VoTtrdvJZjMUJ8YQQjBq5GhqYlUoo2hrbyWdTuP5Ht3dXcQiMcaMGENTVT1R4aCUT8rP0dzcQjQSZURdPRHbfV1ByKLb+slnVnDFRz6A0kFb/MCdti/hH4yCl1fCIbMB+gTHoCTZS6NBaCcoo6iprubrP/wBruvy7//8CXzfL+WSvFqMaxzFeWecg/uwQ94U6Ni5h9atu9HKx5IOFYkEdVXVHDFhCqcddxJxX+I7mpyXp3nXLmorq6mw42xq3kwkHiUZTZBKpUjEkkSMS9KKE0/GaO5qpaV9D03VjSTdGMbTRLDIiDzd3d1UJCqIRqN0p7tI9WQAQ2Wyip50D7WVtfjKEIvEGFXRQGeqi717WkllU9iug2VZuJZNTXUN27dvp6aqBj+d5y+3/4menh4uvOgictksN33//zFpyhS++PHP01CbZIO/lV/c9ivGjBrDh97x/j4P3ZIutY5L7cTKN/REi8T/3Nq1vO1D78dXmmg0gja9Wa37Jf4+ceeDS/wwwHOEvSr00++KhE7JOihTBMP92hgaGur59k03csZJp3DiMceGUviVmaCoLjUmavjPT36BRRdfxvad2xFW0FU5n88Ti8ZxHIdMT4aRI0dxzJFH4wgbbWDNhhe5+567mTdvLus3bmDzlk00jhiBAHbt2EV9QwMYmDJ5MrOOnM2yp5exes1q4rEYRx99DPl8npfWv4Qxhs7OTppGjCAai1JZUUnBz7N923Yc16G7q4eKqiQCQTJZwXnnnsuGDev5x5IlSCGJxWLYjk0ykaC+YQQvbVzPkbNmkUwkeXzpo2zdspnxo8aiteIf991P+7F7aXvnXmqrarn3vrt5YfVapk6YTCGXwYrEAsM0rCArJuWJsvv1WqB1UJaZL+T5169/hVQ2S01VFb7SCCsg9FJH7FKdRD934EFye/aHGHfGQVaBILhQDRRHgeKcPuVdJIrrYQ2xQOAVCkgp+dNPfsb8Y+e+rpEAKKtAEoEqEtoeRYO8KJO01nRn0mzfsZ2K6kqUUmRzGaSUZDMZfD8o4q6uqSYRjVNbVUM6l6G1vY10Jk0ikUBaFr7nkc/lUVrhOA6FfIHGxkYsR9De3gGA6wZzCitfkUjEaRrRRE+qh5aWFmzbQSCCqU9D7UlYgrq6OmzbYfv2bXR3dzNx/AQKhQJd3d3UVtcwtnE0wrHY1bILQ5CPM6p2ZG//zQFQN4reuVw+x5X//BEefOwR6mvr8MLcKyHCli/7SH+AvrlLB9P4LeLQMACUJcUVV00fBgCCxK+SfaDD2oEcjm1zx09+yvxj570mJjjYfUiHBA7QGGsgUCT+bC7HVR/7MPc//DCN9fVhqkNvi5P9qz7lo82hkf5wMFIhXkWKRGmGqpJa2BscE6VXgdaKaDSC53tc/qF/4slnn8G27WAq01eB10v8xUh0efXW/pb+nyn//mtdXu675ftf7vfDi97nNwcCReLPFwpc9c8f5v6Hl9LYUI+n/FKGZzHA1SfSX0bzJXEvBoG+XuVyaCvQ94kQi17iL7nLZK/0kEEwJRqN4vk+b/vAdTzxzApsy8b3Xx0TvK7TLJNYL7f0/0z591/r8nLfLd//cr/f/zcGCuVqz6KPfJD7H1lKY0NDKfWhdLyS5wd6OSA8p7K/hxKHvgVDkdhL68UHRj/p0esyU1oHTKB8Lv/g+3lixdPBSDCITHAYAYpljdlcjqs++mHuf2QJjfX1eL7fS+wh8VP2zHrnZxb04cVDzAOHngHK0Fcq9I6XffzF4UiglCYaCZjgig99gMeeXo5t2yilDlqB91sNSgeuznQmwzv++cPc98gSGusb8MJAV1BfHY4ApWhvWZpzH+I/dHp/OcLKDg6ZKVCy+sNJ0ERxneLgEN7E0jAe3FAZllFGIxF85XPxde/hK//73VL9gB6gNOrDCOCroH/rEyue5viLL+AfTz5BY119QPyy7NmUhvJ+Pv7iTO+m//ohXYwtBGJISMySC8yURcYC+8iUSQohoTjFsECgjMZxHSxt8dX/+x6+7/PlT38mYJBh1GhrqEKHXjjbsljyxONc8/GPks5lqapIlrw9vY6K8lcIcvzDhynKR/ghQG+AEEJIrc2e0EA69GdVZg+UJEnJL9+bRxK41mSpi7ABhJCMaGjg2z+9kTOvXsTuPS1YUuIXMx4P4zVDKRXMnyAl13/3W1z8vnejtKYimQwa2cqig6LMUVF6pdfoFf1S3w696mMCr6LZI8E8KILZUIaGzrCPgVTmQiszrISkZFwVjS9lDLU1NaxY/TzzL7uIO/92L7YdZH0OVGXZWwHFGmPLsmhp3ct5117Dd266kWQyie3YZcTP/n38+yX+EIee+MEYHdgr5kEphEkc6vPZF2X6Y5kLrShF9l9UIUqEXlVRQU86zXWf+Rc++/Wvkslmg9HgsIH8ivBVYNBKKbntnrtYeOXlPLr8KWqqqoN+qFAKcu1P8veO2NDHBhgiRm85hDAJqY3YbIwpBWCHxEK4lBnJwf6i8dRrZBl6R4Xig/BDD5EbifL9X/ycU6+4jCVPPI4dths5mO0XhwuKEwTalsWulmbe/2+f5t2f+gR7WtuorqrG1zq8//2WkOjLxUrw2IJnFTzTsjnjhsxijDZisxRa3GNKvqpDb5b3XXpvZylyKKA0f1RRNeo39AopwixEaKirZdP2rVx83bv5/De+TiabOewpKkNR3SlOEHj7PXdxxlVv57d33k5NdRWRaFBMjyw55EqvvYK+1/Atok+jxUMY6d3vEtTeCKHFPWLMgvmzhJSPApVhDs7QGqhM74opbYdsDL25QqGIKU+mK7J7Meltb2sbc2cfxcffdx3vuOSyUr2xgCE5R9lgIuiIoUt5/0+veo4f/OLn3HbPXUQiEeKxOL5W+6g4AaH36v8l12fJwT/0fP39YMIT7DZanyIARi88aZVlydkmsBSHHiWYviumxATBa3/iD/aVMUbYytC2LFKpFOlMhtOOP4FvffFLHDv7KIASI4ghPrfWG0W5gQuwp62V7/7kRn70618GE4ZXVwMcMI+/d53e9Ir9GrxDkvgBtLCkVEo/v3PJ40fZgBBG/ENIa5ZWWomhyAAl13GvTxnTGyQQwlBsaGvCLwTVBeGcUzJ4w1eKeDxOMp5g+arnOPPqK7n4rLP5+Huv47ijjykdrhjufzNljhbVvaKq097ZwU2/vYWbb/0923fvorqqCmlZpc8JGXao7qNi9s3m7CVy0Y/ehyzxY0BJaQnhm38AwgYM2ixDG4E2kiH/0AXCmBKhE0bMggqzUAKZIkNIEKb0CdAYA77RVCSSaK1ZfPdd3PXgA1xy9jn883uv49hZs0vSUZV5RIYjyvX74jXs2L2bW+64jZtv/T1bd+ygIpmktqYWrVVYmln0uPX15xcjvb3euTImIFTzy2nHMDRhjAxpfRmE7pQR8+c3OC4bpBAVgT9oqPJvGYo2QNl6H5WopAaxj03Qq0IFE9pppejs6iYWjTB98hQ++u73cvkFFxOPRcNDBfpysZ//UB4ZikSPEH2i4M88v4rv/ewm/vH4Y7R1tBOPxYnFYijdOxnH/gNZZRmdJcYIf7Rc5RnC96QMRgghtDE9XoEpLU88sVewaJHF4sVq7Gkn/kna9qXa9zVCDI8Z68qZoLhd5IWiD9X0ZwgT7i5jCMCSwbSjmUwGpRSTxo3nkrPP5dor3s70KUf0OayvVGgvyEM+EXWpqZUx+/RRbdm7l78//ig/ueXXrHnpRXrSaSqTFTiOE7Zp7yX8ItGXJH0/Pb93PyViH2bED8YoadtS+/6ftz/85NtYtMiy2bMnHNHM7UhxGUN38NoXxQdRZIRi3glFpSj8GJSpQcUHD5igWESY3gntkskkAtjRvJvv/PRGbvrdbzjmyFmct/AMzl1wOhPGjiUR7zvHlx/GFQZ7hOhf8FJso26VHW9vWxsPP/Ukd/7tHh5bvpzde1qwbZtEPEFdbW3g7w+nWRVC9qoz4gCSXvRTeYYr8QcwSCGEMLcDsGdPr/d2/II5VcrEnxVSjg9nWBheiu/+RoPwtaQmmdCZ2n8UYN/1IjEr3yedyZDL56mtqmZEQwNnn7aA8xaczvQpUxg7avQ+p1I0JIvF5m8UxVFmf7ZIOpvlmedXsXzls9z90INs2LKZPW2tIASJeJyIG6HYyh3oS+zh9j7roWErygzc0vv0rg8zaIQURuutlsgcs3Xpc11QvLQFC2yWLvVHnzb//2zH/rgueD5CHKKWKW8ERSIvbvYG08pdp6aMOUo2QrlbVZvSdwIhGMzt5fkehYJHNpcFAyNHjGDsqNGcfeppNNTVcebJp1JZUcGIhoZBubp8Ic/WHTt4adNGVq5Zw5qXXuT5devYsmM7vvJxbIdoNIrrOCCCmWyA3iBhyVuzr4qzDyMUvxd+rWT8lu8fTjDGl65j+57/g50PP/GJIs0HRL5woWbpUhT6x1L5H0DghtQz/K5UlKtE4T5Dr8oj+rb/NqXvFNuyBIl2BpCmKMUNfuhNiUajxOMxMIZUOs3Ktat5YsVyLGkRj8Wora5hzsyZ5PI5Tj1hPhPHjn1dLR1NeM6e5/GXB+6n4BXY29bG2pdeRGlNJpMlEo3gOg6VFRUIUUw30KWuFyX3Jf0JnbL3odyw7evcMb3fp4yZhpGWHMIgkFr5OYX+MVCi+d6nEhrDY0474ZfSdt6jveE6CoQwvQ/J9Nvuo/YUP9BvFOhdNfv5fK8TFhHM7miMQSuFr3wy2SwQuFFLUvg1E02RcAn6HwlwbJtYNBb02besYD6w4nkXP0xfYt9nu5zg+79/IHWn7LeGJYzxpePY2vd+tePhp95bpHXoK+ElwMgF86daxqwp3zds0Z8Jyvf19xaF+0yZ2rTf7XIdq5/7tQgZpJf3ElFRtXqVA2pvf7zgpfcwoXpWLsHpu97fYO3V4/szQ/BHiP6/U/ozvFWevtAASogjdy994qXyfbLPhxYtEruXPvGCMfxE2rbEmOGdNlmuAtCPOMLZIcrD/Yje+gKxz3axuVNv14NSQYgUfWoVtDFoAs+S0hrfBN2mlQk8MEqr/S9GocLP+qXPaor/DPQep6zZVJ8GVDIsFApfewuHioVElH1P9CP+sOio/F4Nd+IPXZ/G8JPdS594gUWLBCHxw746vgDEmEUnRsxuNkpLNhk9DD1CL4f+3qI+VjO9XqN+kr5XyPf3Lu3vd4oqU58D73e1D8QBNkT5VvmGKNvsb+iyH+LuXaffevlPDkfT7wDQQkqhlW4WI5m8Y/GTeUKFt/iB/oRtWLRI7Fj8ZFYY/Z9CChFMmmt40yyhTiLo25CrePkl9Xg/+nAxUFQkrmL7llIASZapFCIwpsvfF2WSd79L+WeK35P0jkZlr72fKe6j9Lov8ZfRda9O1ude9JMCb47FaC2kEMLo/9yx+MlsKP37iJ8DsboE9JhTjr9bOvYFOmj6MnwN4gPh5WyEPm/0l+h9pf0+I0Gf7b77X9a3VqTLA0nhfvt7afxAowJ9GaFs+01j4B4IxvjSsW3t+ffseHTZhYQ03f9jB7pywYIFVp3nxWK2ek5Ka2KYIvHmUYX6Y3/M0G9/+fYrE31/pnl96Eubos9L+fb+VaS+P7LPw34zEj6AMVrattRabc761pw2x8mydKliP2LpQARtaGw0bY8/3oPR7zXapBGid3qTNyNKOkeZptBnv+izXVJl+hnMfTuiyVeh6ry8ahToQKEuVdq37zmUn3+fc95Hx+93PW8+GITQRps0Rr+37fHHe2hs7K/jlfDyd6EYIT7luM/ZbvSbqlAoBEGytwD6ivj97NqfqrSfjVDleT0jwb402l+d2c9G/0Gi/P03Lc2XwVCwXNf1C7nP73x0+X8XafhAH3/lWzJ3rsOKFd7oU47/tuXY/6o93wOcgTznYYH9UPAB1Pz9vTNAOCB1v3XUm5eHJx3bUZ7/nZ2PLvtMkXZf7guvrNOvWOGzaJG189Fln1EF/7vSsR2Meet1oe2vZtCrKvVRyfenguyjkhxgeaXvlR2s/7f3Oe5bDYHR66iC/92djy77DIsWWaxY8Yp0+mrvlGDBAoulS/0xJx//Hek6n9ae99YcCQ6EV6njvJpPvaqH8lYk8gPDk47j6IL33R2PLfvXUO3Zr9HbH6/lLpaYYPTJx3/Hcu1Pq0Adsl/j77x18VoMgcME/mpgAN8qSv7XSPzw2gm3DxOEIwEY8+Z2kR7G0ENIc9Jx0AXvdRE/vD7JLVi0SLJ4sRp98nGfF0L+B1IkjP8mDZYdxtCDMb6wbRtt0sbor+18bPk3wwzP1+yqf/3jbNFFevLchUJaNwohp+nSlOBvotyhwxhK0BhjpG1bxugXjVYf3vnYiiWv5Op8ObwxRTN0M404+6iEnYn+QVryImMMJugnIt/w7x/GYQQwGKOFZVlCCLTSd/nx3DtaHliVfjWuzpfDG5PUK1Z4XH+9bHlgVXrnY8su1tr/kBFsko5tASJ0l755o8eHMdgwIQ0J6diWEWzS2v/QzseWXdzywKo0118v3wjxw8BJ6KI7WjcsmJl0/eT/IHi/tKSrfYUxxhfBiHBYNTqMVwNtjNFCCFvaFlrpAoafF+zUZ/cuXZui1OvvjQvXgVVRykrNxsyfN0sL/k0IcZW0rIjRCqO0HySxcFg9Ooz+CHpZYoywpC2khVYqb4y5VRq+teOJp1cDfWhsIDAYRFjyEgE0nXbCDFuZDxvMhdK2JqPDzmVaB+6qXlvhMEO8tRBI8GBmIoGUlpQSpED7aqNA3O1b4sbmh59aB/B6vTyvhMEkOsmiRaLICA0zZybd6vhlGLMIIRdI26oCMFoHdbdBPz9K0aLDRvSbCUVCJ4jwGZBS9k6tCtpXXRi9FCEWFzozd+5duzYFFAnfsJ9c/oHAwSAwyYIFstxNNe7UuSOVss9EMgfln48QE4Ul4+WnFBSiHbaf3xQoI/RSnYTSGYzZjGXfi+Y5y/If2vbIit2l7wSuTc0gEX7p1Abzx/c51oIFFo2Npr8ON2b+vFnCsUYqz78AKceIoE/hQoRoZLg06z2M/SFoPmrMHoxZYqSUaL3Dcux7jKd2l/T6IhYtstizR7zWaO4bwf8HL+zxGC3PzUMAAAAASUVORK5CYII=", sizes: "192x192", type: "image/png" },
        { src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAEAAElEQVR4nOz9WZBkWX6fiX1nuYuvsedeWVtXdVV3AyDATUM9zIwNh+ACriAIYiFHJjMan2VGGR8lPUhmMOFZD2NGUcNliJkRCQJEYyVIG2pmpCFIoLvRXdVdVVm5L7GH73c5ix6ue4RHhEdkZGZkZmTE+ayy3P36dY/r2/399yMInEm+/l/9rH/dxxAIBJ6f7/6//un1F32Ob/zvfu7haRzL6+Z7/81/K173MQQOEz6U18TX/vbPBIEPBM4p3/tv/tsXFv+v/1c/ey7E/yR88o/+WdCi14B+3QdwEQhiHwgEAkcz6xwZjIKXT3iDXwJB8AOBi0vw/l8OwSA4fcIbegoEwQ8EAhDE/1USDIIXJ6QAnpMg+oFA4LQJ4n9yps/BwRh4PoIB8AwE0Q8EAkdxGt5/4PkIxsDzEd6opxBEPxAIPI0Q+j+bBGPgeEIE4AiC8AcCgVdFEP+Xw+Q8HgyB2QQDYIog+oFA4FkJof+zT0gRzCYYAAThDwQCr4/g/b9aQlRgjwv9BgThDwQCL8KLev9B/F8/F9kQuJARgCD8gUDgRQmh//PBRY4IXCgDIAh/IBA4KwTv/2xxEQ2BC/FCv/a3/mYQ/kAgcGp87x/9sxcL/f/tnwnif8b55B//0rnXR/m6D+BlE8Q/EAgEAs/KRdCOc2vhXIQPLxAIvHqC93/xOK/RgHNXAxCEPxAInFWC+L+ZTHTlvBkC5yoFEMQ/EAi8TF7U+w+82Zw3jTkXEYDz9qEEAoHzR/D+zwfnKRrwxkcAgvgHAoFXQfD+A9OcB+15ow2A8/ABBAKB80/w/s8nb7oGvZEpgDf9TQ8EAm8WwfsPHMWbnBJ44yIAQfwDgcCbRPD+LwZvoja9UQbAm/gGBwKBN5vg/QdOypumUW9ECuBNe1MDgUAAgvd/EXmTUgJnPgIQxD8QCLwugvcfeF7eBO060xGAr/2tn/Zw5t/DQCAQOMTX//bfDN7/Bedrf+un/Sf/+L87s5GAM2sAfO3nf9oH7Q8EAm8s4fwVoNKyT/7J2TQCzmQK4Gs//9PhpxMIBF4r3/vHv/Tc4f+v/63g/Qf2OKuaduYMgLP6RgUCgUAg8LycRW07UwbAWXyDAoHAxSN4/4GXwVnTuDNjAJy1NyYQCAQCgdPmLGndmSgC/Pjnf9qfmXckEAgEXoBwLgs8jY9//qf9p2egMPC1RwA+PkPWUCAQCHzyAuH/r4Xwf+CEnAXte60GwFl4AwKBQCAQeB28bg18bQbA637hgUAgcJoE7z/wPLxOLXwtBkAQ/0AgcBZ5kfB/IPC8vC5NfOUGQBD/QCAQCAT28zq08ZUaAEH8A4HAeSSE/wOnwavWyFdmAATxDwQCZ5kQ/g+cBV6lVr6SOQAf//zfCKv6BQKBc0w4vwVOj49//m/4T//Jf//S5wS8mkFA4bcRCATOKV/7+Z8O4f/AG8lLTwF8/HN/I8h/IBA403zyT/67EP4PnClehXa+VAMgiH8gEAgEAs/Hy9bQl2YABPEPBALnnRD+D7xsXqaWvva1AAKBQCAQCLx6XooBELz/QCDwphDy/4GzzsvS1FM3AIL4BwKBQCBwurwMbT1VAyCIfyAQuCiE/H/gVXPaGhtqAAKBQCAQuICcmgEQvP9AIPCmEfL/gTeN09TaUzEAgvgHAoFAIPBqOC3NDSmAQCAQeEZC/j9wHnjhtQA+/rmfCgv9BAKBC0Y45wVeLx//3E/5T//p//BCCwaFCEAgEAgEAheQF4oAfPyzP+WDIRwIBN5EPvmn//3zFwCG817gDPDxz/6U//S/ff4owHNHAD7+2Z8KP4FAIHDh+NrP/Y2Q/w+cGV5Ei0MKIBAIBAKBC8hzGQDB+w8EAoFA4GzwvJocIgCBQCAQCFxAntkACN5/IBAIBAJni+fR5hABCAQCF44X6gAIBM4Jz2QABO8/EDiDeP/6/l0wQgdA4CzzrBr9wpMAA4HAS+JNENiTHqN4oYFlgUDgJXBiA+Cjn/2pN+F0FAi8WVyUX9Vxr/MNMg4uyKcVeIP56Gd/yn//hMOBQgQgEHgVXBShfx6Oem/eIMMgEHgTOVENwEch9x8InJxXlCv3Z+jfy3mBoeYgEHgeTqrZJ4wAhB9eIHAkL0GYXugZX6ZQHuGVn+Qvnoo/f/C1PWeUYDQaCYBarfaMb1Y4FwbODyEFEAg8C6csrid+trPi/T7LcRwQ56Me+UKGwazjeQajYGIITHh2gyAQeHN5qgHw0c/89bDiX+DickrC+9RnOSsCf5o87TWNhfrUDYMXiBJMGwQzjYFz+DEFzicf/cxf99//Z//vY7/8IQIQCBzkBcX42Ee/aqE/jb/3sorxnlL8N+ve5zqS6b8jBL//D/7RjZM87GCa4OOf/akwAyBwrji2CPCjn/nrwd4NXAxeoNBsZkHcyxic87oG9bzqv3vMc75w8aH3jEYjcTD0fxzPun8gcFZ4moaHCEDgYvKcInXko05DbE/7mF4BR6riCcP/z8SM0P6LRAlC/j9w0QkGQODicJoC+yKC/wyPPVPphFmHMLlyjKDPvOc0ev+PyPVPb531bKPRSMwS+6fm/wOBc8aRKYAQ/g+cG54xLH2ikP6z/u1jHnvw73nAe49/njD7zCc75X8nfZ3jf5PXcqKnepF0wjOkDCZh/aPC+yHsHzgvHKflIQIQOJ88o3d8al7+MY95ob8x+8Ene+xpM/PPztDKg5uOMH5mef37tjxvVf+B4r/J38vzXAAkSbK7w1FzAYIREDjPBAMgcH541aL/LGL/tOc9/IDTOIznfs6TZtL3tHjGcx/aJGbfPKFhsPenZvytpxkFMx4zMQRgzxg4Ng0ww6AIBN5kZqYAQvg/8EbxDKHimeHnZwk3H7HvoVDzcWHs/bH+8f2Hg9VHR9X9vn/PFLs/cYj/ZM958FiOz1YcePzuDrM+lMNvwFHh/OM+l1lkWbb7b0Ke52Lyb7LtuBTBqXQ7BAKviKM0PUQAAm8uzyD6z/O44/Y9ZEA89Y8fEy3Y/2QnOKbZGz7757/69MeeEh/+5F8aXzvo1R/xfu3bvPeYypGeunPWfkdECg5GCY6MEBzw1qdF/uBfTNP0qZGB/QfhZ/6NQOBNIBgAgTeL5xX9Z3jskSHppz3XU4T8xEJ/YL9XKewn5aTHVBkKU+J4QPBPZBj4w/fPMgr8SVIGQlAUhQCI49gfFPtJVCBNU+CQsXA0IT0QeAM5ZAB89DM/6U/khQQCr5KX7e0/TfSPFfznFPupx3/2z//V047wjeQ4Q+HDn/yL7PfyZxkG00bBrEjB1OMPRgiOiA5MDIBpDhoD039hYgxMZqI/Vd5DVCBwBvnoZ37Sf/+f/fN9X8oQAQicbZ5H+E9D9J/Rw/fHGAMHnvjciv2zMut9eBaj4HCU4ECEYDo6sPeAXQOgKAoRx/GhD2zaGJiOCuD9vuFDwRAIvOkEAyBw9niZ3v5zi/4zCH4Q++fmWYyCwwbBwQjB7BqCwWAgoyja98EdZQwcYkrUp3c+VuJDeiBwRjlsAITof+B18bK8/WcV/Rn3HRvSnxb8fxEE/7Q5aBR8+NeOMwhmpAw8+4S3LEtRlqWIoshPLk90INN7HRD1EBUIvInsMwA++ps/GeQ/8Op5GcJ/qqIfBP8scfA9328QHPz8xtGBqc+wLEsxuZw2AiaXJ44G7P9DwRAInHk++ps/6b//S3t1ACEFEHi9nED8T0X4j3rcwcKxWaJ/YFsQ/bPF9OdRGQNw0CCYNgYmLX1aa46KAMzc/jTRfl5DIBgBgddEMAACr4enCPkz5/dn9Ygf9bhnFP0g+G8OJ4kOZFkmtdbeGMP4UkyiAlEU+WnhPy1DAI4xBkI0IPCaCAZA4NVymsL/At5+EP2LweHogNg1AAC01n7aGACOrA/wY2/9qPkChzgg7E+NCgRDIPCK2f2mhfx/4KXyEoX/2b39IPoXnV/8xV/8IaXUPiNgxnWgigoA/J/++S/9YPcJxKS24ADHifdRg4pOuH8gcFpM6gBCBCDwcjkDwh9EP3CQv/f3/t4fTq7/4i/+4g8ZY44zBmavBQC7w4YORQVCRCDwBhAMgMDL4TSL+04q/CcK8YdCvsB+JsbAL/zCL/ywtdYbYyZpATFtEMwM+Z+SIXCiOQLBEAicMsEACJw+z+L1P6vwB28/8JL4+3//739ncn2SIpg2AqqVF0WlwwdFeWIIjLc9qyFwoq6B0DEQOGWCARA4Pc6c8AdvP/B8zIoKVPf43ZbCmYYA1baXZgiEaEDgFBEQCgADL8hLEP6T5PcPhfkP3A7CHzgtfuEXfuGHlVL+v/5f/l1VO7Crv9PrEjBbmGcVDJ6wWDAUCgZeFt//pX8uxgbAXwsGQOD5OKn4vxThHz9i6nYQ/cDLZm/YEGOFPriMMadqCAQjIPAy+P4v/QsRUgCB5+M0vP5TE37PZ//i1449nkDgtJgYmR/+tZ8ALwC/awjsRugnX84DqQE4UDD4tNRASAsEXiIaTlSwHQjs8TK8/mft4R9f//yXg/AHXg8To/ODvzo2BMQMqT6iRgAqQ2BfjcAJ6gNCkWDgNAkRgMDJeRlefxD+wBvO5Lv4wV/9CaAyBPYVCsLJigVDNCDwigkGQOBkHCP+pxbuP66PPwh/4IxznCEAHN81cJK0wLN2CwQjIPAUggEQOJ4XDfefpKUvePyBc8QsQwDA+2MiAkelBab3mbH92LRAiAYEnkIwAAJHc9pefxD+wAXiuVIDR80QeNG0QDACAjMQX/3p0AIYmMFJxP9Uw/37hR8Pn//LIP6B88EHf+Un9loGp2YI7NPlgyL9LG2DJ2kZDEZA4AAhAhDYzyv0+oPwBy4Kk+/0B3/lJ8ZbZkQETpoWeN5oQEgJBA4QIgCBPV5E/J/m9YdwfyCwy15aYLJFHNbl6Q0njQacdIpgMAICBAMgMOE0Q/7P6PUH4Q9cVJ5qCMxIC4SUQOC0kK/7AAKvGe+PFHbPU8R/6rEe8Aefa/p+P75/MsFvfF8Q/8BF5vNf/rW938nYIPbe7/2MZvym/KRQcNb909s58BuetU+YAnehCRGAi0zw+gOBM0OIBgReNfoY+zBwXjnNXL/fd2vfxqOL/L75zIccCJx3Pv/lX+ODv/IXxreOKhKcMhAmQYPJpuPmBoQCwcAMQhfARePUxX9a4Peu+CnBD8IfCJyMyW/ksCEwiQZ4qgWI2Ft7wItqKYLJk8zqFJjaNjYjZhNmBlwoQg3AReKkIf9Z4fx9uX5miH+18VCuP4h/IPDMfP4vv7nv97O/NmD697W3j/fP9js+klAXcGEQX/0bfzV82heBYwr9jt3nOK//wO1DXj9B+AOBF2V/NKC6FFN1AgcKAWZses52wRAJOPeECMBF4AXFf7/DP+X1+6O9fh+8/kDgVPj8X37zkHG9Lxqw3/Xf3e3YQt5ZczuO2SdwPgk1AOedp4n/U6r8T1zoF7z+QOCl8cWvTNUG7Fb+zagNOFAn4KcLBJ9nUaFQE3CuCRGA88pT+vt39znmcfu9/mm34ohcP0H8A4GXyd7v66hoAId+s8fWBUy2M7XfrPtDNOBcEgyA88jz9vc/tcp/L+S/t31vWxD/QODlsz8lMPnNPqVAcPoJnscIOOpxgTeaUAR43jiNkP/ulRDyDwTOMicvENy7vrfpOQcHhZTAuSFEAM4TpxXy3zeyt9oYCv0CgbPH0wsE2fth+1NMCQTOBcEAOC88r/hP7/e0kP+UceD9XmFSIBB4fXzxKwdSAlMG+ktLCQQj4FwQUgBvOi813x9C/oHAm8SzpgROOi8grCNwPgkRgDeZFxT/6ejgQfEPIf9A4M3jRCkB9q7vngMgFAdeQIIB8KZyCuK/L9/P3nV/hEEQQv6BwNlnf0pgsvXA4CCmrh+sCzhIMALOLWE1wDeWZ8z5v0DI33vPF7/yGy9+yIFA4JXwxa98k6/85T+HEGL8Mz4wOMh7ppYRZN+CQlMDgnYZDwQaPypwTggRgDeNIyp398L5M+5/TvGfpAGC+AcCbx5f/MpvzAj/+6nTwTMWB47PLfvSBjPuD7w5hFHAbxIvrdJ/tvh/8Su//sKHHAgEXh8T4/0rf/nPI0Tl6T9thPBJlxY+MhoQxge/MeiQAXiDmKXvu1eeT/yPzPf/ahD/QOC88MWv/Dpf+UsHjQCougReghEQeCMIKYA3gWPC/rv3z3rM9H5PFf+9AsAg/oHA+eOLX/3140cIP0s6YGpbSAe8uQQD4A3l+cV/T+h3f+WTH7L3QfwDgXNMZQRMnQsOOgP7OgRe0AgInHmCAXDWeU7Pf68ocPy/fUI/tW260v9XQ7FfIHDe+eJXf2PPCJhVHDhlGLzwrIAQBTjT6PDxnGFeJOx/IJx3VLFf9Z/nVhD/QODC8MWv/gbv/6U/hxi3Bx5dHDi+hL1k/7PWBISiwDNLiACcVV5Y/Md2exD/QCAwg1u/+hv4A+eDfZGAfecPv/+0EyIB54JgAJxFjvuxnFj8CeIfCASO5eRGwMHtPPVc9Ez3BV4LwQA4axzX6x/EPxAInDIvwwg4UuqDEXCmCAbAWeJpg36O2T+IfyAQeF5O3QjgZOetwOslGABnhWed8nci8T9QBxDEPxAIHMHRRsDkXPMMRsDT2gODEXAmEB/+1F8On8Tr5pnFf+/e48WfGeL/m6d00IFA4Dzy/l/6s+PuANhbMIhqYSH2b6smCTJj+2STmNwzm9Ad8FoJEYDXzQuI/749g/gHAoFT4Nav/uaMSABHRgL28Bxy+UMk4EwTDIDXyQuK//TvMYj/RcYBdt8Wb0a4cmtqSw/HFo5NPFvgNsBuAKPx/QNgeMK/F07a551nMQL2n6aCEfAmEQyAM8bx4j9182BxH0H8Ly4CUHs3vUdIhZTgfQ7egc+Q5Eg3RNgemB6YLvgd8Dn4HpgB+AxweF/9w7vJkx74e4HzzsmNAH9Yw5/VCAi8FsJqgK+LZx70s7fHbPE/sN9E/P9VEP9zy+6EtT1B9kWGxyLjBIzH5V2EEEjRAwpwGbgSbAnO4csE/A5C5DgRI3UJKsU7gXegohRUDVvmCKGQOjp4EASD4Pxy61d/k/f/4p9FTE8FFFNfPSbbDkwRnPWdCNMCzxz6dR/AheQ0xJ8Z24L4XyA8B0+03hRgR7hyhIyXwI4wgy5SWoQcItwAb3v4so8zGdZaQCFcjNAxRG1krYdTdZxVmBJUcxFqCS4fouIUbwVCHTxtBCPgPHPrX80yAmYJ/qxRwgeeLBgBZ4pgALxqnjXfdZT4H7WwTxD/C4KYOll6wIESCO/RtWUgBp9RZhtoWQAjhO2Sj55QDjZxZohzFm883il0NM/C5bfhUhOp5pHeoXMBaR2QRM1FcDle6upveUBIgvBfDJ5qBOyK9wmMgOMIRsArJRgAZ4CTFP0dbvcL4n8hmcx2ENPlOzne5whRh8gBVY6/6KxRjjo4maMYYootBjsPGXWfYMpelQKwAlxEnPSI45jmXBvawEhALqv6wroHGiBl5efZEQIFKp06LDfuAgtlReeVpxsBjMX+KUbAcVGAwCslGACvkmcJ/R8r/v5I8Q81HeccAburswHVB14g3A4oA3QpVu8yGg4oswwwCGXwfkQ27DPod+l1tinzHgKP9ApISY2mu7mGEpo43aAoI0a5xIqEevsSjfklWHkXqCPsAHST6dC/CKfyi4EHL/wRRsC02L+AERCiAK+MYAC8Kl66+FdXb/1a8P7PJ5NT5eREasGb8XUHKgcExeAevZ075IMRznvSJEVJifcGbwrKPCcf5ZR5gZACrSRaAt5hywwz7CEdCBehrYJSYWzGsOyTaI1aeAe0AynHR2XAS8Q4IuGnvssinMTPHbd+7Td5/yf+7O5KwcEIeLMJBsCr4DnFf9+eTxV/H8T/IuEt+OH4LJwDGxTrD9ncfEB/awNvLFrUiEUbIRMkBg3EMiLWKTiLlJJIxyRRjVpSI9YK7wp80UeJhMQKfGnIBxtk/U1Gwy6tlQ3iy9chXQBKvC/xPkKJuDqscXGimBgrgXPHnhEgTmQE7H0PghFw1ggGwMvmBZbHnDXo5+BlEP+LwMHvyfjEKDIgBgaYjdtsPfmcztYThqMRWEms6ihXoF2LOJZEWtNozSMUlMUQ6SHSmjhOSZM6cVxDSY1wruoUyEpMPyPPDIWP0L0dbDFkSQrUW1eAJlIUMBZ/AClCDcBFYJ8RAOwJ/dTloZbBIzhuh2AEvFSCAfAaOFL2Z4X+923bV/03rgcL4n8xGJ8EnQVfgkqovhcZDB/R2XxEb+cxw/46eVbijKBggM9yRJnRbDVIajGthQXq8w1cMUKUJRLQcYJOasgoButhOCQb9BnudBh0+uSlx4oUbUqIawxaq7QXnkDzranjcxycK+a826sQCCfxc8euEcD+TgDv/fjznlEoeExnQCgKfPUEc/1lchp5/33b9jZP9gnif545+B1xYHLI+0AJ5LD5KZ2Hn9Hv7JCNcpxx4AyuzClHA7JBl6zfwYz6SCy1ekJrvsXcfJu5Ro1mLSFNY+I0RtdidE0jtKAoc/qDHr1+jzwb4bzFIbDWkA079J/cwm19j2qEMBi3ifWDfYc7WVAmiP/5pTr/+CPOT1MbpveZVax83KTAMCr4paFD2fhL4iUX/c38EQXOKeMgq3eYYkDUEIDEFV2yzgZ22MUVhkgloOtII1DKIpCkShEJj/IGTAaFR1iHLzJcNsQ7h7MxUjiEsAhfeXBOSJyMEVENRERUb5G0WiTNOlJ6fNmh37E4LEmtpHQ9ShvTbl5GihglorHwTwLEfpy5CMbAucP7fXUAL6U9MKQCXgohBfAyeGbxn7Hh2KK/6vLWr/3WqR1y4OyxF0qd3HbYcoDa6SEXBpjeGsPBDsI5Ep0S0aKwUDoNyhHJiDRKqMUxsZaQDchH29hyiCsyXFnghcBHMbJeR9eaRDoFAzquUW8LZGxwRERpk9rcPLV2E5nGOF3SH26ysbVGb/gJMtE05i9TXjJEqkG7vkSkarvH7rwD75GoYAScM2792m/x/k/8+InbA/fJ+0G1D0bAKyUYAGeCWWH+qRv7rgbxv6h4ZzHlkM7WPS6bmKyzSlZk1JWk3WjjbUIhI8pohATSKCaNY7QEb0YUwx5Zd5NRfwtTZFW9vlL4KELW6iSNNmltjjhuEtUatKI50lJSOomKYuqtFrV2CxHHDMuSrNdj9eFD7j3ZpJvDux98zCgfkUZzXL8iWWwnyHG7oBSyGhYUOJccNgIYi/txRYEh6/+6CQbAafOiof9ZRX/jHSZ3BfG/GFQRgKnbzmLLHJMNcMUIN+rhbI5KazRrMVDDakWZJwghSJIEtARTQH8ERUbZ65J3O5gyR2iJUwojFRQ51jokGh3VSGspMmrjnCYvASFIGjVELQat0K7E2wI7GpAPt9juFHBbkhsLvoZUTZyNaNVb1JIUIQVCqiq94B0iFAaeO/aMABBT3vozFwWGKMArI6wGeJqcSt5/djRgz0AIH9hF4eB5Tky2CVcN6xEOKRxS2mo4j/CoRCJR1ajgSIEU4MbFeAgQCiEjlAKpJVZIrPA4B9Y6HA6hQMUCmUikk1gczlq8K8BIQIHJiaSn3WqwmC/Syba4d/c2n926x8rK26honp1Ozs1rN7m8eIk0TYDq6+ycQ0lF4ByyW8wnEMd6/cEIOAuECMBp8Sz9/v7gXX7f9oPRgOnbt77526dzvIE3DiEVWsektQbUUyIzIir7WDNiNBwgMQiT40qD9xJRxiipkEIgVYSstYgbBQ6FNyVKS6wAhcNphW40iGo1ZKzxosSaPrbwlJnFlJYyV8RZiooTjFekccLla9dR7WWIHrHZ/YQH9x/wZL1H0lykdAIvHbVGDRlJIqnHx6J3o1t+d2hQ4Dxw65u/zft/4cdn5P+fVhQ4vX1y+xihD0bAqRAMgJfI8b767IjAfvGfutPDrW+G0P9F4lCIXEp0WqM2vwDNNpHIiPrr5Pk23c4Wzg7RGJSXYCXYiChuUGu0qSUpsqVJSNBJC18WSAlOeFLp8ZFCNmvEzQY6jjF2SNHfoRjkFIXFlh7rBFIlJPU2urFArb1IPL9C3cTUmvM82epz6946j9ce8Xvf+vd08xG9okdjqc3QDllpLtOI67uvzVOlAyQypAPOEbe++Vu7RsCuoo/rAQ4XBU44uh4gVAq8PIIBcBqcYt5/v/j7XU8piP9FZP9pTypFlNRRYh6SJpomWit6Ox02N+9RFNtEwhOrBFkqRBlTqy+hopS0NYeqJ9R0Ex81cUVWhWilw2uQiYZmCrUIbwtGnS797XVGnR7GOKyVlAV4UuqtJVoiobFwhWhhiZacZ65e4/7qNp/ff8z9zQ2++9kf8mhnjZHIqV9uc2n+Clpr0ihBCTV+dSKc3c8pt745rgfYrWMRu0bA/qLAkAp4nQQD4EV55tD/jLz/rKK/fcM1Qt7/QuOqFjqURCQJyiowBoFHKYExGcPhNsPhOlo40qiGLiOkqaFUHec8IkoRSRNEgnAKKWPwFqSrpgnXNNRTiAVkBltmZINthr1trHE4F1HmAu9rKCLqzSHSGKQHZES90eTqlavcfOsGnz+4x8bgHqvbj/ns/g+4/P4NrPAsLSxRrzdIRUIqY6SQu7UA4xLXkA44T+xOBqTy+nfnWUwVBT5DPcBxfyPwfAQD4CVQafvRef99G/bX/s0s+gt5/4uCH5/PJie08aV1UOZQj6vrgx4uK5G+WxUCKoFSAjnJqzoHCHSk0VGE0hqBrL5krpoUiDM4ZwGHtIAVYA2Y6tI7C94BDo8D4RBSI71AAdIa3GgIO9tQh8KUJJHk8qUl3r55lY1Rh/XuDl8+uIX69wk/9I0Bjfk5VC1hXjW5nC5T08neKx//AEIq4PxQ1QP8mXER4P7Q/65uT9UDPG0+wN66A4HTIhgAL8Jxof/ZD9j/sJl5//2pgCD+AWyJHXVR9XkwfXo7a+D7RHqEkFBrNplfWCGOBNgCLWIiXyPWbeqNBbSOcXmOLAr8aIjvdzHFCOsMXnhUBNpESJsiYo2zBQpFUmtiLRjj8D4Cl6Bkg1ptgaRWw9sSt71B1u+zU1iK0YBmPeLq5UWudJbouSFb3U0++eITrJIsXb1G0moyUHM0kxYpMcHnP99MFwXODv0f1ylwmJAKOF2CAfAyeMbQ/0GzwfvZ2wMXgEMnM4+xBUXepU4dO9xifeMhij6NuqDegmZrAa0sRXsOV2TgJErU0VGbWDeRQlP0e/iymh3gsy62HGFsWQ1uURIdxahRDZ2myEijVEx9bhldm68MACKkrBHFbeKkRRTV0FJTZH26vQ7bWcGwKBF2RJpI6vUIFUuKQUF31OPx1hO+ePAl7aUlsnjElZWrCBQtakRhSZJzTiXbBydbTqcAXjgVEHgudJCY5+Sk3v8hW2B/6H+/4++nbnu+DN7/xcJPX9mrnra+IC+HxBufs715j62dJ2idI3SNGnVqtRa1NMIVc7g8w1mJVA1E1EA4hekPKfrbFP0tbL6DL/t4O44AeI8XCqkToqxGXG8SN9vErTZxcx6LojQebyUirhGnbXRUQ3gFeUnWHzIa9hgOhmTGYIoM53I8JUiLjCVOQS8f8L3PPiEvDT/2jT/Kpu+RmwKpV2iTIoXYjQW4cWtgONWfD25987d57y/8mUq8J4WA+6YFTl0+LRUwe1MwDp6TsBjQc+Nn35pZsHdE1f+U2O/dri6D+AcAEAIhHEKWjLIeZdEhNwOQHmSMUqIqpPMpUglEFEOkIWlD3IDSYvsZxWjIqLtFmW/i/QBJUYVfHRiv8HlGWRZYByJOSXWMbi6idYLODWVh8TJCRAkyiqovrhE4HMbkOJMhvEcJh1ZV0ZfHI7VCphGlt2xsrxEnKdevX8dojySmz5AGMSpEAc41X46NgIPrBUyuctJUwHFdAYFnJqQAnoejqvKfddTvgcf4A/cHLhiC8fdh/6lNKYhigVKaei2iXtMksSdNI5TwlEVGMRrg8hztIE4aqJjqLCokSHDeU1pDZgs8BZGyRFohvMQ7ibHVhD5pHdYBQoGOqn+FpyxySpOjRjlRFKNVVRAopENrWY0dVpIisdQGPYQSWO+wOKQCrzy5K+mMOmwNttgabeCjEls0WK41QcS7r9d7B0KGGMC5YyL6U8Of9hX3HawPmN42/TRHePshCvDMBAPgWXmO0P/MvP+Mgr8JX37zd17wIANvLDNOYEpp0noNlUhiMc9CZx4lMmIlsMWIfNBl2NnGZhmxUNTqLWrWo0uDFwokRI06kZnDZiXW62rpX60RQqORSB8hVYJOG6haHYeAPMNlOdkgY9TtkQ8zcI44iknSOlGtgVQJ9WYT0ZAUOsJkBUm3ByrCVAEGVKRJaglRFCOkpzvY4daXP6BNkx++/BEmXgEd738bXtHbHXh1fPnN36lSAbCXCjiwUNDseoCpzVOEVMCLEwyAF+Qkof9DN6dC/SH0H6g4+P3xeG/Hs/9TVNKCWCKbLeYXlyhHm5R5n7LXo+jvUA46+CLDI/HFAJOP0PU5VNpE6ph0eRE5l1DL58jzLmU5quYDqIgoTkmSOlFcQ+oYLRUGT7GzRVEUmFFGPhySD4a4sqRUGttokc4tk85fojE3TxK3yGREr9NDROt4FYOKUJEjSVMazQZxEhNpxSjvs7b2CNJl8qUBloKSiAgNIft/rjk6FXBwFcHpR4VUwMsiGADPwmmE/g8W/RFC/4EJe6cy7y3eFwhvQdRApUAOOqHZatMvunS3e+Sddcg7RDZDuQJvLVnRIxv20MM+ydwlasuXSeYXSfQytlyh39+h09khy3OEUuhmm3R+gUazCQjcaMRga4PB9gZ5r4swBRiDz0aVASAUwmXISJPOLZE2W/jGCsYqTN+QeU1JVS+QaEWtUafRrBPpCC0EphyxtfmYdEFQqhwrDRkjFA0kKhgA556DqYCj6gFCKuBlE1YDPCnHjvudfcfRq/z5qc17KYEvfz2E/i86e21SDihBzo1vx4AF59FRghKSYpQx7HVRRRclCgQFtiwwDqxI0Mbh0zqpuISs1xFpis1TSiMYjTx9M8IrBVGTNG1Ta84RaQFK4XY2GA17ZDsbKJOj8GBLsBYvFGXmUFkT5ww6rUG9hRlYOplhu58xLCxIRRQpkjQlTVOSRCOcw9qcTmeThbSJiCx1mTBkRIP6vvcgTAc8n3z5zd/hvT9fpQL2twZOLw11RCpgBiEV8PyECMBzcmTof5Yn72fd8PuufvnrIfR/cTlsXApx8KRX4EZDpM3BWPBjb8m5yiv3GdZlOFdivMBrhRAOJ8B4R16WFB66gwEbvSHbo5JRCVjPoJ8xUj1yqZlrpEQenJRVRbYzmCLHe4vytpo2KMG5krIsKG2J957SWnYGfR5vbvJ4a5PuaICTnjiJiNOIKFEoDb60mLIkQzDKelhfoNEYLA4fegEuCF/++m9XRsBuyH+qHmDfAkLTjzo6ChBSAc9HMABOwkln8T+t6v9QHWAI/Qeexg4Q4UcPGWw/QbkM5YZ460jSGq7ewvgcCovzBicFQsfo2hyqNQ9JjWFp6W5u0zGG9V6XjX6PkTE4ZOVx9R1rvR7b/S5X5tvMKYFyENUa+ObcePngHOktWitkFGN0gkxSrBAM8xHdcoMHj9e58+A2j9cf0h91kZEnqWuSVCK1x0uLpcC4AmMFWT5ge2ebJwuraOJdjz9wUTiQChir+L42wJOkAo58+hAFeBrBAHgOji/8O7jX0bUAE0LoP1BRrf4ovKNyhQ3k62TZiN7q9+lvb5JoSGOBFIJ6c4FIgqkl2FEDWwxwOEScoprziPoCNmrSzQq2t7usD/tsjHr0yhyrJFJrvBdYUyK7sNPborPT5FK9zlIkadXnaIkYWx/ishHCGpSSRGmCS+uI+gIybdAdDrjf3+bW3TvcefA5G9uPKP2AtBHRaCekDYVKHHiLKy1OGAyG3OYMsiEDN6LlI5zaHwQOnG++/PW9VMBuFGCW4M+uDNwjRAGem2AAPI3nLvzjgGO/P/S/6/2Hlf4uLrseyuQERyWSNkPKFChwvTV6aw9ZffA5/d42jVrK4vwcrXaDpDlPrV7DNpqY0TymGGJwkKTIxhw2ajAqHKtb29xfW2etv0PPZRjtEZFCWo33YI3Fl4btnmd7O6bbauOXl2nNLdFqrUBhsMMhJs8BT1KrodotRK3FSGrWuzvcevCIL+5+zqP12wyKLXQqaM43aC0l1FoKFVmcs0jr8MZSuILCFeS2pPQWgxufwMMp/EIxnnuxryvgiFTA4cjAgecJBYHPTDAAnpGnyfXsZX73P3g69P/lbwTv/2Jy8JskAIf3Bm9GEDUBg+tuMlq/TW/tEXk+RJsWtl5DijZxUkepBi5JKdM6ZZlhBJUBUG+Ry5hyp89Wts79rR2edNcpRImqSWSiEEpWCwQah81KilFG4iR2YZnlxhziSpvG3CJYR9kfkA9HOOeI6jXihXlIE7r9HmudTe48vs2Dtdt0RmsQGRrtBu3FmOZchIw9TpRgHSJyoD2utBhvsTiMcxjAqWAMXzS+/I3f4b0//18+PRXwIgWBgSMJBsBxPIf3P6Xy+3eYEfoPKc/AfgQej6pdGt9uYIc9fNZDmYxUQqIEWgq0kCghqlHBKLyIEJpq9G6tgaq3MWisLhkZz85wxEanS05OlEtUIhFK4pzDFpZyWFAMM2pC045qGCfQSRMa81CUuMxhlccrcHEdojql8HSyEU+213i88YjtwQZOZtSaMY2FlNZ8QlyXWEpKY3DeI6RHKgelxHmHsZbSGCwGF4UfxIVkWrUPpAIOFwRORQhCFOCFCQbAUTzTxL9Znv6BbTN6/oP3H9iPR8npE1WOR5LGNebnFxDCk9br1JMY6Q12NMD5krIYUJYZDgdxDFohTW13xKpSGq1jpFCY0mGHFlGCVAJrHWZUYDKDKB1RLaWuU2pRDS0VGIvNMgbDAXmRg5S4UpENuvRtxqP1x6xtr9LNdnC6pFaLSBYa1Bdr1JoKdCXwxhbgQCBRwoMAiQfv8M5gvcVhgwd3AZkZBRh/E2aF/Y9NBcDs71AwAmYSDIBn5USFfwe2TYICfkr8Q+FfYNbSqEJDuQNRAuUA2ViijkK1NsFlxApiLfDlkGw4oCj6mGKAswVCeYhjbNnGmJwiaoIxNOspl5dXKLwhHnTIygzjDVgHxiKtoq4EzTTl2uICby9fZyFpILKMzGyQ93sMuh2Ms4hIk9khWcewPuxwe+Mxm711nCqozSekNU0y3ySeS1GJwHiD8zneleAliggtQUlBJEHjEN6AL8FNih8DF42qIHBsBDCeDTCJBhyS86cXBAZORlgNcBZP9f6nw/yzqvyr63v1AH7fvqHwLzAbAShQdfAOSJHz14ibbxH7VSi2UXkHkXfIux2G3VWy4RbeDFCUSCVwWuGHLfywS1lbRuoGS60G7sZbNFot1nZ22O51GAyH2LLElw6lPe2oxtWFRd6+fJkby/OspDVMd4edfEg+7JEVGWiFN4qBMax2t7m/vc7j/jYd20fXoZXWEI0Y3UyhpvDS4a0BTLWiIQIFSCWJtCLVikRBJC3aWCSWkMW9wHh/OBWwLwrA7tfj6CjAuFaAEAU4CSECcAL8oSsH7vcH7/SHDAI/9b8vf+Nfv4SjDLxZHHUikiBj8AWIGmruCoo2kCD6GgYGm21RZh1GvVWy/jrKDVDSIOR4fmDUoBwOcC2Dnr/KcmuFufklVpYus7y9w5PNTbqdHmVeIA2kKFaabd6+fIW3L62wUFeQdRhuPWTYXacoBtWYnkiSZbA57HNvY41722vs2BzTikhaddJ2iqvF+FhhVDUcyHmLlKCVACeQFoSQJJGmkcQ0k4iGUqROoE/Y3h04n3z5G/+a9/78n2Z3LDDsGgJV8d/+YoEjCwInRgLh+/Q0ggFwkKd654e9//13HSgGPOT9v/ARBs4xzrtxfjwCXUNgqMYAJyAUWIc1BaYcVaH/ckDkByhlUNZirMMWGcYK0E3S9jLNekrUXmaxhHraoB6ldOtDvHFETlFXESuNFjeWV7gy3wKZU5pBtXSwGeLdCItlNCrZzkes9nqsdzbpFX1MBCqNSJoa1UwwiaYUVejfekNV1yBBS1wJuGraXxJHNGt15utN5lUDLVMiEU5HF57pYr+ZbYGz8v7T254i+yEKsI/wi3sK+73/GamBGdv3igH9Af0P3n9gj4OnKo/DC4N1ObFsAeCKHtL2sMUGrt/FD0eYsqjG5ipFFCfEviSSEuFKlLcoJBqBkJBIqCtJLVIkQmDTGNmss6gjlNAkMiaVEe0kZaFZq84IzoAwEINMFRhBURp2Rj0ed7dZHwwY+BzdjJCNCNFKUKlCRgKpZNXLYDzeVblcrSKEB1NYvK36vZM4pVlr0qq1aNFERimKePw++LAm4AXlUBRgcvIUYoZ2HxUFmCoYJEQBjiMsBjTNcd7/ofY9f/i+3YV9pgv/xjtMbQsE9r4MYurS473BmQHELSAn336Azbv4bAdpB4iyh/OgkjpRfQElBdJEeF/gbYEQjkjV0LV5ZNqkpiOUKfGDLhhPnPdp2z5WOrSKiZRHS0ssLdYYnAfvMzKRYxNBaTTDEezkOevFgI1iSA+DbySkzRTZjDGpwkYaP52ndYCXCBRSRHhXFRz6snrdSmiSKKWRtqjpFhYFKMIooACOifKzOxdyX0HglKzvztCa3REwkxAF2CVEAI7hqd4/TIn++GL6QdN1AB6+/M3g/QeOR+HRcXN8a5v+xpfY0Qa+GJLGklg7VBQTi3ms9eRoilFMaUYISoQWRGmTqLWIbiyiZQLDIdlgQFlkkA+IsiHSlICgFIpCKLI4Ias3iJMIEQkKOaSvLVuiZD0fsD7sslmM6CqBSWrIWoxqpYhahIoEXgmcVOAFwgmE0yjncF6BV1WRfyHwJQilUGi0TNBRDUhwOBSOygiocOOV4sKp+mLx5W/+a977s3+6unFgJsCudu/aAn633XU/IQpwEoIBMOE5FvyZcQdHFf4FAgc52OEkGHsw2RakI9i4RW/jS4r+WlUh36wRtdtEaR2dJDgfUdqIwiRYP0RKS5xo4uYc9bkFdL0FQjHs9xn0dihHHbwdgBnhyozSluQOMiFxtRpxa5601ULVU0rh2HYDnuQ9Hg46rA96ZM4g6gm6UUMkMT6RuFji1MTzkggvkF6gvcThMVbijITcI4xGeYEmRvkIW0J/mLMTD8gHnnYSUdPR6/kwAmcQP7Mg8Oi1AUIU4FkJBsARnJr3P74I3n/gZFQjgXEbFN1Vhp2HjLprSGGQfp401dQaLXRUw4sUSwy6iS0yhPDEaUzabJI2W6AVbjQk7/XorD2mHGwQMSRRBdIXSG+rpXyFYORTED2kbyLKOoVS7GQ5q3mfJ2XGjjM4LanXU3SzhogjnAQvPY7KW7fWVw1YXqJQRAi8E3gD0kKMRClFRIwpPN2dAffuPUJkTVLXpH5pfl8NmBR7QwEmA7REOGlfCHajADMKAkMU4PQIBsCzcIz3f1zbXyAwmyO8GFeCLKHMMPmAYtTBO0OkJI3mHI22QaWKONUIoUjTBs5aUCBjTZIm1URAa3CDAXmWkQ16FP0OTg6JU0eSCuJIoXTVfZ9h6bse2XBElkWMUPSspZPldIUnTyNEpCgThdLgNVVhlgDnLNY73G4QTKG8pCoxEgjv0TJCJxERMdJqKBWd7QGffX6b7prlyvxNFuevInSCdoIIhZpMgZ3uDw9cMGZHAQ63Be7fP3xfTkYwAOBQ+P95vP999wbvP/AiCAVoZFQj0nW0quN8jvASZyy2yCHOQSgi6YhiAV7ilcBrhVSTdik7biuUCKUROgKpIfaImh7n7zUSjysNg6JgOx/QNY6+hSGCwguKSCKTGlILfCQwGHAgpay8L2erKX7jr7xAIsczxpzzOAdKxjSSNs24jXQxZQ55z/Lw0SqbD4d0ruXMLa2wMj+inTaZr7VQ02MBgx194TguCrDLi0QBQhogGABHcvCEE7z/wCtBVCJNA5HOU2tcQliPsAVpLSLSCd6UmFEX7x2uLPAmxzuDlwIRxagkRcb1KoQuIEpr1ObmUYlHiRQfG7LIUQjP0MEOni0HW9axaQydvKBvHLmQoGNEkhAlGq0EVWa/mt9fVWh7hHdI76t6LQQCicDinQTj8KVARimNeouV+Ws00nlcrtle73Ln1gPuPHlAZziivbSI/vjrFC6jWasDFo1GXvCTdOAUogAhBzCTYAA842z/4P0HTo2ZwiZxMkGikY0VmvM3aaYtpMuItEcqA6YgK/qYYkiZ9SlHPUyZIQToJCVtzBO3FtG1OZARSbtJPbpEVKSUtkdm+wzLHjvZgK41dLxj28OOdXQsDBAMBRgJSkGkBZGWCFk5YNJ7hDMIJsOL/bgFUOK9wzs7NgBAWI9ymppKmW8scnX5Ha5cuoE2DZ7MrbK9nfHF3fvc//wRW/1tHm884Ee/8SPMLbVRXjIvWqRETJ+9J3MCAuefU4sChLUDZhIMgAPMNAdC5X/gFeKFAlqIxmVaKz1UuYy0fYQdUGSbFMMexWibMuuQjzoUww6mGCJxxEkNXywDDqE1qrlIUmvjmwnDLCUbSnZ6JZt5l/VhwU5Z0BOOvlKMhGCEItcCozxOgtQadBVJmAi+wCO9R3mPEJP1e8TujHbrLNYWuFIhrCRN6iy05ri8cIW3rtzkrdYHpMxRa85z9+ET9Cff5fHGY9Y2V8lMn1o75tq7V6jJlDSOSYggiP4F53Q6AkIgYD8XezGgo7z/mQLuZ3j/0wv+TO7bu+4v8nsbeDr7zka+8p6FwwPeRwg9R21pBUwLsi3cwGOHG2TZkGzYxWZdTDnA2hHeZzjvKI1HlgOEGYDLiZVH1hLwitwVbPU8D4cZ6/0hm1lOz5YMpGekPWWkMUrhlMZLEEogpMAricVjfSX8ApBCoETlPFUzWyRS6Kp+wTlM4cF4EhWzsLDEzctv8f619/lq6yMWuAKATN7nytUvaM61KH3B5s4OyX3Nlc8ucfXGZb769lcZxnVqJHg8CXEwAi4gHoeYVv4pYX+ejoDDd13cKECIAEzxYt6/n9q1uu/2b/6bUz7CwPllPAnQ2WrpXFXN0SeWoCQ4gR05SluSlTl5WeCcBSVRtRTtFR6HE4JMQelLRmZEXA4QhWbkLeujAfe7XR7s7LDdG9CzJZn0jATk3o+H9wlQGqkVQkmEqAxZ4xwSjxQQiXE6QFaHiAfvBV4opIsQziGtQMmUudYy16+8wztX3uNS8xIxe33+GSMEgnqjQXOuRS/rsT3o8OkX30fHmqw35E/8yB8nrVUGQNVaqA8ZASElcL65/Zv/hvf+7H/B/ijAwXRAiAI8DxfXADjW+z9i85F9/+w3FPyuORAIHIkfT7qbIJBVNb0rEGIEpkMx2iT2BfgBQuR4UWK9pXAOh6jG+cYxWnu8cGTWkqHIywzT28Ibi427jJxls9vh0dYm670+/dxQSIlRklIKrJJ4pfBCIVB4oZFC4b3HOgveYwWgxjH/8cqD1QsZLx/gQDqwppry12os8d6Nr/LRu3+EpfnrxKaNcY6RL/AocjtCWUk9abC4tMSwHJJnGU82VmnebbDcXuBrX/uIeu1d1ot16nGdaOqU5XDI6U6BwLnF408hCsDR6n9BowAX1wA4wMxGwOD9B14Ws05EQiKcATusbvfv01+9RT22pJFDiREysvhIYlRE4Q1agU9U9U84hmXGTlawMxrQGQwYskEmNLmDQZ7THQ4YliWFUDil8JHCRRKiyvt3AE7gjYDxVL+qwV/iFeMqwEp8va/2xUusBUqJ9BGpbNBoLXJ16SYfv/Mj/ND8HyXHU8qERNSJRIQDFmkyp2vUk5RWe565YsDGxhq5NWzubPJ4/RGPNx5xqb3CcDSgJVrUonTfe7hraF+8c/eF4nSiAHv3hyhAhQ5+asVxdXsn8f79lNEQ3tPAc+FLBBaXD/Bym9HmF3RWP8PVBLKVEqeauCaptVsUAso8pnAlhXAICyWWbuHYzAo2RhkbeU6nsAyso/ACi8QJhZASHyX4SYGflgjlQbiqDmH8BZZeVsH18YprAgs4nHdYD955vAXhBDiNEAmRbjFXX+Hq0ttcX3mH6wvvIamRmz6xqFb8k1IggbaqUxcpWmoazSZzdoH+sI83hsIVbPW2+PLuLbRQLKcrmNSEcP8FZneNoJcVBbiAXMzVAE8y+OegReAPXk55/we23fmt3z3tIw6cO6bPQA58AcIiZMFouEN3Z43+o9tsbzzC1EHQph3NE9UTWvEyvtmk7HXZ6e3QHXUY5AOG5YhekdEtc3aKgu0yp1uWDEpHiURGCVFcJ4oihI7HIf/J+dLhvMCN4/vCKyQRSkikcONLA97g7HgCgIEy8wgHia7RbC5x4/I7fHDjI95tfZXl+mUSGsA8qYxQpGi5f9a/cpUxECcR9WadKI2xhccLz6gYsrrxhLlWm9pKHaccGQUxGoWaUQsQzuvnmTu/+bu8++PjKEDl/8+IAszihFGAC5gGCCmAkzCz8p992/bZDYHAkUxC1tMr3htwQ1AeJ0uGWY/t9Uf0t1Yp8j7GW3zq8I2YWq2GbNTQtRoOT2fQ48FgyNrmOt1hj5ErKaUgVzDAkQlBqRVGKFQcIZMYGScIqbCIalKg89VgFQAhUUIhpEZIhZIS5eU49e/xtqo9kGiErVIEkajTSJdYaF7hytI7vH/5a7zFDwEKRw5EJHKOvfWC9zDOYGyOdSVOWFQskVKjEomTls3OBo/X2yy1ViilZcQQSQOFGnceTk7mQf4vAtMBgL2VAsf3earBQHtW7YUT9GclGAATDuUAPAe37Ltv1v7H5RECgSPx46r/RaQsAEM+HFE4j48jCuHYyXLccEQtzRAyomcNq2XBw2zE3W6fJ50ug9EAI0GmMV5oCqVwWiKFItYRQleev1NVaN8y+bYKhJcgQeyW9wu89+NCRV95Wo5qnSIDBk/sI+Zr8yy0r9JqXGKutsJicg1FE9A4chwRHociOjS7paTEJ57CF/QGXYamj9QQJTH1JEGnmkE2YKe3w9AMiWVEgxYGQwL7IgBB/i8Kszz+o6MAs/392d0BF5GLZwAcFf4/auMBd/9g88DBrMGd3wrFf4HjmPiq1dnHeYcUHpwdjwCWeAkyUpWX70pK4xmWJd1uD+EERTxgpyh5uLXBw61NHg+HdKzHqBgRR0RJjFcSIzxIiYxiZByDlDgExo/H+UqJELJaO0DKaqjP2GOyzlc1CQ6kACk8ElBWQeGRDtKkzdWlt/naV3+MRC2i8ibX2u+wyCWgjiQa52IPV+qXFOy4DqZmKcjZ6W8xsENk5EnqMbVaNX7YCENv0KEz7JKR0cJjsTPCtwc3BM4jd37r3/DOj/8Xs8oAgKkowKHiAGZ+Ry56GuDiGQCzOK7477h9dtU/eP+BkzPtuQox7qmTGtgGMmSs0e0GSjQoRjn9ckgnKxnlOww7A3pCslXkrPe7bPd79MuSMk7Qqo5OE2wU4fHVCoGAUDFCRXhZrdxnnN0tqJJCIFBIoaviPAF4h7Ml3hvceCU+IQRaSKTXxDKhkdRp15e4sfweVxffZbgtuDz/DkvJNRJq41cXAW5GXbanIOfJ8BF9ugzcgMGoRy5y2vMNGq2UWi1BSYkxlqEZst3Z4lH/IWVqWNQLRxQDBivgYjDt8TPbm5+2ATjiWxG+LhfMADjJ3P8jhXyqCnBSC3Dg3uD9B57Ofm+4Ov/o8T8FpESNOqIXk/Vga5Sx2emzNerRsYZt7+l46HlLryzInMFICZHGRREkMaix5y2r/L71oqrWp/LGhfLgPdZbrK0ketcIEAKEwQHWGqwpx+N/Jcpr6knMQnuJm5ducm35bRbaV1hU12k1YxaSyySivv/VTnn/lefu0ChG9ImaisFaj6zoU/oROpG02ilz8w0iLXGlxZaWvJQMRn0G2YCWzKqliAMXln1RAKZKAp+zJfAQFygKcKF/Sk/1108y+Gd/C0EgsMu0l+qp8ulyRji8Sq4bJiekQgu6zvCwu8Pj9XXWd9bYyYb0vGMbR19Kcq0plcRrjRcapMApiRMCBSihkErihcOZEm9KVCyJkgipIpy3uKLEWYN3VcufQiO0RAqJEArvBdY5nK36rqXQ1OM5rq3c5I/90J/kav0mw1LS5hIiqROL2ozXtoelJGNESkzHbvL5nU/47vd+n+3OKmkqaMzXmF9s0GwmWGsYlQWZyUE4CpfjJqmLIw30i3HSDsDu531kMeDeLk8T9Iv8zbnQBgDw3MV//uC2oP+BA+wL9SP2Tf2b4HAUDBnaAbH3GD/i7vYWdzY2uLW2xpONdTr9HYbOMFKCDp6hUrix16+iqMrhT0b2eo91Bi0UarwcsMXjnMVaj/AKJRQgkLIa8iOcw1uD9QXGVm1/eIN0AoEmVppG3GClvsz1+RtcXXyH5foNFE3moiYRDeRY/KujqGIK4kC0QyMpGSHIWN24x7e+9e+5dfcTstE27XZEe6FOsxGhI49xhtLnlC5HKw3K46XHS4G/sKfrwC6T863Y9f+PbQkMxYCzuTgGwGkW/x3w/j1w57dD+D9QcXDE73Fs2Q6dbJv13irZsEe3v8Wt1R/w8OFtVtdW6fW6lK7ERpJSK0oPJWD9uDIf0FIiJVXY31mcc5RiXOQnBSJWSAcIKI3BeotUEq00Ukmkq8b4UhYUhUN4h5KeVGuSuEErabLcWuaDqx/ybv1drl66yiI3UdSxaCTx3mvHgffj2gYwVe4BjUISkwA7xSpf3v6UB/e/YHvrEVqXNNp1Gk2N1hbnLcZmWJ/jpUVEILVEKDFu/av+0oU+c19w7vz2/mLAI1sCQzHgTD7/5V+7DhdqNcAT5P/H1w9599P5/93L6bzARXkPA0/DU4n/UUaAw5OTUyOlz4jb3fs82lrj8dYjnmyssrr+mLWt+3Q6a4xGW0hKdKxRtQivIyQgbLXoD1AtvOMlWkgEYAVVeN95PBKtFVEUIYWucvpFQWkcSaRJkpRERUgLriwxzmCNAe+JoohmVKfZarLUXOLy3FU+fu8bvK8+JK7VUcwDNRSC6boGgRyfScddDsJjKNDEgGGjeMC3/vDf8/n3v81O5yHeD2k1YpqtiCjxODeitJbSlHgsSgviJCJKNDKqxhGHdTYDFe7pHvyusotxSu7i8vkvf/P6wW0XJwIwiyPC//uvH1f85w8/ReCCMmnuGwvzbhISJmcoS8nADNkyO7ydvk2HPuvFNp89uc3txw94sPaItc1VhsNtrBkghSWNFUkscZHCKwVColU1s9+rcY2Bc+CqU5zE4YXHYaky5uCFrlb285U4e+vwxuPVuFPAeFxhwFgiJEkUM99qsTC3QLPRpJ3O0a7Nc6l9jRVuYrBAjapocfod2F+Z7/HEaAw5oOgXj7l1+1Pu3v8Bm9sPkapgfj6htpCSNDRWOzJTUBYG73zVlqg1OtLUGjVajRZtWrPl/xx7a4Ej2HX6j0sDzCoKvFhpgFnCP+FiGADPHP7ff3lk+H98/c5v/9tTOczAm4v3lV86XeTnbI5QAkECWLbKNdb722wXPR7trHGv84jPHt3mi/v3uL/2hM3eNoN8gMcQJYpIpThtyaUF63De4FWMH0/oc6Ia0uO9x1qLl2PRlAK8rAwA7zC2BF+tqa6lRiuFRuJzT2FKpHUoL6jrGo16k4W5NivLi7SbC0RCgVW4Akpv9yYGzliFb7/4OwoyEuqUDFgrH/H5rW/zgy+/xaP1WxjRZ24hRjcjdEPjY0nuDZRV+6EU1XEKYpK4RrPRZIklLnGJPn0c/pD5ca7P4oFD3Pntf8s7P/6fszth8qnFgMy2AY7a9AanAY4T/WkuhgEwiyO89pMX/x3/PIGLhdg32hfA45SjYESdhE2ecGvjSx5sPebe2iMera/xYGOVtc4W24M+vSLDCoeIBFEUkcQRkYqQFFibY4zBCofEI6VECI0UDk+V8zc4lACtBFIq8FXPv/OW0ji8UGg0kVdIL5AWMAJhISKlkdRYaM1zaXGJSyvLrFxaplarMewN2d7Ypj/qs/ZklaWryyjqzJEimV317yeFjWWHJHJ08sd89/v/gS/vfZf7Tz6nn28TN6HWrqPrEVb7SvyNQ8jJ1EGPFpo4rdGsNVFC06WL5xFztPd1V4hxo2LgAnJAtU9eDHj887yJnFT0pzn/BsBz9f7vhQAOP/wYYyBwYdj9hjiHlNXo3AkOkAg8GkHMiIxt1+VRf5Xv3v2ULx/d4/HOOtudHUZFwciUFDhUpImjGJ2AiiqDwjs5nqSnpv7J6mvoKw9fCAeTKX6yGumLt3hXrdwnJwLpHBiJLzy+EGgV0YybXFm+ylvXbnJ9+RrXLl1hZXGeWGsGRY97/TuY/jr9bp+H9x/QUi3mmyvouibFILxCULUNSqruAk9BZrtEkadbPuHLB9/jzpNPedT5kr7dQKYlSUsTN0EmDusd3liQHqkkAok3laEz35xneX6ZmqyhS01NpyQi3v0ExK5rV10PqwVePI4T/f3FgEeF/o9R/zMcBXgewT/I+V8N0B9x8+DrnlXnd9RlCP9feKrselXsN02JJ6MkJqZDzt3OLe7eu8u9rTt8+egOd57cY21nnUE5onAlXoJIx2OAtENqA8LhHHhvwTm8l5UwSo2QGu8FzjqstzgcUjHu3Ze7MU/nK+ME71BSESHRTqBKgSwksUtYaCyyMneFd69/wIfvf8TNSze5El9mjhoFA1bj+zzxj7GjgmGnz2PxgEZUh2uSREWIyFYz/lHgFbFMEDiG9NgYPKA72mBt7QFfPv6UJ1t3yMpNdL0gSkGmBiOHeK8oHFhAKIlSEVqC8QLtNUvtJS4vXqalW6RlzEI0h0KhpxIAlREkpn7S58CdC5yIO7/9b3nnz/znJy8GnP5qTJfpHNjtLPL5v3xxwT/I+Y8AzOJ5w//+wL7n3XgKHImc5MDVlBCNxf9JtkU9bXK3f4//9du/x637P+Duk3usbq/RzXoU5IhYIhOBihRSjg0JAUpaBJZK+x34KqcvhEKI8VoBY+9/0mkgRRX2l7I6Fu8M3nq8tbhxbQBopFHETtNIWlyZv8b1pRsszl3i0sJ12iwTZXWMhKE2gEe5mHpUR3pFNhiyXpQ0Gw0W5ua5srREU8ZAiyoqUf0YLDkDv8OTzbvcevAJD9du0+mtUoohMi2JahKdeKy0GFFinaD0ClstCowQEkHVthjJmFatxUJ7kZZsk5BQm0o7uPG8ASn2VwMELhY//u6Hf0pr7ZIksb/8ybd/b/+qgG9mGuBliP0sLqYBAOxT78NVfjwt/B94c9g1/qda8/z4szxpv/4k4XNUeLnA0zMD+uTcXr3HqMj59MGnfPuTb/Fo6y5b3W2GdoShRCSgYoGIZTXgpkrYg/c4V3ky3ovxqHOBmxgb3u9+9QRivGwvaClQUlWtgN5XaQkrq4V7yqolUCrQMmaxNce1ubf5o9/443x46SOy3DCfLLHYWKGZtklFPA7ie5TTzDXnaNQblGVJXo7Y7m3RH3VwlEACu4LssPTYZJ0Ha3e4/egz7q/eYrP3GGP76NShY4uMHSLyIBzeW7yvVh8UFpzzCCeq9QZURCtuUlc12kmLhXSeWEc4DHJ82jKUaKITh/wPpwcOFwePezhO9HyBs4FzbnIpfvIbP/rH4jh2URT5er1ulVL+//FvfvsPZ6YB9oX3X5/6vyqxn8X5NgBOUv0/a4en7RiMgDeK07D2xTjc7/wk57+HwbPa3+BRd40hGd/+7Dt88oNPuL/xgI3uBkPTxwiLTCRxmiIiEJEAWU3N885W/3zVpyyEAKEqb1hUeW3rqjy/EpXHWy3coxEClJAoD9KIsQEgiZwm8ikejRaKOdVmobHAzaW3ePfKB/zIV3+Et9Tb7OQ95qMFaqJRrQUwfmskYJ2hVkuoNVLQDussQ9tna7jN4+1VopU6c4wogS22ebzzmPv3bvPw0Zesbd6lP1rHMkJFHpUIROTxwlY5fzxSCLyQKF8tT4zxYDyx18RRk8XmIk3VoKlrLDSa6AhGdGmwCMDQ9UhljZTGjI/3cC3AcYZC+DW/uTjnhHNOWGuFlHL3QzbGCKWU/z/8ub/4da21T9PU1Wo1PzYOXBzHfvLv5/6v/+fbk8edZjfA6xT3k3C+DYBn4HnC/3d+J+T/3ySmvf3p65PwOxxoZZushDfV238wYtDPB6x21vnBk9sUiePR1mO+9env8+W9L9noblFSohKFTjS6ppGxqPrvpasG9niHr5r1qykCYmIAVPl8Dzjv8d6BqCIYSimkUigxrn/3Hp87jHUIV0UTpIc0SWmmKStzy1xbusbV9lWWkitcW7nEVXWNBi10ko7D6nL8mi0CUMIDJcbmoAy6JilKT0bOVtbh8WAD6gkNPSAzBav5Og8e3ufRg3tsbDxk1N/Aq4wkBpEohB4vC+zBW0AJhJAoX9UPGAOuAFEKEpEw35jncnuFpdoCC1GbxWiOBZpI2rvvfSEHmHIEkRsbARKwWO9RYvrUNvnxHjyJixnXAm8a/+Af/IP/+e/+3b/7p5xzAmBsCHhrrbDWCmOM0Fp7gLIsRRRFvixLARDHsQf4H/4v/7d3kiTxaZoCkCSJB6jVavsuD15/07l4BsBB7/25wv/n5vO/8LhxpTxjMZ327t34M5fsNxgMbjzX3vPF49v84O4P+M7tT+j7IY+3HnP7wR06wx7WlaiaJq7H6FQjI4UTDmMMxlmMt3jhqt59IZFy8q8yNBxVON+OF8GR+CoyIEErWc36dw5Kqsr+0iGcQKGIVcxSs831uSt88O77fPTeR7wz/y6y1yBueFq0kMTUpsb4gscIi3YeJTzGDtnprTE0PWQNnLAMbMZGsY0ePmbQLdAyoTfos95ZY319jU5/m8zs4HWJjsBGAik8OI90HuE9Uonq9aJwXuOdQhpQVqB8TCNps9Ja4frCNa63r7KczpEgKenh2CGnJPc528MtfAl5vcuV+DqKeUoGOK/weLSIxq/qxQQ+dBacfZxz+yIBSilhrZ1EAYQxZtcQmBgBAEVR7BoCeZ4LYNcIOIrRaCTOixFwfg2AY9v/Zu1/4PJp+wXOBVLKvYK+g/fBrmEwweLp2yFCabZGW3z37qf8/nf/A9+/930ebj6im3VxEqJaQtKMULWEKEmQscIJsNZjjccYj8WDFNW8fiUAhZDjmfcAuyvfCYQXY8NgvN1ZnLNgHBQgjUcaSSoTWmmDpdY815evcH3lCm8vvsVydInLyWWayVVGbOJ8lYefHujj8VgskawaB0emw8bWQ7qDdXxc1RKMRM5W0aHsKzboYpyj2+mws73NaDDA2QKZOKJU7i5SZAXgHbiqVkF4kE6Bk+AE3gqEEWg09agaPXx94RpvLd7g6txl2lEd64esFdusdR+zvrPGcDhCCEmzOceSXaG1FNMmIadLLFso9k7iLyreQfzPPmPv3x9MA0wzNgJ8FEVMGwFQGQKTaMAszpPoT3N+DYADHPfJhfD/+cKPc3bTZwFjDSjQ46+8w4/7449mX5oAGPoRQiiedNaQWnNv7T4PNh7yYOMBD9cfsp1tkZU5Ko2qFex0RBX1dthxq5uz1fxySTXW14sqouQ9WCcQjqo1UFD5nVKhpUQIqiI/IcB6TFFA6fClQxtJpFKaSZ2l1gLXFq7y9Xc+4qvXP0JGjqX6EotzKzRZBqDGEiPTwUqLUtNz/AV+d8xvSXe0w9rOKjujTTI/pFSGwluKrEtvp4CBpDQF/UGfrD/EW0sSSeJIo4TEy2pkMQgkEiUjIqXRsqrQtsZjDTgDwitSVWOuMc/Vxau8tfwWNxavs9hYQEjYGe6w3Vtlbfs+j7YfMBgMEGiWzBLtxQTLABjQJMZhESg8BjF1irOuHK+QOOkaKMefrJv61DWT06L3Bjcuttz3/QoRgTPH86YBjhL9PM9FkiT+vAr/hHO8GNCM1+UPXDk2/O9n7HvSMEHg9bM/8JuVOaMyZyWtCsi2zDYt3STZFwI/mq7rsdpbR9Uivn/vMz777HO+uHuLu0/usrb9mKEZolJNrV4tWOOUo/QGZwTCW7wR+HFoXwiJjjRIgaPq57e+mujnbCX0E29fComSEiUEirGBYCy+cIjSo6ygrlMWG0tcnr/E25ev8/blm/zJj/4477U/YnV0j/l0mVTUATAM0dRxyh2KizssORmSjG0e8mDtAWvdJ2wNd+iZjBxPITQ+t5TlAIOltAWlKRC2Mia0VGPHXmLHJoXAI5RAa0WsBdI7vHHY0uFLj/SKOKrTaixweeEKN1auc33pKkuNBWKp6RZdOv111rcf8mTjPmtbD+lnfRCSodmh9EN2FteZq11iefkyb+n3SWiT0yelDUistRgxQnkJvgkywzHEUFJSVsWYCGISEi4BYClAaHbXPPCM28oCZ5HnSQNMpwAmz5NlGU9LA5wXzmcE4CTT/2ZtCuH/c8P+ufRgtGV9Y53lK4tYHHfXHqBKyeX2Cs20gdLj2fOyWsdejUPjFsugHPKw85iO69PfGfD73/sWf/Ctb3P/0QN2Rts4VaBqkqgWIWKJFa5qQVYeLxze+bEYCqTWSAVCKZAC78BbV63e511lJHg/9plFteCZ9RjnsdYhra8G+lhJXcU0Gw0uza3w1uWb3Lz8FtcWrvLOjbe42b6JRLFcu0xEJf6FzSl8hpTZoU4Gi2PIiO3RNrfNEzaG9/hy9S6Pu2tsDTbJhcUqjVUxzlqy3JHbAu+rQUSxluhIIbUct/jtVcsIWQ0orHqzwRmLLQym8AgXVeJfX+bSwjVurLzN9aUbLLQW0FKSlQN2eutsbD9iffsRO71VBtkWw2KIxTGyXUZFl82dVRYXLrMyvE7zZoMreoG+20RIUb1+ZfGUwNL4Fcd4trHkOEqGDCmNYVEvTo4aL3IiEiqff7LEcfD8zyonSQMAGGM4mAaYGAKwVwB4kOlowJseGfjgr/z5h3BeDYADPHv4f3LH/mhAdTUUAZ5FdnPl7A/dO6pPayQN64MdHn37/0O31+PBziPKQc5bV69z5dIV5ubmaLYatJoNEmpEaCyWvu2zurPGZ/du0Sv63Hv4gP/w3d/n7sO7dEYDvLLIRFFqi3Ue5QVCVZP7pK7y9h7B2J1HKYHQAjHOjVflfVWhH8LvjdWVujJCbCWWNivxhSH2klTVaaZ1rswtc23lOu9ee5uP3/+ID298wLK6TEq0+/on4g8QqwRnSqRTWGyVAhjvu02XjeE6Dzfv8aR3h4edL/hy7Q6rnTWGro/TAqESAKxzFNZSWoOUAq00UayJlKoK/rzDe4cTIGQVwZAS8A5rHDYvcLkHq0l0jbnGEpcWb/DWyrtcX3qL5dYKkdQMyy473S1WN++zuvWAjc5jutkmme9hZFZFILzCDIeMbJeB6zEqRrTjJu4KDMsCF5XUdQtJNJ5dUFLNVthig3X6psug6DMY9Chzw1ZznsW0x0K6gMMTMYdjgCdCERMqAs4uE+//uDTAwQjASdIAr/ZVvDwmoj/NhTAATs4Rn/WBzoE7v/M/vpKjCTwDM0q9HTCgJKfgcWeN3/vDP+A73/0Oq2vrGG+p1Wtcv3aNm9dvcPnyJS6tLHPp0jKtdptYR5S2ZGNzk9v3b/ODzz/n9p3b3L1/nycba2RlgUqrCn8iyP2Q3BUIA5GOSFTlDStVJfTdZFSt8IDFeXCI8bK91RK+ld0iwAuwovKiC48dOXzmkKWgFtVYbCxwbfEK7954m3evvs1bl9/i6txlrqjLaOoUDLDOk0p9SK4SVUcgyMkZkRGTMqTg7uABDzcecffxFzzcuMWj7S/Y6D9mYLoYkSPRVS5caDzVegNaKJSSxFGE1holBdJbhHdjI8DjhQLv8dZTeletWlhalNCkSYNWY5nLSze4vvIu15ffYbm5TCxjBmWfrZ011jces7r1kLXOIzr5Jrnv4+MCiUPhsNZQuAJTFpT9EmMMzhhWt1dZbF9hea7DXGuJRNWweLZ4Qn80YKe7zVZng53+Ft3+Dr1+D1sa6mmdxeYy1y7f4OOvfJ0WC+T0iWkB0YEv2Yv2FwROk3/4D//h//R3/s7f+VNQGQOTNAAHTuzT9QBwvgsAZ4n+NBfHAHha+9++soDj6gcCZ4lJQdbB/vxJkV+HDqX3fHb/Fn/w6Xf4zmffZbuzQ6xj2vMtZEOhmhqTOlzqoC4wkSWuJRRFzsZok8fbT/ji3hd8eecWj56skpmSqFEjqmlkTeOlw1tZFfEJj64K+qulgNV4RrnzVY4SU4X1hcCPFxGSUuymHAQCbzylLSmNR5QGCk9NJLSbTd5avsqHN97no/c+5IPL7zM316SuGizU59Fjb98Yh7MeH3nEgUioEBIHKDR9N6At58koGKqcB9sP+OLJbe49vsXW8CGF6uEji9ACtGB3qQGqfL73jAcSCXCVAaMQKCHHrX8OZwzl+PNQzhEhiGVEI20x37zEytxNriy+y9XFmyy3L5GIhFE5ZG3rCY/W7rK28Yjt7hrdYouh72GiAhF7lKreK2E9prRYY8kduJEjzzP62YDhqEe9FbGgWhg8a71tNrvb9Hs7bPd7dPsd+oMd+lmX/mCANSWpSugtbGPjkrmtFpcXr1KjicOOv1fleBJhEP6zyHQNgNaVvE28/0kdgNbaG2OOTAGMeWo74FnkaYJ/kPNnADzv9L8jn+oooyFwVjE4huRoYu6vPub7X3zG/+8P/lc+/eIzNnY2cTiU0PTzAbfu3+bx5irz7TaXlpdYWV5mcb5NlMQURc7m9jYPHz3k3r27bOxsUXqDqmlUqnDaU/gS5yxWeNCyyvvLyon3UlRC7z3WGkpjsN5WfqNSKK2RSiPHRX7eg/ASjMdkBlE4IjR1lXB5foW3Fq/wlevv8iMffp0f/eiHuMZbDNlBIEn3hfpTLPZQnh9gSEZGjgRW83Vu9+6xurPB3Z37fH7nc+4+vs1m/xE5XVTdEEcKGVW1C0KqqrvC7y057L3DlNXaAzLSxFqjpEJ5gXe+6r7woL1HoIiSGq1mm+XFFS4t3ODy3E1Wmjdo1xerz8QO2dhZ5f7qXR6u3mFz+wmDvEMhB5R6iJcGoTxEVXGhVKAEeGmxNsM5i8lKrHFQOlSi6Ix28F6ztd1ls9NhMOwzyoaMyiGlzSltxsiPMN5SlCNc36E2I+q1OpFPuLF0kzmWkNQoGJHQAPRJJ8wHXjGTFMDUdMDdE/d0GgA41A54kINpgLNYB/Csoj/N+VsN8KjXc3C7PxAUOHTp913309sDZ5Iq5CwYUdAxfUrh+PTzH/Dv/r//E598/ilPNldxApJanTiNKcqcnfUOpSlJdES7WWeu3abZqKO1wtiS/mDAcDhglGcYHGmrhkojiBRWOEpXYoUFxVgkq2oE4zzS+iqvP164x3uHc25cUAbS7fX2i3GluistlCBKT6pSFupzXF+6wntX3ub60hVuLl9jqb5IfTyD39sqty+mVsfTIkLraJ8kWW8ZMuKJWcNHUFLyg8efc+vubVbXn7C6ucFGd53ucJtSjFCpJIoiIg1SVhXyOMHY70apavVB50tMVX2NkxIvq9QGxuMKX7UqimqVvyRtMtda4vLSZa5dus7lxessti5TF208gp1sh43uOo/WHvBw7S4bO4/pjTYp/QivSryy46WPx+snCBBSoCKJkNU8AW8c3hmKcsh2b438Xsb91QcgIvLMMMxz8iynsCVe2mpCoTKIGIT0lGXJoOiz2d1EPtIY5+gXff7I1T9OhKRwGVom44jN7PkRgdfHpBBwuhYAqijAOCWwewI/SR3AWeSDv/z8gn+Q8xcBmMWxH+2M9r9Z3YHj63f+dcj/n0U8lTcuhaKb9RjaEbce3OHb3/sOX3z5BU821iidQScxRIJSOJwGYoEXULqC7tCSlSO2OxFq3KJnrME5VxWzRQqdxshEYwUYV030c8KhlEYpiReumttvHEJUtf9KCqSSaKERTu5OHpTeI6xDeIn0DltY7Migvaau69y8coOP3/+IH/nwG7y//A42L1ipLbJUm2d+XM2eqnQs/oe9z8mYHwM8KTZY669zr3uf+ettVtdW+YMvvsWDJ4/Y2llnOBgyzIcYn6FjSZIkxNqjcDhb4kqP8x4pPUg/NgIESmqqSf4OhQJX9feb3OEKjzCSKK5Rq7dYWLjEtUtvcWPpLa4tXmOhsUSNOiWW7dEOTzae8HDtIU+2HrLdXWdYdsnVECdyUA4hTfWqjMd7AwKkqFI9YpyK8IhqeqLNGZSWwhfIrINHY52kMA5TWoyzoF0l5LJao8DhKE2JMRbbryY2Si2JVcpXLvVoKk1RltQSf9jhDwGAM8GkDmC6EPCk7YAHjYDpdsDX5e2fptjP4mIYAMCxofw3xvYLwOxBLB7IbY6Uiq3OFr//vW/z+9/7Nt/5/FNWN9YprSVKKvEuhatG6EqImzUiG4MxeGsx1mDyYneRHaEEKtJIpZDjNjdPtSiQdZMCvnENgpTVWBkP3nmkdSjpqzy5VJUR4P2kX7na0TjwpgqPW4EWEa24xeLcEu+s3OTrNz/ij338o7zFNTZG6yzH8zRknYnaKJLxVL/975EDdugjUQzI+GTrFvee3OXe+m0G3++zsbPB+s4q/UGPvBjhbCWIiVbEqSKJQSmPt2XVpmht9bORjM8a1Y9GSYmWMeBQCLwRuNwhjEI5TapjFmpzXF68zPWrN7l55SbX564zHy+QEFNQsDna4f76fe4+vM2j1ftsDzfJ3Qgig4sNTpiqhVBavKvaKjEWhEdKUFJUnQZCIiSgPd5ZLA5jS7xRCBGDjPFKQezBWZz0oBxeVhEap8bLFBcFRVlQlgYtIxLf4MGlh8Qrc2RZTlM7dHD+zyy/c/vz/wVRRdb+6jd+9I8ftd+kHXDCwTqAV9kB8LKF/ij0udK+GeH5Y1sAj7QD/Pg/P3XzXL1T54ZpQ8DiaNOi0+3w+7//H/mP3/s29zeeUDiDSDVREiNihfUl1hmUUkSxrtq7jMEUBbYsqsVqfDUmWEUKrXXVt6/GK/N5N87lu2q1PiEq0bceVDWtr+p7l3gvqBbyGxsC45n/xpZVL3xp8CUkcUwzbXPlylWuLl2hrdt85epXuN68zBLzpMQs1xZo0TgwunhchDfFsBzRsX2e5Fsszq2wQ4e1fJ3P1r7g9v1bbHbW2cm2sLZEKsBbpIZIa5JEE8eKSIHwFuvsWMwFIFFCI71CGFH9LlRVCOg9lNZQWoiEol1rs9hcYKG+wOX5K1xbvsaNyzdZqV+hSQvrSzb7O2x01njSe8iDzbs8XLvPVmeNkR1AbKqWycjhxq2Fu79LNzYABXhX3e+kR0lQVO+/iABRDRuyxlTv/+RzkQrhx3MPhR2njqgKNyOJLy1FWVLmfUS5gSgSvly6jaJJWjZpxyVxku5bIG7/UOXA62S3adsL/sV3v/V7uwt6VT3CgNjruBHwf//f/90Pj6sDOMiz1gF85TWJ+0k41xGAk/f/n6D976jugMCZQCJoR9VKcdubW9y9c4/79x7QKQZEzRqREFVf+nioixdV/73bXYWvqphXWuGVQPgqAiBlVejmrMc5jxW+mnQ3TgHLsddvrAPvUVITRzFaS7QU1fK61mKNq9YIkFW7nDMCZ0AWHl8K0ijl+sIV/sSP/gm++s4H2G3LV5bf49rcVVZYQCPR1I9ct2BCiedu5wGPO+s82HlC0qqxPtzg9pPb3Hl0m0ebD+mOdih9jpCeSEqqZQhE5Q7I6n0xDoSrlhaWRES7UYwIKTTeV3l+7yojwFooM4P0glarxY0rb/PVtz/k2sI1rsxd47K+yhKXUNQpGHKvd5f7Dx9z98ltHu7cZ2e0Tme0xciMsMrgKBGuSpEg3e5EQekFAoUUimpNhKqw0niHEAYlFFpppPBVEaas5hF4XyKcRHrG2zzWV7MMnLPVGgxSVQaclngcWV5gB11cFvH4yTpL6SZtISjqBSLZe8+997zIkrGB06YS/8o3mL4+Yz8E/8f/53/92cQ+2P8Z7j3u0MPPyWd9rg0A4IT5f/YE3h+6Z+960P+zwRH51l7WZVAM2dneQQCNeo1SeryaFNhVo3UnK/AJ76vQNyBcJTJKKaTQlbcI1fAaa7HWYLzDCo9XAqJKMKSQVUTAVdPvpFcopYijqKrsH0/5c2VZTfrDoaUE60lcTBTVqNVrrMyv8OH1D/ja21/l2vwV5hbnuF67Slu1dqMcwgucOLyGgcExICOlziP3kD98+CkP1x/zYOMx6zubbPTW2RntMDJ9cp/hlEHHAqklUSSrGgVR5dGt8DhnkXikrwwrJaNxiF2BUHhXRTW8G6celECiqamIWpSykCzQoEVU1Ehti5pro6lRAkN6bGc7rG5s8WBtjXtPVnm8/ZhutoWRI0gsIhIYPM5YwFWTBEV1LBo5XhNBInC4cc2BtVU3hpSOOKLqXpiMIJS+aou0ZrxGRGUcWByltRhnEEpWEQcn8L5qcfQOrBU4K/EGbObwujL0Dn0Fz4cenA/GH870Z7R73VPN4thnFBxTwHHOazvOvwEAnFb+/+7vhgLAs8C+RXq8370dq4iRl6zMzfOf/Ik/yeLlJb5/9wserK8yKDIcZbUYkBbIaDyhbmwIeOfw1lW/9fGKfHIcLvSiighUI3qnTirjcHT1JfLjOf+TO6uRwnjGfeOeIssYZjkaSHXC8vJl3r3xNm9fu8H1+essryzz4eWvsJQu0aBOi9a+1y2FrIrXpNw1Arq+Tyfv0i0HLDSWeDLaYKvscGvtLncf3WWru0N/tEMpSpwq8MKhdLWcsI4kWkukUoxlsVqh0HukADWua5BS4ajC/NZYvPE4Wxkk0lfrGtTrTa4sr7DUWmBOt7m+9BbvLL7LSmuF+XiJJq1q6qAvkIXGlYL5xSXms23ub9ym2x9i1IAISaQlVgq8k1WofvwWe++RSLzUeKEQY+/Ou/GEQet2iwGVlKAUbtx5Ya3D+eq9U1JWnw0C5wWVnVEZCViwmceWAiVSmu05rszd4P2bH/DRWx/T3R4S6ejQ3InA2eHu7/6PvP2n/7OT7XyomHM6knPO1Z/zZAA87/K/h24e6A/cvR7c/7PCRPQP1mUkOqFdg/feeY+5lUXe/+h94v85YfjtEWa7IHcGbwwIhdSqCvEDYKtWNmsqT1EKUFU4eDJHRwqJonIovZR4IbDe463DC1e188nKV3fWYYVFIpBeoLxGClnNCyiqUHSjWedq8wo/8v4P87/5sT/GewvvstXf4mp6lQatqqJ+Bk44DJaUmCEld3oPeLTxmCfb6/QHfR50HvFw9RFPNtbY7u2QmwwrDSiHGs/pl9IjsWMJrFYa9EJWhXCuWhnPj1+PVAqHxDuPMw5berypKv5jGRPpmFbSYrm1zMfvfo3rS1eolSnX229ztXmdNKoRE6PGw3NioWjGc7Rr88SNCKcdDzfus51tYcqMwlQLBHkhEVIiLYDH+SpKY6i2C18tr1wNHXTj2gCB9wJrIoxU4+gAlMZVw5HwCF8tyiSFxnqq/a3E+fFqjYXDZRC5hGZjjpuX3+ar177K1z/4YW7WPuSJf0Ca1vYZANX1cH44W0zO3wdTAZWoH5L2Z9X6c5LyOUerAR6X1d8f0PeHts+49LOuB84CR3lfSijqcY0bl68Td2LaC3Osbm3Qy/o0n9xndXuDYZGR+3E1uRXV0rveV7n6sR9cTeqrQvpOTroO2A2Te6lw+MoAcL7q9Z/M8YcqRGyqWgNnPa6sFvGJiWm3m8ynLRbrc7x/+V1WkiUuNS6xyCK1ZkqN+u6SxbOwwjCkICVmg01ub93lky+/z91H93m0/ojN7jaDYkRhcoy3qFiiY4XSCikdVTmURQg/1Tw4jnQwWb63eiecAOupUhylxRbVjAKFohbXaNXa1JMGi7V5VuYvcX35JteXrlK3DW423qZxIIIBIJHUdI3FxiIPt4dcmlvh/Xc/wGnDxuAJO6Ntcpvhcs+48B+kQwnGSzRJrFSIqqADgcT7akSvlJPJb4KiqE723oL1cnf0chXGsAjnsV5gnagMBQvOAlYTy4S5xjzXV27y8Y2Pee/6eyzVLgOC+fYCiU4Ova6wQsAZZLo7ZlfgjzbWjrMBzmss4PxEAJ6bKY9/fDk7/x+MgDcBgaCuGlxZVBgcf+TrX0eliisPb/Od73+P+08e4gb9aiqfK1FKVIvYSImMJFJVxoAYF3btrtIH1ep97H1dhKgk345X9ENYhIpQWqGFRqHw1lAOS5QVNOttvvHhx3z87ofIkeNrN7/Ku1ff5np8HU1M65gRswaDQjMgo+N7PNp6zJf9e3x67wd8//5n3H/8gJ3BDoMsqwrcMFgcEQoho/EqfdUUP/yU8PvKa/a71U5yPJgIcGD9OCxeOnwpiImpp3VW2issL6zQbs4xl7SYS+dIfIrPBHES06B55GcUq5iFxgJSSUyS0Tc93n73LT5f+wHf+8F3Wes8YZiNcIXH5AYhPURVG6UXEuuo2i+pnDAhVLWAkvbjGQCWwlS5eiFBKFl1cfhqloEpS5wD6wVOaKyVGOMRFhKVsDC3wvVLb/HVt77G1xe/Rmu+RUoDgETXmNT7H2xHndWeGnhNjD30w3UAU5GAqYjAReV8GwAHNfvg/P9nfoLAWWK3tYf9tQAACQkR8PZb71KbbzN/bZnOqE932GNQjMiyDFsalJbIJBmLdjWSV7iqqM8ZWxXw7aaBquf3zuFldQRSSKQfF5nh8cojdHVekQiEU+Aj6lHKtfkrfOMr3+BHPvw6qYt4f+UdlusLxMTjo5Y4HLiqtW5CTk7XdUEKHmdr/MEn3+azLz7j/tZjVnfW2epvMypHWOkgqabjCS8R3lV97UKiEHvCvvs6qg3S+fEwnGqegfBVFAQA6xFOEvuEOIpppW0W28tcX7nBpeXLzLfmqOsE6WA4GGJ6BuY9o9oAhSBmTzB3PzchqCcNkiglU0PevlKQxIr6YoNiZIgfJKxvbzLKBwzLEd6XWCuq6nxdeXCVUeYRyiOVREk1XnnRURpPURq8d9XnKqtFi5xzGFdSlpbCWKwXSF29V9aCcAKdpiwsXeKtG+/xwVc+5l35AbmuVh5Mxp/RMd/GwJnkJCI/tc/B8P45thHOtwEAzBTxgxH/Q/cdNhTu/u6/O93DCpwYf0T0Zd+yv37cJib2FtUBaNMmbTUYRSWtVgsdRVWgf+zdMxF7r6q5/eP8oGPcGy4F+GrAjJdVWNz5cfubFAgp0apawtdTecsmK/HO4ryiGdW5vFT1wX/lxjt8dOMr3Fy6wULa5lK8eOg1yfFKewAGS24Kur7Pva27pPM1vvflJ/zeH/4etx7fYXVznWE+oqBARAKdxqhIjtsYJaAAD6pKZQhZhdHxolp+mPHdfi8JgPNYY3ClRzqP9JI01rTSNsvty7x1+R1uXHqba5dusLywTC2O8WXO1vY6Tx48Yr0zRAuBugoxDUZ0iGmMawDGf3BiOCmJpMHl+FL1eSUK+4HlWuMqj7uPebT2iMdrj9nubZKPCowwqLhaThnpJgeNEL7qWhDV8RsPFoH3sqoLcONll301P6iwjsI6LJLIVd8j6yoDQEhNWmvSnltgJb3CZZZZYwvjHSUlkdgbHHPQ6AycHe7+7r/j7T/9n3KoF2BWS+Bkl5lCf47Vn/NiALxgeP7IR4cAwGvFw3h+/qwiTLHPSHfeIcT+LnmLxWIoKMmLnCzPMKbE46uedqref4/A2GrCXNX6Vw2HEQiEUlU3gByfIbzDOVtN36OaA6CVItaimhNgHbYwuMKTqBqLjRbf+MrH/Mkf/ZMs1uZ4e/kG15qXqcmYp7GT93jSW2Pghnxy53NWd1b57N5n3HrwJVvdLYZmWPW6K4dXAkuJFwKQeFmFvysXnyo6ICUIhUDhrMN7N66yr1rrpADvLL50+MKi0KQqYiGd48bSTd66+h5fe/9HeOfaB6yIK8yT4vB0kjWypEeeD9nYeoSUlrvvvMVSukyZOeajBKWqU021xIbbNdQUmibzKAQaRbqU8GNLP8ad8jZ/+P3vVFMac9gcbDMoBwgHOtWISI5TMuOVD22JN1TjlQGhIoT0WA+mHJt0ojL6Si8wSLxQWKEQXmK8QzqBMZDllrywVUcEVReHFNXwoN3v1vg7Mnkdx3+P/eQb+9R9Ay+BIzT8haX9HBQCng8D4ADH6fZxpYIzNwcj4LUhoBL12QXx+/f1h5cEtli2y22ejDa49eUt1tbW6Pf7GGvGwh2NG8wldjITwFdiIYRAqyp0LKqxflXY2VaZXj+2Sao6I4FEVV5/bsBATadcnl/mnatv88Nf+Rpfuf4OsVFcai3REOm+Xn7rLIhqGV2oPMvtUYcvN+5yb/shnaLH733nP/LZnc9Y764xKod45RCpIIo16GoK4mS4EVRrDVTHDV54LOMCQKHGZYBgXbVQEaIq//NUXr9GEkcRrajOcnOBa8vXeevS21xbfpeVeJl4FGPikm1pkNLiMGglQJZ0hpsM7ndptmssz13i3Usf0tJzeBImyzZ7X41SnjYCwBNRI6akTZM55mkzz1vzb+FLQZTUWOut0yt7ZLndbfVzXlTzGZzFeocEYqWIla4KGU013tk6ixdVVMcJWY0EFgovFM6Lqh7Awago6XR6rK1t8nhllSvtK5TC0KCGFnunSyXUidUjCP9r5HARwLE7XbRCwPOxGuBRr+FQDcDk0h++PSkAnNo2OckHK+Dsc9ATs1TzfDc6G3x6+1M++ez7PH78hG6vR14UyFihq6XukEJULYDjeQAIjxICJ6YWmPGVYDoPftw6h6j61J2pDAOTl9iipBbVubFylf/kj/wJfuzjP8LNpWt85dI7UHiaun5odG81t3zv+B91N7jz+A5/eP8H5Drn7tp9Pr31fR6tP6SfdyGR1OKkqu6PVdXL4301jEhMhH4ctRgXQk0K4NzYYHFeVgWO1uCNxUmD8p5ER7TiJlfmlnj/2k0+vPk+Hyx8QHN+DjeKWW5eo6kX0WgkUDJigEcpSOqazAzpd/s0H9QxxrCyeBmvLmPIiYjZLaDzlbGy97kJlFe0xRwQczW6wehKSTOeY2nlEiOV8e3P/5DvffkpO3kXlxkiISESmHE1v3UwjhshxgZV1a0hKMdpAC+rqI6QeryaocJUazeB8wxHOeubWzTkQ5bqt1h4a575+RaXVZWuOa7Qr3rnjxeJEA14hfjdsr/q/5Mlt6cLAfd9DudR4o/nXEYAgKcUAD7jYwNvHH36GBwPVx/yve9+wve++JTVtVX6oxFWGCKqfK8Yz+4XCJytesSFEFWvP1VY3wm32yNfnVPk+EQvxznzkonj3dANri9f4Yc/+Ab/2f/2P+Wjmx+QFJo2DWQsxsvI7sdTjfCNEXTI+d79z/nuZ9/lD29/wvZoiyc7q6xtr5HbDCKFShQyqRYmqlL64+WGxwasEH6cPqmiGVUBg6h6+V01BREnkE7irUI4TyQjYilpx02uLS5zc/kqX3vnq/zYhz/Eh3yVjIJRVFKTbWL0lNAJPCVelKTN6P/P3n+/N3JleZ7w55owsAS9SZ8pW1J1dbXv7Z7Zfc0+z/7w/snvM7s7Mzs9O91VXUZVklJS+qQnQfgw1+wP9wIk00gqI1VlikdiEgRIIBARiHPuOV8DwjCcnPJ07zE6ybh35x61KDBUdOghSYMaY0zSF+foQqiAUSDgB2727tJpdsnOcjrXuhjguD+gOvVM3BhnIisjrsbnIyNjA51TCRfxHBInFTZABJDMVQ0lOKidC2wH77FViS+PUbWkkTXopC3uNe5ys3mDFJhR0iRfHDsDC2PgIQUKQYeMghKAxCeLzs5V/Injd8nvPxAg4JtfAHxtYv9mAODLxIBX9P+vCoLvPeZiq8ZZqqqKyTe2thFBeEeIQPMSAQUu4py+oMLiOeWMB08f8ennn/Lg2WMGkyEWGwRk4leQ+COslpWMH/TQOncExH/YoHgSiOA6530QxnHWUhcl0kqWOl1u7lzjR/c+4G9+8le8e/MdOjRppQ104AS84n2G7e/XQ5pJm/3ilEenz/n1o8/4/PGXHA2OGBZnOO3JmilZlqIzSZJqtJYgPA4b3gLgI5rJuyAaJCL0X3iJx2Jt0C7wBjSKRGjaWZOVzhLry2vsLG+y1l1iq7PCtc4OXZaBBo6CtuyQcA6Cc94ghMNhMK4AbVC5x8mKs9EJZ8NjKj8jQzJgTIMmKYGzvxjXCL841pf3j6CZtEgSDYmgpOL65k0+eO9j1POM3dNdBtMB5aTEJyC1iBiHsA9q63Bz2oMQoe3vfazTghWzj2wH4yGYx3qcrQP10AqyLKO71CHvZbzbvMcaHYZ2hJPBsrn2lomv2NLLcYtVJCeGLtHYjejKNsSjfxXfcyyS9uuBgIs8//sCAd9wHMCbXwB8V3GV9P9k4YHCBSvW4+mA53vPmc5mGFsjRQTdJQlJEgRu0jSj0UgDwl8LhtWQSho+f/gFn3z+Wx4/f0r/rI/RHpVqhCIq+QVLXjlXFVQymu2E1bL1gSUwrw9ETP4IGZgD1uIqiy89WZpxbWWLf/6bf+Z/+bv/wEqvxzU2ydCv0fQLBUZBhUfy5PAZw+mYr/Ye8uv7v+Hx4VOORidM6gm1cAgV0P1ouehaLJ6EuQSRvLDy90HFR4BQsfHuQFgXcAq1R6sG3VaTnZXrfHjvfT5670e8s3IHY0taNmW92WONVSClSY9wuQjvxvma2s+CZTI1pZkwKc5A14jEUdsZ49kZw0mfKUMqV1LJAk1jscpnsa3itdfQhIz1dBODZbZq0H/d5Oa92/y3n/8Ln371KbNphXWxyxEtgT1zy2UPMtAinRQ4VBiDOHAuujn6IIfkhQDpMSKMjib1lOPBCU/2HtNq5Wxka9xdvcWp7XNaSoQTFHXNzJbM1ioUgpGbYWtDViqctsEWeVkiDbR0kwQdy5z5vPlKN+B7i7d0Bf+HxltXAPyO/YBv9WSP/9MVBfC7ildRqRxQ2AopHc9O9/jZb3/JybBPVRYorciyjFaekaUJWmsazYxWt0OeZaDgbDRg93CP337xKb+9/zn98RAjLSpN0HkS1f2Cwp23YZUcbHqDEM+8nT7HhgQwfSgMwgYGoxpXWRSKdrvJ9so2H979EX/347/ho5s/QsLXJn+PZ+wLDkfHGA2/efhb/vvP/wdfPnnA0eCEUTGiwiAaCbnUAfSnA/JdiNDvdsYzF8oXQqAQRJ2fAIhzwfWQSJHEeoSBzEuyNKPX7LHW22B7aYvt1jbvrN/j3fwe/fqE1aRLi8YF+l7KxVWUExbjZyS0UTjKashodIITFWkGtrLU9YTjk30ern2FKnNay0s0X2FAfjEpnp8D56ZHKRkSy6pcZZbWtLe7HN084exsjLWSUTnA1gYvQOmwD4KA01zeKGAhnAyYAOMMtXF4L4LCoNQIJcJ+0gLSwCqZmikHp0foxxpT13y1/oBm3kQiqKuasjBUVcUvH/8mKD5aRz0rqWc1jSTj3q07yFwgKthsb9CVrUtYlSsa4Xcbj//Tf+bW/+d//p2T/w8JCPjWFQDfPvxL318N/r9qBfwpwglYIqOWnsPxKY92n4CCLE1ppCmNKidVCqQnm2S0Zi0azZzaVDzb3eX53i4PnjzkuH+KFQ6dJqhEoxONk0HhztoaYw0AWiUIEdp5zp8nDxnV/kTUwzfWgXOY2oBxtFot7l67y19//FP+6kc/4YNb77JJFwevTf4mYvJPRqcMqwmPnz7j3379cz754jc8O9ildDVeg8oUKtNILXHSIQXBvCd6DuBcLFQCA0AqGTwEhECKoIhXGxNMcKwF40iUZqnR4c6NO9y9fo8GLXaWrnFz9RbX82165GTJBo0Lrf4Q55e9eZO7JXtARouEaTlmUg5xvkKmYJ2jdiWT6YDRpE9mlqjrCqfdSyiIi4lwLrvs8aFAc9F9T0BL5WypDTyCe9feQfqM7tNP+fzhZxyfHVObEp+r0OFxodPrPOeuhUIEzX/vMdYGS2Ol5g+F/ZbIKOAkqFzFyfCUylQMpkN2zw7oNros93okOmE0mnJ4eMRkOsHUHmUFpqioy4q2apA2U3ZuX2c0OKNJk267demkuMiEuIrvKi4CAV91z9f2/t/6+GEUAN+kAPjSXVdJ/08VHo/BMhieMcjH/Pq3n/Bvv/w5D549QiaKRp6TpwlpkiABY2uQoTDIGikIGE1GDMcjRuMxtTeoRAY5WRWQv1IGWdiFC1xEpDvhARuAci5cnLVUISF4ibUGZyzCe7SV5GmTm5vX+Zsf/xX/v//1f+PG+jWWRXcBCntVVL5maMZUyvHl3kN+df+3oVPx4HN2j/eYmRki1chMIVIRAIjMW/nRIEfFFOkJ5j3+PMEJJVFCoWRkQlgRFA+9QnnoNlrc2LjOX3/8V/zFh3/J5HDK3e4dNhsbrNADeEXyvxyCQB+ynKHYZMIZ02JIUU6wrsL5GuM8xlZUpqSsCpRPMcaElv9FbFXk0s/vF/FiLOMlunY1zlUIJLlISeUyBsGtldtcX7nNytYq02lBNa3pz85wpUcmczOhkGQtQeOBSPYJ3kEBxuhwseMzx5RIhBZ4A2VdMSsKhuMRZ6MBx2entNImedYAD0VRMh5NmJUFznmkBTOr8CawPZbWe3SWu7hhRU90ubm0c/lcv5IX/57jhST/TfP+N3y+/23izTYDet0HyL9444UC4NLjr0IFXrjv6kP6ncar2qBFUdAfDtl7dMCvf/sJn3z+Gw5O9qm8p9HIybRGKYX0nspUGGMQgNKSJNHIVAbzm0QhtCARSRQFAmuDCx7ynLIlffgS0eedmFSlEMF73gu8BV9bTFGRKEm32eHa5jV+dPd9/uqjv+CdjdtoBE1eNoqZhwNGZsbj011mvuZXX/6W//9/+d95svuYs8kIpz1pI0VlCSKRWGFw3uB9VPATIoL+IJRK88QvozuiwFnw1i6Si7aSXDVpZU26jQ47y+vcuXmHD298yGZ7M2AX0i3aUet+sa0+aBPICC18mUytcFTgHnNY7zGZjDCmxrmgpRD+yuExGFNTuRprzSsuuuLS6n9xX/iGx1H5msQrRJWQ5SkSWGedGTPe2XiHJzeeUc8M8vAZg2mfug7AQJ2c0yC9AG/cAuerotUznuDoiAcXhw5C4IWn9o7KlHhTUlY1s1mJkgpTGqq6jAJVkdbofGCElJbESaq04MGThwghWW+vcHftDpN6SjNpLt7+1fz/e4gXCs7XL/TFy7/70nO95m/f4ELhLe4AfNNK37+iMXCV7L/vcM4h5fl6WSAYjUYcHx2xPziiPx4wqQu0q3ECKiqsM2ih0ErhkzDzrWuDLQ2iBl0pkkZKLvPQ2pehJTxX8HMu+MLjPFooUKCVWqxEbfSgVz7Y+YpI8XMWlPXkOmVnfZN//ru/5x//5u+5tnKNTXpcSAdcvFI4PDWOGYaD8oyv9p+yd3rAv37y73z1/BEnp8c45cjzBjrTSC0Cn98bnDXn+vwQHQjDexbCI5VCy0Br8y6IGdVljSlqlFC0W002VzZ49/Y93r/zPu/27tJbXWKts84668hUvJT8AaRQWG+CP8DivdQE09xAgzNuytnkhMPRIdPxkLIswXuUUngVxifeOaypMaZcFAcXQ11QeXpVQlRSBwyAlwvwYAKs0MbSJiHjr979K9Z7G/zbr3/Gp19+Qn98gnE2dkuCD4LDhbY/HiGI1LxI87Q2dAC8wyOwzgddB+cwUbTImRpj4/DDOUxt8cIF+GV8n946wCOkokZzeHaCThLY9ExkQZFUpGQk8X3M2/9XYMDvO17FBLi48ucVif7tHBG8xQXAHxBXdcCfLIwxnJ71ebL3nN3hEcPZGKcEVTOjkpDkSbiwa0WSpmipwTvqsqQsC6w1YaGsZJi0O4NAYL3BWYcTLuQwGVbUOvrOq9jq98QLswfl4hDZeqT1ZELTaKRsLK/ywZ13+Ief/i0/eecjsku8eHjxQmGwnJghR+WQx4fP+Jdf/Yx///UveLb3jMH0DJ9CkiXoVAfVQ28Cw8BVIcnIwEn0TmClw3p5DlxUCqk0EoV1FmcttnKIWtBoNFjPV7nW2+ad7Xv83Y/+lh83PmLKlJyMBo3XjipCG/5F6qIFZoQPSM2g6vN08Ji94+eMp2NMVSGEINUJMvFoGQoXb234mlMqv2UIBIlM0TIBzyWxpAyFBzo02MxW2fxgi2pSMTzqQw1DO8AbB94hpQ/gyYiZCGzBIArjDFhjET5gPZwQYd9bsNaDlEF22EsMwU1RqOAcySKH+GAtbSQiAS0TBIpxMeLgWNJtt5n4MX2GCDTLtGPjZgFRvIrvI97OHP4HxVUB8Lq4av1/7+G8Z1oWnPT7PHz4kGdnB5z0TxGJJNEttBYhSQrQUqK1Dit3TwBvpSqsmCGgugmrtyDf6xAioOFd5H9LpYMNsDhPVAIRWNsCpBNgHaaskbWn3WiytbnJ+/fe46cf/YR7O7fp0iQhIVjLXIb9eYJtbYllt39E30359NGX/PtvP+HTB/eZTsekzZS81UQn0VRI+jjXt8HcRgDe46wJYwulkEKFxC8lDqhqi3AOUxi8qUlVxsbOKjc3b7DWWebm+g53lm+xma3RJEOhSNDICxdE64NA0EU3BbEgSAMLWKMhdABGDKbH7J0+5eT0iFkxwzuHkpJEa7x1KIK/wMJiac69vxDGlgtlxLmt78UQYt6Wj9uJC10ZEUqTDMVOe4MKwZ3N2wzfG5BmGY+PH3MyPqaiRqYCkRAlH+b4iTj7jzgQ7+ViIGisD6MURDhHhERG4QiBQEhxfmzmLAvnEY7gnCgTlIViUiLMGcPxiJmrQiFYHtPMEvIojTw/78UC/3AV30m8wW367zJ+MAXAN6XzKwbA9xfzJCCEQKnzC37tLeNyRn804PnzZ3z5/BH70xOcdyR5CrEAAA/OUdqasi6Zu9kLBVrr0Hr2PoD25m1fGbTjpZBBF565PW5IStY4vPEoqUh0EpIX4K3HlqHV22m0+YsPPub//R//X2ytbLDRWadLJ7ynV7zPkppRPWMqK7549pAvnj/iZ5/8gkfPnjCeTfGJRGYJOkuQcx1/a/HeIoRHKx246d5irQNp0V6TKk2SpCAkVVVTVwZbeHxtaaUZW8ub/PTHf8Hf/PinqBJ2mhvcWL7BltwCAj0xHIDzbQ0djBeQ/t7H1mgNvgKfg6yAXfYmj9k/ecrp8IDBsE9pZnGcEzwUnAqqhyqaJUk/xzBcfA2PdTXO13jvUSpH63yxNa9asoWexPl9ORpNhwrPtc4G3b/9J7aubfJ//o//k/FXY2bFDOdA+kihlPGYWhNa/T6MAkQcAc9VwT1BG8DNRwVxf4ALroGCSxRLJcJ7lVJG5kEYOZS2ZjAc8nz3Ob1GhyXRYXmtQ55fxIqIq9XpdxqvYwJ801+8/fFWFQC/e7qeAwJfzxK4KgG+27gIACyqmnE5Y1oWnJ72ef7sOSM/hXYaLWDDxVuIwPOujcGYCu8dWklSrVFKBxMc7yLAK6z2wqpZxiQUVl3huuvPdfSdRxDa/945TOWgCjK5y50u1zev8aN3PuTu9du0VCNKwr66jWvxTGzB0/4eZ9WYT7/8nP/jv/8XHu89Z1iM0Y0MlSrSPEVqifA2jCicxWORKhQsQoKL82hvQXmJRqG8xDsQtcfNHMpJWnmLnZUt7l6/zU8/+Eveu/EOYgY3Wzus6pVLMsQvzp3P6Wjh0ieYJ2uLp8SKMVpoKoY8Ov2K3ZPH7B49oT86ojAjjCsQ0iOlxMsoyudBKUWapmQqJ9H60vEOr+9wvg4oeqkXj5zH5UuxYH78AktDIkgJcsTLaYdiPOPayhbX1rbZO9qlrEsm1QTrakQqkGkQcarqIP8rpQg4BBGsg92iAIhfi0uEP/+6sA+Jq3cfWh1BZdEafGVwxuAtjIcTnj16RlII7q7dZtba4YKa8KWC+Cr+uPFyIn+hDHilJ8Dv+pxvbrxVBcAr45sogFfxZxEOmFVT3tm+yYMnD7HGUkxnlL4g0RKEw5SBz69TDVIghUIpHZNmSOLGmji9JsxoZWzdivkFmwtYn1AcgECqOTArzJbruqYclSRWcW1zm7/40cf85Y9+zLs332FnZYfMa5IXPj4Xk6rD058O6BcjHu495bdffMbu3i7DwQByRd7Mg45//DspA+Le+whMcx5nw8w5GPYJpJcorxAG6rLCWQcGukmT7bUt7t64w/s33uXOjZvc2LzOrfQGInUss/SSFG0wBHIvJOSAusdfUBok2AxrVgHNaXXA88FXPDl5yMHpHuNySOmmeOniWEJga7foyiipSdOc1OQkOnkpyUmhcSRI6ThX1b+4RZyzA7w/xwGIy/tbW8Fy2kF1JW1a3Ny+ztloAAoePn/MrJghhERrhXUCE5P9XD0QJM57rCN2BuZXi7lF9PmX9z50/hcASYF3wZnQGR9EgWYGO6lCFyArA0DVwXQ8xpT1138YruJPHBcvEm/36ODNdQP8phm9f+H7q+7z33Dbw5P//b/8oVt6Fd8iamsoZyXTbqC9dTtdVnsr6GqMl4KiqHDUmDrMWlWWkCSaRGusM0HUxwSqmZYiFg0gpZhfwgMKHYGb28LG15ZCopIk6Mm7oLBXVQZjLM0k48bODf7D3/8zH9x7n83uKh1a6GirOw+3sNUVlJRMqdk93edff/Fv/OLTT7j/8EvGxQSRCHSukUpQO4O1FrxEpRqpJN5LjBVYY8O1JwoQKqHQaJSTUIItLXhoJA3Wm8t8eP0d/vGv/4G/ff9vaIqcBEkvgs1ep0O/MOUJgxD8HB/hXbC7BZwzzPwMrU5RwPPJYx4fP2Dv9Akn4yMqV+C1Q+sEqZPwejK0xLVMyHWDZt4mM03SJHupAFAyDUWAn3vpvRzzIm1eoAS4XiAaeu+CF4TSdNA0VIaygjsbN0GCTOD05JRqVGOtwxiwCCzBQMihAqgSCBpPLhQA8eQI/IFQiDG/P4D9AxZAylCU2EDBFLUPx9Ml4B0JmlzldBodeu0eiuRl8Z+3PMn8SWN+LX99U+nbx0VIzEuv82Yew7e/A/DK8K+oH97USujNi7kL3MXwUXjn8aNHSC/48IMPSfKU49EpZ9MBx4NT+tMhlTFBbMWDFCkyCQh+nMMJEy7gOETU+JdzcJWfO+YFk5gIS5tvUGjDO0Fd19jSYI2lkTVZ622ws7nNtfUt2mmb1XYvzIDlfHUa/pWRV25xnFVDbCrZOz7gZ//+b/z2iy84mfbxWpA1MmSqETK40Dlnsc5hnUDJ823yHowJDAClVWArWIGdWYQQ5Dqj2+zQa3a5trLJ7d51dlrrbIhVKkraNFEXUr9zLiTEF3D/8yJmvpJV0QgpvCtHLUtG1ZDd/hfo1pTP9z7j+fET+tNDpm4EyqGT6EwowrjCO4GSmkaS02616WQdtGqS6nPg2yKkRH2NZDKErsxL51D8N+D6XUjQQIKkQca17haNTk5RzfjqwVeMZxNGpsAZcEqA1NHXIST+ACvxr+j0z+8QQZ5ysTgQYEUcG3hcbcF4tBekSUaz0aTZWWcpbbHRW6HXWkYbxeryMnmSx2cOxZeU8koU6LuK1ybmy1XAS1TAH0i8nQXAqz5M3/bzdfU5/F5jLgSkhKTdaJLogMxPGxn/9M//xOP9p3z+4D6ff3mfJ3vPOZ2dMZ7NMLXFyBphBVIHVLjWCR5FmFuHkcBcUz6Atlho5YdruIhJILTdvXFUZYUrLZnU3Ni8zt3rd7h78x47q9tcX92mnTYvpSvn3SW71+EsUP1UN+Pp/jOe7e1yfHbEzNdkOo8e9GH1PqejCQHG2pg8o+XwIsWFlXSmNK4OgMQsk2yvb/KjD37EUtbmWnuDj+58yN31u3TIceSvMR0+b6nPV/34V8+ePY6RP8WKGafFIV89/5JCHPJw7z79wT6lnyISS5IqkkQhBNja4moQLqWZNFlpL7O6tEovWcKnUZOBy9dk62sQErlQH5yPAi5v8+vi3PzHUtcVQngaScpmc41VvcLBygE7a9ucDoeUsz6VjYDQ+bjC2dhtifN8L5lrBM3b/d6DcKEIkD50H4QXC20Jaxy2sigvSZOMdt5ma2Wd27ducmt9hyXZ5P3rd9lsrrCUd2jlrZfe3tX8/3uKb5vjX/V7b+gq/+virSkArvL2mx1aKbqtFs63aHXaNFpNVlbXWF1fCY58zrPUW+Kwf8zuyQH92YjCFlS1CbPxJNACUaFt7WwdcIBR2VEqEVq1i5V7pJJF+Lepa2zpMEWNMNBd6vDeO+/x8bsfcnfnFkt5l6WsfamdXps6yApfuCYc90/48uFXHExO+e39TzkdngZjHilBeqwz+Dpsj9QCoYNMjXUW6yxApLhFrj8SYYNLofSCRGt6zSXu7Nziw9vvoyr4i5s/4t2te3SyNhDSp/MurPbjtsmF4M5l8N/rRGiG9pTd8UN8o+Tp2UMe7n7JyeQ5Z7N9rJuick+eadIsRQmJrR22drhKkpPQafTY6G2yvrzJUrJCIT0aHVr3F17OYfDUpATbXBgQEHIN4AxowteoK0LEMzhHYQoQlm62yrpcYZd9WrLBna3bDCYTqgNLvxrjjQlcfiGDOJQJlEAhw74TIgAZsREcGgsB6eR8p4XCyYFwAokiSxKaaYPl9hI769vcuXadv/7JT3n35h104bneWWdFdkhUgo54k4v7/qoAeLPibekVvDUFwNfF78UOuIrvNF684IUugEIBiVJkq1ukwM7KBoOdm3TbHY4nfcra8MXug6Cdf7BLfzrARAGcuV1vgGbJOJOPpDIBlz+yYnGYrbF447GVxdWWTKas9lb58ccf8Q8/+TtaTtPKG5eSv7EhWavYvjXeUpiS08mAB08fcf/pAx7vPWU6m6KUQKUKqRVOuNCZcEHeV87b/gtQWVj1BxS9xNWWYlrgpaLT6nJt8xr3btzm3o073F2/RVs3ubN5m15z6dL+DMntHOR3nuQvI+rPj0O4pNWUDKZ99oZPeDb+iu5Wxv7Zc/b7u5xNDqnllDR3yDS2/QkrYVt7XOURRpHonKV2l5WVTbaXrtPgBoZ9BIrLID9HJjImDEijD0HQGSgAhWHAcHRAki6hVQOtMwQK7TVeCGpfRyyGXBRz1p2PObRVbHTX+PiDH5F0MqpfWSaP7lOWc5YFCOvDDGBhS+yjrPI5+t/b8/MIbwP7wkm0UORpg2beZKndZa23xtryKtdXt7mxcY2/e+8nfJDe4LA7YJUu2WtSxlXy/77ih4v2f138IAqAS/EtsYNXRcD3E6+7+KXx+1re48Pb73HTzDguB6z1tvjs8Aua/63Jrz9LkbtP6I/PmFUFzhqkVQgZ2rxa6sj6cwu0PZ55eQA+rBxtZcCCNJCplOVWj+tbO3zwznv8+PqPmJRD2lnn0vZJIZAqtK2NN5yVYw5Hx+xNjnl48JzPHn7B4ckhZV0gExWwCgockS4mPN7bKAIjYocglBjChW1UKGrjsdMSo6C73uGvP/4pH7//ESuNJd7bvEtLNeg1Lif/xTZKuUDQf73znKNgSk7Osd3jy737PD1+wGm5jz2csXv0lLOiTy1KdCrRWZDYtdaDNUincLVEu5RUdeg2eiwvrbPW22KFbYKh7zllcv6anhJBA0vB/uwTRuMhhR3ijCWIDk0pphWt9grNVo92e5VEtVliGUnK1E/IaZCRIWVIxn4B7YSu6rC1sk1ztUNvc5mjsyOeP3tCURVQe4RwSOtRc8S/A2QQ9QGCvr/1oQMlgqiRjx0D4SWJTljtdLm2dY07N25z69ot1nvrbLZXWc473E2voYE2rdcCMa/i+4qQzr8xqf8Qsv6F+OEVAIuYf+pfBQhc/MZV/CnCh8u4FGHNuLm0igNWWEGS8f7texyeHFKbktLMKMop0+kE4y3KOaQWJElQywtidmKh/AYizo1ZzP1tZcBAJlK6rQ7Xt69zY+s67SRnxoRe1iF94aNy0b+g9pbjcZ+vDp/w5GiXveN99o8OmBZjdJqQZgqUWOjgeB9RCt4F/rtSKKWiprzHW4etLd55lJe0Gy26zS63t29x79odVpo97m3cZL21SkNFQJkPCH4pBC9z7V9faFkMEwb0Zye0Gg0eHN/nFw/+lb3jZxyNd5mUA4wo0LkjaSYkqULpAKG0xmFN0CBQLiERTbqNZTaWr7O1fIuVziYilnLOiSDQJOZtb0PNlBTP7vEzPn/wGWfDQ0bTMbWZAoY0TWi3GvR6qywvb7Hkd+j1tuiKUPCUrgw0Q5EipSST+aX3lpOzKgVFPaMjm2x0llnr9ihtycQUGBO8DTRR9AcC0l/4xT6dIwKFCNMjG30BhJfoVLDc6XJ7+xofv/MB7919j+32Jl2aKAS5D+MO42ZUIkWSXMKLXK38v594XU5fAP9+Dy2AtyW0f2PTnP+WP/mX/mWxLvIXHrn42Ks4hFfxXcdFQZQX16oS6NGMP61wbWuL0eQO+ycHHO4fMvADjK3xUuClXBxa5wOwzsUCQEoR6HYIvAutf1dbpFFkecrWxhYfvvMud67fZKWzwhItclIEYRV9uW0eEnmF5WBwzGA24vH+Mw77R0yKCV5AmgcHO+td9COM6npzUyJCt0LIQCv03mNrSzUpSbyi21zi3o07/Oid97m5dZ0Pb7/HVneTtfbyIvlDSExx5y1my6/a3ouXQ8eM0+KEw+E+NjecVY7d02ecTI94dvKE/uSIigKdQauRkEi9KJwAhJUR9JeQySbNdInV3ja3tu/y3s5fc615g3kvR5KBkBgKEho4KlI0h8NdHj9/yPPDx5wOD5mUY4wtQJQorenWbWh6UprkaokMjYoqOg3dCNr8X5NIczLWkhWSRLO9tMGNzR2scDw92KWuSoSEJFV4KSIrw4XuzKXzMdBJpRRYH8yDhPMoIWhmGb32EhutFXba69xlfVEqVs4gHaRSo3wofqy3SKl+gKnmTxPhs8AL/4a4zOp7meP3day/tyV+wB2AV4W/9O0qvt/4tiuimhm5SlhfXWe53UMrSSIkJibROdLcOoez7nKrXYTmusBjLXgbwF0Jklba5M61W3z8o4+4trLFctolJ124t4lLznghxrZgXM3YPdznX/79/+YXn/2a/eNDvBQkqSbJNEpJnDWhfSw8XsaBhA/tZedd1P/3uNrhjAMr0CphfWmVv/6Lv+Kf/vYfyH3C7fVbLGddMpVe2g4V2QwQ37w47wqcg85CuRKKqwbH7jlf7T3k6eETDoZHHJ8es3vyjJPBEaNqgJElOhN4LTEeisqibTD5SbUOe0ZJUnI6aY/V3gbXNm5zc/tdrjU/ICT/ady+BgJPwZiEBiUTHh884MGjL3ly/JCDs31G0xPKusBRIaTBVzAsB5yOhvQOj9lcP2F619HY6LHEJjWGtmi8EsS4OKeADm2qqmK9tc69nTtILen3z5hMxkgt0CIUAMb7BeAPBH7uGCdkoH3OGSTeBxEhPx/VSLRXpEaiL1xRC1HTVClNmS84HZdTzlUZ8L3Govb9Ya72XxVvdwHgX/vDN/zuVfwp4yJNzbpg0DO3jZ2ZktFsRFUUaKWCr7sNyO1A94vTVhdW7NYGipcU4Tmk1EgCQA4H0gXxnURqWo0GN69d5+MPPiQnoZU1kBdYaS9esC2e0WyMb2oO+sd88vmnPHr2hKKekbZS0kQjFDhvQ5KPhYhbIPMjIt57jDGY0mJLi7KSTrPN9somH777IR/efY9bGzfoJm2WGz1ykSy2wTiLgMurylgIXLTaDWtax4wxDRIkJcfjA758/hm//fLz0Lk4OWJajfDaI5uCtKlRWRAtMiaMK5wUWCFASZI0o5m0Wemssb2yw3bvOjurN9nqzFf+k7jzHEokOAySQL0b1QPuP/qC3ZOH7B0/YzDrU7kZTtVIFba2qmuKUcFJf8xJf8J44vG2wVJ7k3eb+QIn8WKcd3vkIkEnRrPcXuaDd95HtVK+ePiQg8PDOJKI+AsbhKIu9gPnuAykxCFxUuKFBCFxDqxxuNohHLjKU1KjhWRACTisdJdoo1eXmT+T+F3AAG9xvfBmFgDfoWjG4pmvhDn+ZPHyyuj8Z2ctxWzGaDBhVIyYDCeUszIAswJ+PhxEG1drjoXdr9ZJ0NdHBhndqK2vREozabDWWeHm9nV+dO0DwNKi+coEA2EVOKomnI1HGAv7J0fsnxwymo0DQj7VeAm1rWOOtwFRjg/gMhVMchDgrMPUhqqo8ZWjkbZ55+47/ONP/453du5yb+c217qbNGWD9GIyiV0N8C/pEbwYE0ZIYPdsl6IYc3p8wlcnX/LbLz/n/sMvOegfMa0LVKZo5Q10niASgSUoI+KDA6PSKRKJlRqp2qz0dnjn+vt89O7HvJO/T8oqNcP4qjnhKMh4FCWKjLKecXLaZzjuU9gpo+KMcXkGiUUnQZTJWoGvfVDtc57JrODk8ISG3Ofw5hHbzTGSaAw1x/GIFzAPFy7cjbzBplxnbXsd1Uj4t5//jMf6GYUrI100nmky4P39Qh8hqBAGjED47pUigBQFxlhMVaO1RiRQaoMmJfcJHvda4aWr+J4jcvi/01z+BuoEvJkFwAvxu6Xq14P+XvrNqyLgTxvzFqu8CJySVGXFsH/G0fCEs5M+xWSKLWtkKtFShSTrz38/OLUlKBFOd+88Lq7cpAuqeivdHpur6/SabURoH5DL1/PPrbMMJ2Oe7j7lYHrK0/3nTIopXoHMNEILrAvyxGGFHmh+5+8jGOX4uPqvixpXORpJxuryCu/cvsuP3/+Inm6z3V2nSXYp+V80w1nc5wIO4CJAEWBgzng+eIZMHV88/pxf/urfefL8Cftn+xyfBaXFWljSZkbebKBbTZJc42XwVnC1CbP2JEHqJnnSoJU06TWW6eZbNOQKme+Rsk7g7BfAHMl/HgJJQoOJ6TMcT4LPQyPBKUtpZoR6SCHQWGcx1oMLYxdXeWZ+xnA4YjqcUFORoVhkeXFBzyB22i+OlFKZ0suXOGNMUzZY7ayw3FrieDbAmKAeaXHBMRCBOG8BxN4J4H3sfgRLZoenLCqm0ylOOkhgSkmDjFwE0aPzfsLCiPiqCPie47xQ/qbf43dSA3wbGgNvRQFwKb510r4i/P05xCWDnks3fdDof1EG1kNVloyGI4b9M0bDIcV0hjWWLEtIZIIXgZfvCQWAEDJgAuaCL94HJcHakDhFo5uzvbnN9a0duo0OwkJDNZg31V910bYSxrMJzw/3+GL3EXtH+xjh0HmCzoIgUXAZjHoBQi4Q+gvvdw/eOkxlsIUh0Rlb69vcvXWHezfvcGfzJsuqQ6+xFDwAYl4PLW4XZtMXtkm8kPgn9YTj/jF7g136xQk+sfz7b37BL377S/ZPdxlORszqiloYRKZJtMRriY1jCW88xgYXQi0lQmXkusNqb51rKzv08h6r3TV2lm/TYpW5YI93KbWoScTLgjdhNe1w3rOxvc7Mp3z1XDCdTbGlIa0USZLgjKcuLXXpcFYinSDVITknMiHzSZRfnj9rPFYR/zBXCAz/h3OpSYPClzRpsNZdY2drm/LYcTjpYyqLTUGnycurOO9xBDyFA9Aa4RTWwbSYMRwNmVUzSlsGW2fpSC6s/AMg0y8KgfkVR3zXK9Kr+Nq4vO+/5ZF4A1f5XxdvphnQ123zywSAy7f9C7dfdd+buE/esFhU5RGpj5+v2ucULIJ2/QtJzVtHWZSMx2MmkwnFdEY1qxDSh1mv1DjhQltX+NCy9YGyVts6tMq9xNYGW1m0FLSbLe7dvs2tGzdZ766Q+YTGBb/Wl2f/UPiaYTnm8fOn3H/wOUenh6DCTNpLjyOgycPS3y9kiIUMTWHvCRTE2uJrTyo1q0srfPzBh7x/913euX6Xrc4aq0mPXKfn5jwR7S++pt0/oyYj4VH/CZ999ikPd7+iPz5lMDvjq8dfsHu8y6Sc4ISFVCKTFJEqrPIUtqKeWZQJFrl4hxaKVOdkWYt2Z5WtrZt8dOdj2qpDM22znW+znKxd2F/Jpe1xF8yFALTSNJo5G+kGZ6Ug0znOwmxWUEwdWqfgwRiPrTzCp+RpRqPRZHmpy3K3S9s3qLwD+SL/JzIsRGi/B9R92FcJmiXRoavabC9vMbg1Yexq9gcn1KbEoFBJEscAc0BwSP7WeayNoEqpEEJhjWM6nXI2PKM/6DMajxBJi7pRk4kXaKNCYKxdJP2wn4LssPNcKmau4o8YF/P61XX9pXj7OgCviKtO/p9fLBTqhAhAvtfEiwI2FktZlRTTCaPBgOlkgqtrSGXEAIjo2OYiglvgnQsgu7rGuZDQnPFYY0Equu0Od27f5e7tu8GxzUnUK9T051Fj8VIwKafsHe3x5NkThrMhKpF4qbAYjI2yslohLhQ4oS0swsrfWWwdbGJbWZsbW9f4y49/wge33uNaZ5OObtFKGufv3bnIR3952xweg2VYjxnbCSKF+8/u86+/+Ve+evwl+4d7nI5OGdcjvHaQBQdClSWoTCG0xEtBhQPjkN6gVEKiNUmW0253WemtsbG+xbWdG9zeuUeDFjlNVllBX0j6iTxnKMxpWBcj0Sm9zjJPTk6QImFtaYu1pRPOzk6YzMbUZXT/Ezro6+sGK51Vrm3tcOv6TTbW1mjKDEH1ko3QfN9Eb8NwOxabAkHuM5qqyfrqBtPUsjs8RTz4HFPWGBksgi/u3XPUv4ur+NhVQmK9Y1rPGE5GnJ6dMpqMaHayUHRyOe8IQuHzqrjK/X+e8ZYt9l8ZP4gC4Cre3Hgx2c1cwbiYMB6POTo8ZDgcYJ1BWo23FlfXGGepXR1X3aED4KzFGYuzwQ3QGYc3nqSZstpb4f133+Mv3v8YVUKevH7274GJmaF0ynA25uD4kKP+CVNKkjQDCcZYpIAkAv2ED8WGdZ65PLG3DqxHWkmqE9Z6y9y5fou//fFf8xebH1NVE1rpefJ3PvjezVfS56C3EAMzZu9on6dHz7CJY1qO+ezL3/D44AkPnj/k6PSIcTnBKkfaSVFSIJRHS49WwXEQJRAqmgRJGeyWs5xmZ4nl5TU2NrbZ3NhhfW2TFl1ymizRQ6PnqfYlxbugQ3A5SScyZbmxgV+BcXXCYG3IRm+LR08e8OjxI0ajAVZ4EpWRJCntZoetzR3u3HqH2zdv0cvagEEjIOIAakqUTxfni+Bc/5FL2AtBM2+zvrxJ2ZCs7D4hSxpMxBjnwkofP28DxnMn6gM4P38/sQBwlsrVTKqCk0Gf4XTEWncVg8XAC32Qq7iKP7+4KgCu4s865gAsRWhtPzvdZe/kgNPhKUeHh0wmY+a8P1NXSAW1tRhngnvrvAtAbOVbwsrQBoGWVqNFr73EUqtLR7RJcvla5D9A6SvORqccDvs8ePIwJP9ygtEe6VUQ/HEWL0SYm0dQGcLhbeD8CyEidUwGAGJ7mXeu3+VHt9/n1vp11mgzTRPSCykkiCNdFiAyOBIUHnhw/JjffP5bPn3wKXtHexyfHHLcP2Q0GjCcDJm5EtnUyFwhGxqbCLwGKx1WelIFMtVoHXT1lZLoNCPNmzQ7bVpLS7Q7XVqtNkJI+gxoYkjJSOlwzCFt2jQXYk2vDyU0rWSJrNNkMG1RrBakbclaa4sGy/T7J9S2QiUJeSOn2+2ytbXJtWs32FpbBywDTgHBEhmGmgkFDd8lE43LL/YK7YZGs0l3aZVe6llqr9BudunPRkhhcc4j7BwMGBgbYUQVj4GQi+6Vw2GRFLbi+OyEg/4xvaUl0mbOSJbssIIGzhjRpkFydbm9ij+zuDojX4orMaDvOuYs6/mFubI1xtYL4R5rLdYGc52xmbKyuUrXNdmtDnm0+5Sn+8846fcZjkdYZ9Fa4oXAGkNdeawHvA3CLSKACYRSKBEZAtYjkbSbTVaXl2lmDcykpqhmtNPlsI0RtPViB2I6nXJycsKj/WccHh8wq2a4MPHHOYuXxCRBFCPyKELicCIwELx3mDJo6DebTW7fvM1f/eSv+PGHH7Mk21RY8rmEbhyBzG2D5yGFYGjHNFSTgR3x+OQZv3rwCb/45Bc823vO6ckh1tekqUYmkka7SdrKELnGJmCEwwgXcBZpgswSVJqgErUYy6hEI7UK+9Y5yrpmNJ2wZw84Ox3SUA0mnQk3uzeYMOXs9IyVbJVMpyipkSrQL1+V+LRI0CqBZI3t5Rp0TWOnQ0svc3x4QlnPMKIma6R0llr0Vnp0ux2E95xOjql9TepTdFOiVYNBeYrOUoRlwfiQyAvSwyEcHk1Ko9Gi6SvazSXarSXy6RnWzIJ+hHWLYisINAUvACVVcGWMhSQB3kFRVxycHPPg6WOU1kyrkq31TfI0o0WTx/3ntMnpqg6ZTlBKoZQm0xkSMN6h+HpFw6v4A+NKBOiVcVUAfF1cFQHfSTgclatoyAYVFXsn+0yKGZPphLIsmEzHjKczxpMxZ9MR3ZUlKD0nRZ9nz5/z5NlT9g8PKKoyUOlIsNiFN7tQCi1DwjXeRSZ6tH8lCPJoJVlbXmN76xq99hKpSGipxoW5rV/Iwl4U1BmPJxwcH3J4csDZdEBlyohqD8h8KQKKnShBbGoDQqGlQguJx2Gtx9eCRKesdlb4y49+wv/6P/9/2eit0mOJ5CI2eQ4cWGwXlNSA4unpMw6Pjnj4/BG/ffwpn93/jEcHjxnNhtTaIBOJbqbkzZys3SBppvhUYqTDEAoAL0FqhUo1UktU5MHLiHivrWE6m3HqT3FFzfh0SIpGe4UWKY9bj7m+cg3VUJSDkrX2Bs1mk2beotFo0Gy06Kg2zQteeJUPFs5aStKkwUp7E5E4WvmE65t3sKXi7OyA4+IAoR1JrpGJoKpmHAxOGAz6zEyB8or9xh7dlWWsgGwtwU4FrbTHUrocW/UvjiRAI8lVg3bT0u306HV7tCanmInDOgO4RbLwzgHBvllF+p/0AVeCDLLIs6pg9+gA7z0n/RM21tZYX1lnLV+hk7YZVyNkDcuNDu1Gm1Yj7J/tzR1a5IyqCa2kQSquLsffSVzl/NfG1Rl3Fd9reDy1rTmbDXFtz2H/iF/f/4ThaMhwNGJaTDkbDTgbDhmNJvSHZ0ymEyazglk5C2A+b7DOBPMfrePqO1LjPCghkEpFcxdwXgQaHgpDjbMWqRNW11a4vrNDr7tMKhISry9uKM65l1gIRTXj+PSE/aN9BsNBaAJrGSbOzqEIJkTee4zzWOsQwqOFjPRDg6s9uW6wsbrK9c0bvHvnXbZ7WzRJLyV/uKzmB54RM45mJxhl+fThZ/zXf/mv3H90n2fHu4ynY2phSFqapeUeOlXkzYxGMydpZMhU4ZSnJhQATnicBKEEKHG+QvKh9W2doXKOsXFU0xkjcUZKgvQCaYOK4n2R0snbtBttus0u3aVlOu0l2q023U6Xle4Kq501elmPTZaogamfkYsMTYpUkoZqAx6FpqpmdLIVOps5LVKsq5jUYwajPofHuxwe7XF2dkpRFFg8UqU0G22u37yFTCTF0LDTu0VDNcj0y+OI+UAgFZpW2mC502Olu0K3f8RsNqOwwYRJCIKrpHcIgu5/oiRSKLwNLA8hPV5C5SpOh2dMpxOe7j2jkWY00pxGktHK2rTyJt1Gh6V2m267Q7fVpdPp8qPEs7qyTDEaI7sBc3HVBLiK7zP0m7nM/bY8wIs/f5vvL95+E/fNn3/MihmHx0fk7Qb7Z8d89fQxB3u71JE6N55OGU7GHJ+c8vT5MwaDAdOqwDtHojU6TdCJREoRudnhOMk4ow0QLcCDDCAAVJwFe+fAGEhhqbvEtZ1rbK5s0mo0SS4IuS8sei9E5UqsMJxNznh+sMvh8SG1NUglkT72g51biNdI5lK/EmfBVpZqUqNRbGxv8pcf/QU//fgvubV5k2WWLgn9XAyPp6LGYDmcHHI4PeWgf8i//fZnfProU54dPWNaF5B6sjyj0WnQbGXoNCFJFDrVCC1BgVRhBSyJ5jQictxFdCf0oZDBgXAej8R7g/GC0gmEDe1vaT3egnSQZxndbImlXo/tpqOyltJUVMZQlw6TO3SW0CEnIWMmK1q0qahjyROOUSobpGoOwMxo0cBKzWl9wNHRc57vPeTgaI/xeIixlto5rIIsaVCJirSV0M1WOJ0c0c2XsM6S6QZKvkDJAxKZcJsG+1s3WOut0j5ocYJCmOAGKFTwjZCRmqp8wKFIQRAMwiJi8eSdpzAF02KCdzZ0e2SKkIJUJ7STNtubm1xXO4xcwdFkwHq9Tud0Bd1MOO0fkmc5qU5JhI7gxqv448SL13Dxivt+uHHVAbiK7zWccxRlycHhIc+P9/jvP/tX/vN//i8cHxygGil5s4HxnsJUTIqC4XhEURZYXHTNCyszvAUbpIGdC6h7KRVqzrO3gXYnARYXcoczBowFB61mi42NDbbXt+guLV3aTiHEC6tvmJoxVhomxZSDgwP2j48oqxKBRGm5oPdZ7xBCIVFIqfAWXO2pS4OvPY0849bWTf7xb/6R92+/y0ZnjXxhOfRyzGxJvz5lKgru7z7kF5/9is8f3Ofh80ccT4/xuaC91CZtpMhUoHJNmqXoVIMA4y3W1+A90kdgogDvHQIXKYoOayOA0XuED0WUEBInRBAZkgEBjwi2Qj4q5xnvKCvDcDDmpO6TJClpmtPIW3RaHVa7K2z2NljLV1ldWmN9fY2O7FIwYYn2OUZASOYkPMeYmhmGgqOT5zx5/iX7B8/oD0+o6hIvwxje1o7pbMTMFAwnA7bXbnJv+z2W28tkvqDXWCVPO5cFk4AUTQtY766xurRKN++EI1B7EC6OQ2TEk4BwDuk9wluEs6EzIARCz7UsHLWpccJR45E+bBvFlIGcMHEFx6M+Isyl6DY73H/wFR+9+z431nZY7vVoNhs0aV0VAFfxvcVVAXAV33vU1jKZFXy1+4Cf//IX/NvPfo4czagakrzbQWqFlR4nVGhRpwmpEggVZtRBqGVu9BO6BlIGyp2aC+9E5DaACP18nAdvLd46lFQ0spxuu0NvaYlms/GS4t+LNrpJmtJYauKEYzAaMRwNqTGIRAQzHimigl6YIUupQgLFgwPlFanWdLIlVto9NrqrNGTGUtrBOfPSStXjsTgmdsLT02fMZMVnjz/lX37+Lzzee8akHpM0EtrLHfJWRtpI8crhpA8tfSlx3lJZi7U1uAA2kz6CFON/CB+Abj60vOGcN4+cixdEHoUEtAhXDi+BwJ0vXMmkDOMJ7zxCJmiZ0MwadJptllpdNnobbK1s82H9Pu3rLcBRuYIlOuQiX4A0ayaM/TETc0xhhzzff8TuwVP6/UNm1TgKRClQElwwDRqd7NHv9+kfD1luLXNr5zbD0YxW2ianzcUhsOTcp9CWFc20yVKrQ64TMD60/l0wEVI++gI4R7CPjMXnHAUoXKAZ6iBjrLxCKA1CIazDlDVTW2GnZwzGI8pJQT2raOqcvd0DZuMpzb/LcfIeuWrTuEr+V/E9xlUBcBXfewghkFojpQ4Ic+9RTiBcXD3FtrRQPvSsJXgpAq8fF2b6hMQkVLCYUSp4BkgRWrIsqFvgnWOuDRSSkyJPM5p5k1ajSaORofXXfxQ8lpQUoRW1s1S2orY1VrmAOJeKOWHA+cDxdy6gyYUXpDIYBHU7S6x3e6y0lllrLHNn7TrdtBVHFZdj5kvG9Zjj2SlfPn/I0fiEX9//hL3+PmMzghR0W5O2U1SuQlZTsXAQFhsgh7g4q8YB0ZVQRFpbEBYi7EspA8BtfpwWhJjgY+9wkdIomFP7PaGr40QoxJx1eASOmtLXFHXJeDhlMBtwNh5wNupT1gWyEqysr+CGNRuNNVYbqyzlHVKhMZRMyiEn4yNOR/scnxwyngwoygnG11HmN6Z0GYqUWVVgywJvNWejPpUtmM0q6nb1kqKLIHD0a2vxZR2omEurtPM2yh1ivUC4cNzmX0Q9AEHolkSYaNwvgV3gpQ+JP5EIqRBWIvE4G4yEjBOUhGJs6mBazpiVBbWxCCVewn9cxVV813FVAFzF9xpCCLROaDQadLpL9HrLdJeXGIo+LktpNBoIHVfNSuIlCzS/c2HFr4TAS4EWwTlOITh31nWL1b+IUsDMhYACMxClg/Vvq9EgT7NAWYtz6NdFjWV3tMvB4JjJbBrYBSJc+CWBJiajdWzQiQ+JNuAQFFIrOnmTmzvXWe+ustpeoSUy1ppLwSPghdcubMnR7JTngz2Opyd88sVv+OT+bzgcHlNS0FxuoDJF2kqRWmCkwTiDl6FrYJyhmosHaYVSEuElzliwYbWv5smc0FWZOyX62B3AxYQe5Zp9lCGGKF0rgmiQE36xKtcypDHnCR0a46hshSlrqrKiKArG4zHHh4ds9DZYaS1zY2WHayvXuba8STdvYCiofc2kGHN0fMismIYiIz6vs0EREQ9eSKzzOAR1bZhOZgwGA/YP9miJ3uJ8eBFcp4HKGdx0RoJiZWmZdrMdpKStiUlfxLFEKGqsc2H/REVAH3s0cVcx75AIJZE6aCmIqPWrhAIDus7w1pOQkDcy0iwFIZhNZ5wuDemJ7gUR6qu4iu82rgqAq/jeQ0qJ1posy2g0mzRbTWZ1AUlC2migEhWSkAyCN7W3OGPwIgDsiMknrF4FIrb8jbPg/ALFjZBBZliIeIEGJRSJTmg2GjQbDbIsJVHqpQR8MTyOytWMJ9OASaiKAJYTc8FZHzzjLq40o4KRMw5nDdZIGo2cuzduc+/6XbqqQStrvGTha72ltoaJnbHb36VfnfHg+QPuP37As8N9CmaknYRmr3nuOugNtTNYH5K1l5Hn72wE+IUOivKhYyJEAPLNHe5wcfQhzhO7IHRckJIogffCQYzHIcAJw98qFYCTAnAuoOWVw5swD69cxbAeMjkecXJ2zFp7lZ31HdKmZiVbweWOJg0EmqpxRpKmxAEO1nvK2lBUFQBCKYQK3aDSOqpJhakFToL3Am8hyTVahe7MiyHiccU5Ehk0IRppjhIapRIC5E8RWh0RaBraHZzPlgJQEH/hmEuBjx0rKWXoDDmBFgoUuKpGVI7UJyito7iQQCtNKpKr5H8V32tcFQBX8f2GD9x2ay3W2fg9XIidC9AyISVSBW1660yQzRVRgz2a4s3b1zAHsIWVrXeBChiKjMD9X6i6eY9WkjTNaeYNms0mjUaDNM/QC++/V22yp6xKprMJ0+mUsiio6jJY5aoArJuPGVSAJ4ALCHlvHHVhqFVFsqzZWd/h4w8+QpaW5aXll15rPJvQn54xdlPuP/qC+7tf8eWzr3h2tEshKnwikLlCpBKRgFdROMlbnAigPHRwQJSE9rwRHucNiZBoLVBeBwqbjdLIzi/8E6R00UEx2vDGla1/oUHiRQAThvvCA1Z4rDdRNjd8IUEm8Xi6oCtQ1jXTYsLUTJn6KT5zzJjSr4443tpmjS4KFzpES6scHh/ipaKsHbOZCXWW9KCCyVNlHHXlUWQ0szbLnSV63SXaukmSpC/u4kVIIciThHYjZewS0iQl0SmVqQk2wBKPip2e0E0hdlUEkSWiIufEBoEpJzze2ahDpQJANFoKC++CEFQ81+u6oq6CXXSzkdOj8dptvYqr+C7iyg3wVfdd+PnGf/yfePqf/9sfsLFX8WI457C2pq4vfJV1oNQlCda7oEAnJZUzVNbgnA3obFgweRZtWBd1AKzFOxdV80JSmrusRWV3pJSkWpOlGXmek2UZiU4CZe912+sddV0xnUyZzqYU5ZSqrrDW4mR0G7QuGhAFMyLvPMIF8B/GBwCZ9QjrkRaube3QarUueZXX1jCcjXm495h+PeKTLz7lX37x3+lPBpjMkbQSVC6RqQgz91j8OBH5eLEV76U/R+w7Fgk5LOhVSN6xIHLOY+egSecXnuhzG+VF1hcvVABCsLD5mQMKY9K3zuKiHbOUAbiphArdDuPxwmLKmlE1ouwXTKsJ+6e7fLm7xs3tbd6/fofb6zs0s4zl1XXWRn3OJmNmZY21iqKssMbjaoExEu8VmWqy1Olxffsm2xvXWVteQ9uMJFGLo/9iKKXIspQ8S2iYhFQnKKURVkUcg8CLILXshcBhmXckpBBhvDRnLoigB+lskHz2WOZkUOUlFoWoHcVkSjWZ4UmwjQ7eWsrZjLOTPod5m+V0mexrzsWr+B1jfuh/nzz3A2AMXnUAruJ7j7nBiomyv85adFXjayjElLIoEVoitAp0Mxe42U75hb6+9HIBDFwk/Avta3EhYXk3xwAElzmtFWmakqYpSZKiZPK1l1znHGVZMp1OmU4nzGYFxlRYb8GrqBdvF4lCeBlWgLETkCUpDZ2jkTR0ymZvlfXeCklsAc+1BIz0DGcjjs5OeHj4hN98/lue7u4GD/vVJlmShZY/Fm/8ohuC8mF+LxxWOKxzoeaQEfcnQoK33mNih0R5wv5S89V+iDlt8pKDpng5ffr4b4BbxJm48IvaOeAIABHBcYpI4xQor7BYal9hjcVVp5SDGWNzxtgMMKbE1TU7q+skzZzNnes4pWm2ltjfPeDo+JjJZIopoN1psLyyxnJvhY3VTd69e4+ffPhjrsmbTBkS0CQzBDkg8X6GEBEtiUAlkjxNWJJtmnmOiswNE90bnYgjDSGirLRf7JAwEfBxZR9X99YH/IezxAYIxoBxAl9Z7NkYNS6oVIZalqQqAetIvCSX6RUF8Cq+17gqAL42fgAl4J8gQvtUkSlNnuVkSZMyybDWwHwlXXu8VkgZVlk2JikhAkUrwtTiLDrOWrU4BwDG9rSL4wET3fgEEhExCIlO0FKhXvKwuxzWOmZFwWQ6ZTKeMJvNqKo6XvyjVawN34mtd+GCJgBO0mm2WGn36LSaNJOU5VabTt5cvGZtDbU1jMsZz48P+Pdf/5J/+83P+Wr3IaNyhGhILJbK1khDQPG7sArVPgD8pAwiSMaHsYrBY4XAKxkpiaEzYWxwttNESqUKDIp5RpPzzkBMgItWyytKgMV/c5vcmCuVnFvyBtCgc3Zx/LQQCB2siJ33OBXwC4PpMIxYZjPMpKIuSmblbXY2tuiurNLs9Fhd3WJ5aZ/O8yecHg8pRiV53mR75wY729e4sXODW9eusy63gJwmCTUjLA5NCkicm4XtE4pMaLRSpGlCO22SpylaK3wZrJe9cwFTEEQmmGsUBABi2C/ORkaFEygfnA+FD8Wtt6ELJIzDW/CFQ5eWxEAJ9FptVjpLpGgykZKTfsOZeBW/X1zt09fFVQEwjxdz/VXu/05ijjZvZDnXdq5x+8Zt7t6+xSMhAppcSWpbUzsTLroiGP0YZ4Lu/txRT4XVpJEeJQVaBkvbMLc+T0rzlnQQuBEhUUaMgZRBEe+bLg/OOaqyih2AKWVZYowJ4wanILb8vZtTwQiCQHVo97daTba2tujlnaADn+RodQ5M80pw3O8zrQsePXvMr379Cfe//IJ+NUC2FVma4AUYUyNjURM1eHDOooUKdr6xjSH8XFsvANSECq3ouRGSnSf0yFyQ0WnQ+/g+8Hhvef08bX5XFBGKiX5eXAX8gTxXFZyPaYTDSYVABXwGGqct3lhMVVPUlv5wDNUezoRtVTqlubNEr71KK1+hmayy2tphtDHibDTAFI5eb4219gbLjVVy0aKgwjBYKB4K3Asb7sAbjJA0ZEqaaIaTacBACIF3FiMcwgZch1BzV0cdBgMizvONxdYOYYPUsxQRTOpBe5BKkqUJCSpgTJqCMpniRlM2e6t8eO993r/7Lu20Ra5Tcv16G+qr+APjxQ/5VU0AXBUAV/EniDRJ6DY7vH/7GkIKqlnBjevXQ7tfwKwqKMsKR/BnN9bSP+tzchpc4mxtwswbjzMGK0AmCp1EFLpzsQ0bVmnWh+cVQqKUQmsVHNnmLnvfsL3OOcqqYjqdMZ3OKMsaa2PLd15sRD0dEf3irDOYqibxmmbeYGd7i16jExXfzjXqKyy1MDx+/oTn+7v87N//jcfPHnI27FMpSy4CTKeuDaIUwVNACoTwWBOYD7U1KC2RWiKT8N6QAV3uFqCJYI6EmrfqJU7KxSz/onBSbK3AInGGB+b7ScSugCd0PaQPrXFJkFye8/StFzgvFiBDh8dKh5TzMY2OZk4e5yTWWera0x9PwR6hfEKedWhly+i1Fq2ky/pKl3d6H5PphCej5wwPhqw0V+i2unQ7HVpJM66iffxu49Q+FFxSZnjhqf0UTZeWbJCqhOl4TF3VKBUKIWtDgvdCLtwcZZz1B+xppHhGyeRUJeQ6w3uBFRYpIctS1lfW6bW6NHVOJlLsrIZZxdryGv/T3/wdP7r3AcdPDmikV/j/q/j+46oAuIrvPbIkZaXTJVcp691lbm5fI1UKG3n1ZVlSFCW1NVR1TVXXLDc6rHd6TMopRTFlVk2YzqZMpiOsM1gLLnrZeyEiCy/Ovgl6AEoqlNaBFy9DsfBtLFidc5i6pixKyrLGGBNAf/NxAyHZBstYiRIK62pMXSEF5HnG1tYma+1V1tbWqEwdHAOBs3JEYUq+evyA//R//Cc+e/A5x2enkEiyXC9Q7KY2+MKDStBJtLr1AXBWW4cxBqU1CQIlE7RQSCEI6/hI1xOh2zC3sQ3JObwPMf/uF1hCFjC/c0WgsPqFqCQY6YJxP0kP0kVKJBLhFM7LoMAYOyQOgZc+4DjmxYySJKlGS/DSYIuK0bRk7+iUZvqcXHXxdcrOak6vtcw610mAUavixr1btEXg78vF6CFsUYQ6xsJlfpxzLCXGl2gPudRoLZnNCpy3yLja924+BhBxf8TmvBeh8+EE0im01OQ6YanZotNskajgbSA8ZCqh116i22jTSdu00ybSApVhdWmZa6vb9BodkjVPI88X1s9XcRXfV/wgzIDOu/mvowB83WNv4v75845UJyx1umQo1rsrvHf7Hje3rlGZGuNDsi2KCuMMxhiqylBUBbO6JGtkHJwc8NWjL3i+95xDZ5mUE7x3AeDm3PkMm/A93J4nKnEu2iO+XQHgvccai6lNTP5xPj6ng8cVYnD9i2h373F1jVeSZjNnY3Od7aUN1lfXaDVCB8DiSTJNvzzjy6++5P4Xn/Ns/xlGWrJOhmolyFRjhQ2Uw8ohEhCJRCmNlgleKKwPNEBrHKKyeGRokCiFVCKu8gMl0i9W5wGIGVrt9lIBoCLITRJd8UT8ThS6mesvIBZCS56QLOc0t0UvRCiQMhZksSsTkImxypAIqdE62BF7aTBe4ivLeFbw/PCQRDVJZItua4NW5pmbNm6l2+SvWMNcknN+ob8jhAI0IgI/LR6lAhAwzdKwHVIGIaCLzxPHKi5KPQvnUE7SThus99a4sbXNzZ3rbPTW6dKgxjI86dNJW7TTnFbWoJk2F+dHI0m5sbLNUt6huZLSyBvnGhJX8UeM+fX7d53pXixt39646gBciniSXM3/v7MIyVLRSptoEtY7KzTuphgbRGsCRzqI2AR6X2gzz+qS/mTItVvXebT3hP/xr0v8Ks8wzmJODLNqFlbJ8XXO1doiWntRCMyp6xH9/m0vut7HlfL8Nguo+3yMMAfiSQQ4h7CBnpdnKcu9JVaWV+j1evH5YP9snwcHjzgcHPPgyVfsHh0yLiakzRSdaHSSIJQC4REWrLHUJahEoRNNkmmUljgcta0w1mBKizFR/S8LYjNSE5hqETDpvUA6hzEeYQTOnEvfztv4SvgwIhF+UQAgzpsBcs60iLaL3gUTJGvdQjdIqWjDrDRCSZyK+g/xWLvoniiFjQJCHplItNcBiW88/fEYfbBHu73M9Wt30DJjqXnKVrbyyuT/bUKhgQYOT0Ewc+qtLNNpNcNoSCkUKqpQRjlgF0pIVxtsVaE8JDpntdXj7s4tPnznPT587z0+uP4+11hmSMHRs2d0VZNMJiQyAA5lPO+0UDSbTdIkwekmWl8JAX/nIV668YOPt68AiCuSb/GL4Wrmo0jMd75hVzEPKQRShRZ4rjPy3jeDnxxwVo/IkwbtpRZVOaN2JYPhgLPBKaPJCI8PwhYR6CeECMo8bu54dxHdDrGZzTddEIJKnkJJHbEDF5QD/eI3Ln95LnD8PQhH1khJY+u/Px7w4MkD/q9f/guHZ8c8fv6Ysp6iUkWSJWElKsK2SyVIlF7IyprKYrQhSRMSpYLIDuFtWlsHzQRPWH17hzcehwkgPRGqAeE9ynqUA+FlkCuOnQwVV/9ze+OF959wUWMAvBcRGCcR0XgotPhDsRVcBl0EzYW5Qtgvc339OYfARTvnMHSQEmQalPFsaSmLipPRKc+Pd3l6/IzZZEa+pmmqhCXdZk5UsNjA5nhNC31eEAZyiESTxQLA4L2g0+2Q5w20kCip0ASOpRMEkyRrw74sK8xshkTR7HXYWFrlxsomN9a22Gmvsi56bNIiI2Xnxke0vs0lNn37LsNvQixGQ+L8p2/+o7ereHgrzrzfbcEeAFTfpka4agT8+YQEVpIOAE16/OVHP0Yo2Ds85MGjB9jaYrGBb46KeuxB3U96AmjLBUCaNS582aiA902vLSSJViQ6I9EpSukwq408f9yFMiLOBkTsDCgtqaqS4WiI27FUVDgczwe7fPb4Pr/+7Dc8P3jO3tEexht0qtCpAu+xVQVKoDJFkmZY5al8ja0cJRVCBL0BlYU2uxQaGZ39NIoUhYydA1sF4KJEIZVCyYRUahKVkCpNqgIlUsrQ1fDOYa0JXQVbUTsT3qoweAlCObwSyJSotghOiSDDGz84LnoSGOMvzM/9QlVwPk5AOhxBQVC4OG9XGp946ioILu3397n/6DPG3W1WW23KlW0qahJSvAiUOx+7EfPP7cVBAK+4PecvOAcSFel8wSNBx+6GFS7Y/wYTAnxRIGclSmX0sibXV9bZbC9zs7vFne41tmkD0CP5nc/xq/hu4tumbPG7FAK/02/++cabWQB861X+7/HUvJz0b/zHf+Tpf/6X7+T1ruL3i0wm3Ny5wdrKKmmaoKQKc3LrIhCQkBSlCAVAXOl6D7Vx1JXB1iaKA319CCFIdEaW5qRpHpQDhQQfVf/s3BEgYM+9iLQ4HeiGZTnj9OyEwhaccUZZGr46fsSnjz7j/sMvePr8KdPZFJ1pdJYgpMBagzUGoQRa5WSNFK8FwgpmdUntarwHYxypzdCZDrP0aJWspUR7iag8rrRQ1gjj0cKTZQmNNKWVN2g2WjTzFs20QaoThBA46wP2wlQUpqKoZ5R1SelKKldT+/CYddEh0HtEErAGaBXa5Y4oPGRwtg7jExG8GOY0TBGd/Ly3OG+CeZBzwThHp6AEPvPYsmYw7fPVky8waxX3btxiJmYoFMuksWCYr+cuQ/6+MRyY2lFUJeWswhoDzqKi/TE+SPsK78DUyKqCypAkCSt5i53ldVayDhtJl1XffkMvqG9n3PiP//jSfd9p0n4DuwNv9/l6MZt/43L+ar3/fcZcT33elr9Y0Pn5bRGV1oQgiXa93ge5XWnAlRbpIVEJWZZiK8vCoS5SCpEicNMjP9/ZABY0xmBMUAf0zi849K8KKSWJTsjSjCzJ0Do5R5w7H6VfYyEhHC5eCIQKgkPOOYqyoHIVBotLHVM/5XB4zO7RPocnR2SN4ISotcYJFs6HUsggjmQcQiiUFyhUcMAzDlM7RG2RSqMSGc1pLBjivLrGFAbpPK2swXpvhdWVFbrtLkvtpUCfa3VpZW1SnSKEwERWQVlXFKZmWk+Z1jNG1ZhBMWQwGXIyOGUwG1IWFVjQaGQabXBl0EFwxgQNhihDrISI4kMCpIsNAYdzNdabMBKQIrg/ijrw73OBVIJyOuP49IBcphS+oEmLGQU5M1rkl8B+84HeNxM8A6DfWksxLShnM6oiqBCiAi5BRhdKnAVjEMYgrSVRnnaSs9rs0tU5LZmRWvnSFXUuwzxvNQvOR0MBhMo5mPQNTCBvbnzDvn510+itC/22pLxveh8vcwNe//Ml3sB32G34QYe/eKEmuKjF/byY43ofVerOIzzm6aQtVA3ShMS20lvBD0+prAlJ1vnoHyAiXi9IuQoctTHhq46UvovgwFeEEIJEKbI0JUvSyx0AP0e9B8tY76JCj4hUNy2QSRhJVKbmeHjK2WDIw6eP2D3cYzAZ4G2NFxlCReMZ75CEObhWwY2vmpX4WuIS0FIFq2Q1V56TeBvn7ELgrcA5Q20trjQI4+m1uqyvrPGj997jzq3brPZW6LWX6OQdlpo9WrpNQqAcWhwWR+0MlbdM7YyxnXI66bN/dsTu0S5fPn6AP3jG2WhAbWowAqlUNCISWGEWWEkhQhJXSgUgnBRBE8Ca8OVqED4wG5Q+L+KsCVgOrbDSUvqSs+mAw8Eh++xTDGfohqSp8wsmjIHdMC/QXjrpXigUrA2mPGVZUkxnFJMZ9azAZgIhFd67sPp3FmGDOJB0ngxJS2csNTostbo000bY9hdCRmzEhbNp4U8RPgRifpK95uy7it83AjznB5LJf894uzsAV/FnGxdXO4vbX/P5NNbivY+dAEFCApWjoTLWV9dRjYTSVAwnoyg84yMi3QYHVwIK3uIwpqYoS8oqOPr5byjwpJQkSUKeZWTZvAOgmC/fvF+o4UdMgcALh5AeoQQq1QgtGU7GnH3xBQ8fPuJXn/yKZ7vPsc4i8ixY34qoYug8KIHWGqUCyr+sKrwNHH+VJMhEBpEfGcxmpBNgwvb62mNri3SOTGQs97rsrG5xY2eHW+u32G5vstJappO3aaYtOrJLTiOi4+ezcY+T4XuhWrSYop3CTA1FMmOru4kznlzlDIoBtTX4OoxZhBJIH0CTIuoDhwIgjGTmrIGFcZDz5wVCkuBFoF06EY2dtEBlGuEkla94sveMn33+73Tp0NtcYqXTI1UvuP59XUU3/xUfipC6KqnKIrg8FgV1VeOkDBRKopqhcwjjQwdGappZk26jQ7fZodPqkmV5xCCcx7wQUa+wI76Kq/hziDfTDRC+vRSAv9Bju8TdXuC1Xnrstbev4k8eF8VSUp2ysbbJ3Vt3aJ0dcXxyzGQyXgDwgpiLxfkgAiRVcHSrqoLxbMysmGGsWSDUXxdSSlSSBt+CLCNJIr0utqsvnkzeRz48LoDcVPidoq447p8yGI744sEDnjx5ymg8RkhJnudonbBgE0R64oLGKBZkg6gCGLbW2+hZJwMTQPrIzTcgSkGqErbXt/jJxz/mgzvvkQnF7fUbrHZWaDfbNNOchIycjIQMydw57/y093hqDEvUdFsdOr7DilxiJV9htbPC0Uafx7uPOTg+ZFaVOAsyESgVKIqI+TgmKDdaN3cxJBQvSi8YG0LIhbnQHDMgo8QuCdHLwHN4eszDZ4+51tmm2Cix4nIHZ25l/E3hncfWNXVRUhclpq5xEYcQ5jBxL9gwbhHGoVA085zl7gqry2ssLy3TanbQOgk9IO8WXaqrVf2fOF41/n3N7YujmMvxdh/DH14H4GrU/0ZGAOhe5u132m1uXb9JQYV8JvgsycEGoZmgRS+CvoAQKK0RQuGoqeqC4WTEeDqmqAusNXj19SOAPM9otBs0igZJkoZWtpJhrCAIXPk5rtx7PBahBF4KKlPRHw2wAo6Ojnn4+CH7h4dMptOQ4JQKSS5y62UsKqyzOOHDClhrZCLDmMCHFb51LhgbCRVm61HTX7qgTrfSWeK9W+/zz3/zH3jv9jvYYclmY4OWaCwskMN/ihffvbhwj0SRktEgZ6nZYTvZYGt5h/WVdc7EmEbSoJ4ajod9KlOCA5VJlE4QWmC8obIV1tQ4H9oUIiZ/oTQiSirjPaa2RL3A8H5iceAV4bmc4+jshFQ3yWhSKkeFJcGjuZD4L4wE5vd57y+9Te89pqww0xl1UWDrOuJRYKGKGHEovg6iSYnQtBodVlfWWV/bZHl5laW0TZqmYexwgWIqxNWF5o2LtzvfvxQ/sALg9dn/WxSJV/EnjJAYL6/ser1ltre3Gdspg9EZmU7Bhpat8Oe2wEGwJgjbWhzCBGXBaTllVgSEu039a61YlVLkjZzu0hIdMyPL0pA8jAMVWtRBACgI73oXjXREoMJNyxkn/RPGsxnHx8cc908ZTacY44I8sVJhGy8sY4OYXnCa00IhtULqgCIzzgajHR87FyboDARNf0GqNKtLq9y6doN3b77LzY2bdOnQ6W6xROd33/dxr6ckpDKhk7VpZi1UppA6wc0cp/unVIXhdBRwFcKH/SbmqnqWwC5wkQ0AC5aGkFGV0IaiBhxSBDMdAQtLAk9YmI9mE076J0xWr0OuyGUTg0HHy9nvIu7kncPVFlvXWGPwzi6sfIWLfr4+dFtwoLSmkTXoLnVZWVtjdX2dls9oqfwlOvnVdeNPH69DAHz9GfLDqQLemgLgj5KoX3qS8zuu/4d/4Nl/+e9/6Ctcxe8YPtrtvmqOmuuMdrtFq9mk0chRSoa2v7Eo5xA6uOSJaOdqTVAZDK1oy6yYMRgNGLa6rObdeBF/+cMvEOR5zq1bt6hTaOQ53jpEbbBBOw+BDI6x3mOFBRH8B6yzjGcTjk+P0UnG2dmAyXSKMWYB9puDlbz3OOux3obxQTT9iST6oKlvQ1cAEWx3A0vAY70BC1Iqmu0Ot6/d5scffcQ7O7e51tyhR4f0j/hxb9Lgmt5miSaTazOebj9hPJ4wHY0ZlRVlfH8qV1hhIxIeRDQi8I4gQ+xC29wvugDxuMtQMFgseIGzApwMM/vaMilmTMopdewozChJg3zP+bkTRw2vrwfCyGYOBKzKkqoqsabCmQRhA94kdPOjSJJUJEqTJhmtVouu7JK/pnScs1yCAJG41I24iu82rv+Hf+DCUOjyg3+EQ/C2HMW3pgC4FK9A7n/tiOciTmD+m1dL/z+bEIhXIrsLUzAcnHE26DOejkNSnYPyvEdK0ErhZLj4mqjmhhQIAUU5o9/vc5I22Wit0Gxnr1095qRM7BThCPK2SLwLK1tvA2hPoMJq1oeVo/Ahmc+KGWfDATpJmE7npjNxVeznM/KoJBCti4UPbf95YRC2PSRGr4L1sVI6Yh1cMB6yEp2ldBsd3rl9h4/f+4j11gpNcrI/4KN+rmh4HhaDoQKabGRr3N66ydlZn37/lMl0zKwsMa5G1hq0Q+hA/5MEeWFvAwDPR0thiO59kgCGdGEMYFzcPzW4WkKtUE5ROctkNmH/cJ9HO0u0fYO2zuM441u+LzzW1pSmCjoHdUlVl5ja4JJAARQ+gD2lDK6AQaMhFAzT2ZQxEzw5DRqvfpFACHnlPryK7zHESzdY8DK/7tcv3fn2Hb+3swD4xphn94soEK4S/p9JnNMBL7TwOT9iFsfZsM/e0R6fPviMz598wcPnjxlPx6AkCh117+erwPO1lxDhIo4ProOD4YBT3WC8PGGzs3ppO5x3izECgC0txaRAOEEzb9JsNClMhQh6sUEhT4QiQMUkBmBsTVmWwe7W1IBHKonSoT0u5Dngby4uKJivGonmQy4q8AW6nRACNZfftRZnQThIE8Vyd4l7t+/y4+2PKNwU/UJSdN7GffnNXgjB8CcSNhfyveCx6OjK05QZ19e2Od3ps3uwx2n/mEk5wRQW4SykoDOF9BIx9w6IAjvBjTDsJx8lnJE+vmZ4Lec9rgZfS4QJO8gYw2w6YzA446R5jExXqdsdEnH+Xl8kd77I9nDOU5Q102JGaWsqZ6i9wwt3Du4MJ030ZAjPWVQVp2dnPHz8kE9WP2Ep73BtZYuubtHJW5f6EOKFJOMXe/4q/qQhXvXDD++ovKFugFxAXr8u/Dfc/prvYt6K9Be+ruL7iHnL31m3sMydR0GJJqFfnPLJ/U/44sF9PvviUx7sPuHg9Ij+aIDQkjRNEanGCY+xgeevZBISplIQZW7HkzEnpyc0fMJ4a/TSdlhrEQQ6HsBSo0PiJI0kY3NlHRAc9Y9wtg7bvECzRx1/bCg2AB/pZM6ZoE+ACwXA3GeewI33AFIFFTwEzkUXPetABw2AkF5CEROSv0E6QaJSuu0O6yur7GxusU6bI+kCZfJCCCFfWAd9vRuGRIbHhQTC2EKShNW2gJyE9e4q927e4tHTrzg43GNcjSlNFcCQ8wQaP1uOORPAQ2z9Cw9O+GAVrGDuS+wBrMMZwAiwFmccpZsxnkwYDceMWmM6zSYmM3CRDegv3nz5/ZnaMJ5OOBsNGBUTSleHIksrhA6aBgv/49glNNYyK2ccHR/xi1//kvFwxMbyBje3bnBzc4d7d+6xlSy/cj/6KIMsXihMruK7isv6Cwsnq+9itfd6GsGfdbz9HYA/BqLvSgzoewshBGpuqRvDe8/EzNgfHOA17O7v8j9+/a988umvefT4MQcnRwxnY0oMMtHIJDq5xfmu8z5I0IogQYsNyX0wGHBwcEBTZpR1RW1qEp0sXjOMHc5XlJlKUV6y1Oyytb6Jl4LhaMBsVgWdfRXV3dS82+ARQqKUIkkSEqWpqjrO9SPQTc4lhUPR6eddj+jc53zwpbcEiePgoXSe/E1dY6uaVCY0Ow3W19fYWF9HODgjyOW+ZIn7GpzD1x6XC6uk+X9SzG1+La20yfb6JlvrGzxd6jEoh9iJwTgbnAYdYHyQGBJugWsQc2TfvLvgIvo+1EThWFgf6IWxFnfGUdmKYlYymUyYTqaUssRa+4otf32yNd4ynk44GfQ5np0yrQt8IvFeLcSbPARWiQpoDe8cpak4OTtlMplwuH/A5sYmz7efc3jnLj5XtG/2sNQkKBrBXDnsuUWSuEr+30v8vi37b48WfOPjrSoAvh3G/8K93yavX/jT6//89zz7r//3H7KJV/GaOJ/bx8QfP7zTqqA/7NMvBnz61WckjYSnu894tPuYZ3u77B0d0B8NKG2FSBUqEeAdzgb+vYzsAbm4+PoACLSWk+MTdvMW660lrHB4dflkmFu3Xow8zVju9dhc36CoS1KpmVqP9Q5pgynOHNAfWvlB4CbNUlKdUNc1Sov49oLVbkD0C3ChDS4Cr5CwVhRBzCjUDAvtChcLm6ossaUhSRXtdovrO9fYWF+nk7dIvIyZ1EeGwLmGwu9/oLh0UTRYLAaFYkl1WV9ZZW1lhZPRMdPZBGst0gukDx4Dzrsg8CMj3TGC7LxbSCkhfGiCzPejtwJccB4EifMWYy1VUVHMCopZQZWUWPOqAuB89X/xWNa+phY1UzPlZNDn+dke49kUoVQAkybhWPo4xhFKBtAlDl9bZlXBZDJhMp4wmU0p6wqVp6ysr9HNeiyvdFFeoNMVPDVZ7MJckiy+wgV8J3H9n//+PPl/i937+kPw6gfepiP2VhUA3zpeAv5duPuFW1fx/cTr1PieH+1x/8mXDMZ9fvarn/PwyUP2DvY5G/QZjccUVQlKkOgEJwO639YOLwO/Xmm9SOTOBDS6QuK84+T4iAzF7c1tLIbClqQ69JCFCIn7xatDu9Vic32T0WzCYDggURrvXDAFcjIi9YPwjfUeGWHoSkl0okizhCTVaC2DeZGzOCvwTiB85JHP98VcJpbQehcEK13vIm3OOUxlcMaA9rQaTbY2N1nqdMlEgkKQoBdrUP8dINHDoCOUOxpNu9mm2+zQSHK0kPNeAVKExB0ki+NoXV5IhrEQCD8Eyl0AUgaIwPw5fKBa4BwYY6mrmrqsqU29wFxw4WnCsQyJ9yKIdGZnzNyMqSk4GZ2yt7/PaDIJGAstQc1fJ5odSYmUCo3CWbDC4oWn9ob++IziccXZcMjTZ0/51favePfuXT547338DY+bGVZbPZrym22vr+K7DHHh31c89jZl9m8ZP8AC4BuS+ytIAIvbV9X6Hz0uroLmbfeiLCiKgqOzY3711afs9/fZO9rj57/8Ofe/us/g7IzaWpI0QeUpWZaCFtTOYP35KjCME8KKOtgAG3AuiO44z2Qy5VT1GU+nCCVJdIbFRV/5VwPk2u0WmxvrGGE46h+TCBXEa4RAyoDat64m+OQ5dEzUPirbJYkiy1OqQmMKE9XnAoNARSEfAOLs38dtCIp488f8ObjRB0S9c55UJ7TbbRKl8JXD5walz4fizrmgpfBHOo/nxYRELJKtljooJUodCpiFVXJAElwGXF3cDomU4X2JuTJj7HYsigip8D5WBYiF3LONuAD/Nd7OF4Gk4ClsSd5tUkvL2XjIUb/PtCqQjQSpFSyKEx8NixxeBmpn0H6QKJkgRPB4mA76DEZD9vb2ef7sKc/3HjOtZjg85XDGOzt32OyskukUrXRUeryiBX4nIV5O9OKlG6/94z/+9vwZxw+wAHhFfG1NcNUN+C4jmOecJ9yqqnj89AlffPUF+ycH/PbBZ/TLIXtHezzafcJ4NsG6Gi9FuCBLH1rKcb6vRbAC9rGN7j04a3DGYY1FOlAyjAnqumY6HXN61ufo5JiTySkZKSutHsJfNG05j1azxcbaOsurPQ4O92mmOdJJnJJonQX9fGeCGRFB+rYyNUVRoKMWfqORUZcZVV1RuRLrgkuejNz/0ARweBNGAogwg5axAxDmASw46UY4vHVYEyyEi1lwtlPt84/3nI/+x7rAzTH6ITUrlFfU0mJqS1Wb4LboHM57ZMQ3zLn0XvhLCdkTV+lCRFfGeO8CfxuxFXEEIMS8eAjCR34hw/zyVr5YtHs8hppxOcELydlkzNlkxDhqCmQyDWBRIQIgkMBCsLamduDnyg1RBdI4F62TAlDTmIr6oGQ6nVLWNcfHR6wvreFri9mq6LW6LHd6i07TxeNzNQ74LuJr9unV7n6LC4BvrQVwAZizQP+//jmu4o8b1gXvehH57rWp2dvf42e//Dl7R/t8/vgLHu4+YlaXOO3Imjk6TwLXXgT7WIsLwDGt0FH0x4tg8+qsxRgL1iMdaBENaSK3u7aGk36fzz7/HAy8c+0Oje2MVqP5yhVapjNWu0ucDPs0kpxW3qKR5dQIgr6dw3uJRwKB5lZVFbPZDK0FjTyjkWeYVk5RzphNwXsb/naOUvbnbAjvY/L3oQDAhkSutAyMgAREHVbMs8mUw8NDfNsx7k2Z2Rkp5yONhabQHxKL0Wr0HQA0Qcq4pmQ4HnM2HDApCqy1i4mG84AMYxVHsHQ+72LE7ZOSgLn058JAzOfm8sKrxoIgCiFJEYAXr8qf4TkutHc9TKspp8MB+8+OeLq/y2g6pXY2FJXzv/EC4QOdEyHw1lG7Co8KWAAlg7qk9YBC60BzdLWlqiv2jvbp9/t8+cWXfPjO+zSylHYjR0hBp9UmJb3U+bqK7zBePDHE4h9e9Yl45WfkLS3O3uwC4DtJ0K+YAVx4rSsg4B83Lu/i8CEzxjCeTJBacjY44/hgP9jiLuU0Wl2EEtSmjkY/LijFLiR/Q2JwPji4OWMRzqGkJkk0ipBMTR25594zmUzYO9wnS3K6SYvt5Q3ajdZiu1zUqZcyJOFW3mIyHtNMcnqtLmtLa/SLCbV12AjoE0IBFh87DUVRkOWaRiMlzVOarsF0OmWSTLE2qBMGHwEX29ywOAnnCnku8uOjJLKWGqUFMg3FzWQ84dmjZ9g1y+jaFJtAjUWH3kGwEeaPu9oM63CBE56ZKzg5O+W032c8mwYQpArJ2XkfE7diTjs81xSYJ/nQTwj3Bjnl+f1zsOD5XC4WDDroKSzklF/YOu/dpSu6FILRZMLh8TFP+7scn/WZlkX47Xkh6jx4E5wchUQpgfc2AhVDV0GqoP7oVDAwUgSQphHgijDGGvbPmA5HrC4v0+q2eeej9zndO1mMF67a/3/8WAAAX5n0L93448UbXBy8uW6A8/i67b/42GtcAb/2+4u/d/Hnq/ijxIuzdiUV3U6HjfV1DvvQaDRwUmKcQfmAthdeLORwL15GPSDmAjPW4U3wb1dSkacZWZKGi3ZtMcKEdrv3FMWMk/4pWmo2l1Z47+ZdWF5ZbJO1IZEnIkEIQUPnLDWXWG522d7YoHQWe/CcvcEpKAtKIJXGecucrlebCmPqgAvQiizPaDRzGo0sJBYXBHpEBP4JEaWF5wA+50Ln3/vQCvehYSCFQqoU8ExGU548foKv4Ww6ZOJLhBe0RPOyDLC47Kr4bWIuYOPi/p8D6iyOkoqxn3Ay7nNwcsRRv09RVggt0DoJY5rI9UfMk7wLn0nvYrd/3s4/x0DM36NA4OYTgQsdg0Cv1CRpgtb6JaXIiziJi+fY2WDAo71nPDnb53jQp6hKhBBoJdGxeHTWIr1EJzp2LWzAl0SjKSlkMCpSsWBwwdrYOhs6R0qh05Qsb9Jut+kudWnRZJqPArj0Kr6buLSi+IafXxXngK8fxPT3ze4A/CEhCG0+EWeHLx3s13QCruKPGi+u2rTWrK+vc+/eXdL9jK3nW3SeP2Q8GwMByDaf7Yek4bEu8LOxbqEgFwqAcMEWCpw0OKHC+tK50LAXEiUEdV1zfHKMsHCyc8bMlFjnglFNfI2LnSaJINMZvW6PnZ1r6HaTs2rK0+MDfFXhGilJomKiC4pzzjmMs2EsgUdpRZ5nNFsNrHPUhcEYh7M1UnokCUoJEBLvXLDR9Q7pRZhPm+A5IIkmSVJSFCVHh8dkaZPjwSnDekztLM2sdWkfz9Xp5u5432YlOv+dF9H0DhgzYX9wyOODp+wdHzCcDqh9jUo0JJKaING8mLS98MwQmxw+7KvL8/8Y87FIqBeQUqATTZql5FmKzjRKyRee+WXAY2EqBrMxewcHPDl+xvHpCdY5lFJIqYMgUW0wVYkVEpmlyCQJFE3rY7IPzxXMjsR5c8KfdwgajQaNpR6bvTXWN9apq4pnJ89Yba+gxFUB8L3F61b+81HWvNP25i7i/6B46wqAb5evX/9bFx85v31BK+0Nbvf8OcaLF2ipFMvLy9y4eZO17XWeHD7j11/8hsIUhJYuBER4uNh7DDiDNWHe7qKxzLxlLgFrPEVlqWRJohMSlQQLXS0RHsqq4uDwAFtZ+uMBZ9WEo/EpnbxFK22QJslLFLNmo8Ha2hr33rnHDeHY7Z/wyRf38bWlTh2pCCj4uDjEuQBCrGtDXddIJUnShEYzxxiLN0XoEPjgRa+1RqugFGjx4f1FZUKkwFaG2nqkkCRKoaWkdobRbEJ/cMazvefsHu6zs7aNy15OOPMzOryvV8/PgZe6BBd/LrB4JCf1iAfPn/D5oy84ODlkUhZ47ZGpRiQSY0PxM0/qc3BlOPbyQnKfF1rhe9ABmIP9CKh/Fz6RWimyLKXZbNBoNMmz7KWV9Rz3ACFn1xjOzJizesrB2SmPnz7h+OgE5z1aa1SiEQ5E7XBFjXeeqrb4xAASG7sPVgSTJ600Ogmy0xdxCUpJMp2yub7F7WvX2VrbZqmxxHJjiVbSjMqPAf+iLuBfruKPEJcYABf/5aXbr/jjb37632+r/mzjrSsAfr/4urLhwmPx5vV/+nue/V9XOIA/Rrz4gZJS0mq32VjbwCjD9WvXWFtbYzwdMTEldWVQPnQKhArUMhFbs/MVWhDfkSRao6UM4MKyxlQVXjlUJklUAlrhvacsK46OjvHGc3R2yt7wCCsdt9evkypNopKX2svOe1ZXV7i2c42Zr1lZXqHVbDEyM/A+uPbNV7IEPX9TG8qyROugB6C0Im80sMZhaxc6AK6OOIBghqPiDpLeR+McGbANdUhOSkpEkiB0lBMWgtFsym8+/RQhFH/z07+l9+NVenQRWHLmUsIXVqwQu2GXj4UHrLOvdGIsMBwxwKF52t/ns4f3uf/VfU5GZzjlkalCJhKvY6HmAyMg8Ptj+3ye3PFhdOMDxuFiCe6jUqKDqLcQNlIrRSMLYM12q0kjzxeSzYtzSwiUDMfY4hnaGbvjY/rliJNRn729Q07HfRCgdYJWQcVfa0+iQ8GmbCiVnHQLjLAXHmc8NsILwrkhQrfJB4GjLE3Z3t7i3XffY2d5g15zibZu05DZoptyMelfMQD+8Lj+T/P5/8V7v26/Xu3zN78A+Dog4LdmAlx49CIT4Kr9/53HOR0sgsQIkrsry8ucjQesrqxyfecao8mYyd5ThqcDZKLIm02SNMFFgx1jDYGdpWg2Wyx1O7SaTZpZjneO8WDEWX9IWZS42mAdyJjYnXNMhhO0TDgdnNIfD8jzjFIYpEpe2uagWChot9pc397mycEenUaLlaUlKldgbYk1BqE8UipEXMEXRYVOwtxaJ4o00WQRA2CNx5gwRza1w9iaupagkvi+otugCIkmegeCBysdSjiIc+myKtnd30OrhDxrsnVtm3TlHRwFGUs4ApktgBq/AQfwiqJgRsmpH3Fo+nglefDsEfcfPuDp/nNmpowrf4EVHu9DIRRMjkJyF5yrMwbZBnvpIzd/nfNtkPGv51LBQRMg0Zo8T8kbOY0sQ7/YAQgnGEIISl/THw9wmcQmgmlZMBqPKGYFSZ7hrUdIaOY5naVlmjpD+Fi01SWj6YTRLJgGGe/wFqw12NoGjAGBoulqgxMS3exybWeH/4e9/3yTG8nSfMGfmUG5Dg8dlEmmriyRpbt75s7Ms/vs3f96786dnenpLtGlsyoVNRlauQZgZvvBAHe4CgYzmVVkBN4qZgAGcwAOB3DOeY/69NMfUTE+q61Vql708utd4vVjjgJYLvhfOQPgLVfc3t5mQFO4RCSgYEYZuGwU4KLlEq8LRcun2PK3GlZJtWZnY4f37r/HKB5xcHgA+wOsSkjFyFW5F4JAuOp6vvIJ/IDN7S1u377J6soq7WYTieBo74AXz/fY3XXpWaPRCCv0uMDOME04PT/j6wcP+MMf/4j36Y+5cyfNYtGnNeX8nEM/ZLu9xWCYsLm+wY0bO8iKYvdwl2E8QCqFpyTGpiRxijEpSgmiLABQSEUQegghcSEMLtBMmxGpjrEjg/E0nnJsgUK5mLksPdAZO85C1pnbw1hDqkek+hiERUYeUSPi7P0z1lbbRGsexqS0ZeuVfqcY12enj+H5YJ8nJ7scjo7ZPTzg13/+DY+eP+R8cI71JX7kY6UhManrx2BNZtlDHtE/LkgkLCJ3tAkX/AjOHZC733KrLk/PU0LgK0XoB1TDiFq1QuiHeHP2TB7cA/1en+d7uxybnusd0euSJLE7FwRSC4LAZ6O1xr3bt3jn1m1CL2DQ73N0esKT5894vrdHNxkw0ilWW9IkIY4TkjhxJY+RmCTF8wIqQcT2xhaffO8TTD9lrb46J/xLq/+7wMKArgyvYNFdk5/m7WcAXgmLAvvyQMDc+i/OKSxzAdNQ4lsjj9bO4QsPX/isr67z7t13wcLTp8/46/E5VloaUY1mo0kYRQRBQBiFhKH712g0WG2tsN5eY7W1Qi2qcHfzFkc7Rzx49IjPv/icp8+fMcoi1U1G14/imMePnhBF/0EYhLzzzjus1zeo4E+1eM2hkNTDKq1KnZubW7x39x1qrRr9fod42EMYUFY5Cjs1aG0YBbETGkmKH7iOh0EUOt8yhtQaUmMY9oeM4hFaG8LAEgYhSnm4HvZOeMisPK3A1dm3GcVusSRGQ+cU+/gBo3jEs2fP+OmnP8bzLQw0ycoOa2EbxXT73NmAQAN0GNJhyCorPOY5X+x+ycMXT/j6ydc8ePqQx/tPORucYT3wAw/hCbR1DXvynP882FAIFwMgcI8b1tH/ZKyEq5CXJQjkuQd5wFb2TyHwlEcY+lQrEVEYEuEvsK4n36U/7LO3t8vvHvyV56f7nJ2duWBCIfCQ1KMqG6tr3N2+xbu373F7c4fA8+l2uwTCR1mPVn2FbjwkThPiJGEwHNLp9uh1usSjkcvK0FCtVthob9BurKC0oF1foU517v6R8ppImX8EplwBi5Zzl1fhN1gWMHiFcSUVgEsHAs4W/lnw+YXLAm79p1/w9H/++2s42xLL4CmPdmOFX/7sl9x/9z7aGNrNNhrL+uYG7XabeqPB6toaG7U2fhBw1D0h8kJWqnVarSbNWoNKJQAhSIzm+d4LojCi2+2xv3fgXAK4YjvGCnqDPrt7uzx6/Jjn+7u8f/NDegyoUiNBI3GCfxwVLwSNWo2bO9v8l8a/8OXjBzx/+ojjvV3SNMWKEKkkCuU6+6Uu5mAwGCE9D6kUfuAT1SrOvS/IKghqknRAkg4hMQgJgWA6TVDkAWRZEF3uQ89K5Q51zNHZEXEaM0iGyEBQqQXUvAr7BwdsVNeohlUCP5jEVGS+eZulXMZpzEnao7m1ik5O2EuOeXq2x+ePv+TRs0c8333OWf8M4xtU4IHCtQeyKalNsbjSy7nFL4Wr55f7/F1Yv83SG8enPn4HZzpCFvwpUFK6LnueT7NaZ2t9g9vcJKa38B5KTcpIJwxtzOHpCQ8ePeT50QHdTtdlgySGsOrxzq3bfPrDH3Fna4dba1vc3rxBqEL6vR4nGyccdM7oJn1azTWs1pymXU7Ozzg763B2ekr3vINOUqphxEqzydb6Njtr29RVhRaNSdxFQckq6wC8Ptz6T7+YCQDkwuUpvMQt8NLPv8W4GgrAd16xrxgIWDIB3xVmA+18T9GsN1mvb3Dzxg0GvSFrrTVSa2ivrtJut2m129y6fYu79W2ElHzx4itqqkLdd9H7XiZgjWcZmZj799/l7PiM3ee7JKOUk9MztEmRUiGVqyB4en7GwyeP+fVvfkPFr/DBe+/Rjmr09QhfSioinHoZVCoVbt/cYcvbwvMEv1pd40VY5bx/jok1KlT40scIBQYGgxjh9UFJpwT4HspXhKpCXTr/vrYaYzWj/ghtE2Ltro0SHjIrFJR3EDSZb9xgMDJL7RMCi0YbSzo4I9lP0CbmvHPKSq1JKD3azTWa1TrVepNqpYofujr1zh43pGlKf9DnZNCFrwX97oDd/j57h7vsHu5x2jlmaEfIiodQ1ln+aKwxpMYJf1e4yGUayCztUuKaJ01SJLIWwAIXAOkq/rp0R5EpCwaUBV96rgBTs8Vac4V2tIJCIV0pnqn7R2vNIB1y0DnisHfCwckRT5885fnRPv1+D2UFoR+x0Vjh43ff5z///JfU/Qq3VnbYaW7iCYXWmlE84mTUpaO7vHfjYzwsu/aY/eNDOp0ep6enHB8eEQ+HrLVX2d7aRqGoyoCqCYnkdElmKOn/7wziUiL/OzjW24mroQBchFcOBJyZUAYC/l0w1SY1i56XUlIJIrrnPbzQY7O9wcfvfYTWBj8KabdXWFtfY629TlvWAfjBne8TLXnwB4zQWD5670Oe/+AFxgq+/OorDo4P0UYjcKlZg9GQ3b1dPvvLZ9SrNRqNGu/f3aGhqgyJp/ZprcX3fNbbazw7eE5dhdy9cZODF895spfSHw2I0xQZSPwowKBJ4pT+YITyPLwwQAaKQPlIpQiqITVbdwFzAnpej2SYgHGBga5ZkUIaV1BOStcy2GbFkUxmSUshQIFVrl5AZ9hl+HTA3uEerUqT1fYKW5tbtNttGv0WlWoNP8iYAJmXZU7pdDvsHR5wfHrCceeY836HQepiFIynkb7Ez4r9aJHVxLcaK0zh/Zin9jF5liaVfbIivzOE3LiaW97PwUBskJ6lXWtyY2OLzdYaYBgycLEQBZ8/OFanPxjw7OAFJ6Mue0d77O2+YP/gAOFJmvUa660V3rt3j/fv3ufG6hYNv8rN9g4tVZ/8yFVos06fmJWsrW8iVgjbPudeh7oMWVFV4uGQRrPBjfUb9HsD2pUGfioRV/8t++biFfSBVw4AvAK4XrfmKwn2BS6CKWVCcPM//YJnpRvgtSAvTpMvW1yOe+gHeErhKZ/3bt5js7WONRbpKSqVCvV6jZqYtFldJvwBKrh5d2/d5f/9//o/Wd/YcA2I/pZycnpCapz/PUkTTk5PePz0Catrq7x3/130XfewePhzt41C0gpasCrQw5iP7t1nY7XFv//ut/z6P37Hea9LKEM8oUhwlikjzTBM8Icj8CQpmiBwwX5hLQIpkJ4iCEOGnQHxICYdGXTsrHohLEqorGVxVl5XTmrru0DB1KWlIRHGMko0/WGPfr/L0AwwgaBvR1QGHcIgQirHgkjp2iAbo+n2uuwe7HF6dsrZoMMoGWGky3+TUuB5KvPX4yz9rNGPzKr6OXbCoG2m2OFMfWFlVslQuDx669wbVgiMYBI3YDN3iwYbazwp2Gqv8+G797m1tUOdGh5+9jg7JqTIJHWGXY7PTvnrwy95/Ogxp2dn2G4XUauyvrrGP/3s53z/o4+5v3OL26s71GSFZlH4ZwiQBETj9VUi6jKi3aqzGbWJV0akcUxUqdCqtRhUBvgoAjmdRbKoOFGJb4eb/+kX0+6UC2v/L8HfkTh4k3C9FABgTvJnwX4LAwGL82fjB7OpJV4TZp/Z7CH2hBqnd7VrTZqVeiZDnOBQr1DONsdqvUUQBPi+x8HRIYPhkAdSctI5Y9TvkRrNoC85PDjk0cNHPHj4gC9++IS1apsGFUQhcC5/13gI2lGTQXOVe7fusLGxytHxCV9+/hWDwRCbWHRssMoJQGslaQrDOMEOBCkpqdVEIsT3PCqNCn7gE4YR/bBH76zHoDNkqGNXFVDnQXIC1wtHji1sYwxCuwY2QrqwOaWyALvUMjAjTPeE/pOYYC9ASZeJIDLKXUqVlSJ2NfxjHRPr2NH60oAE4Tl2IbEpJtWOqvdx9fSVQCFdYKIpxCdYEMKCUChBFsOAc2mM2YEsAMC6YEBhXXqdshIpPOp+xJ3tHT64e4+t+joREQpVeC7dQ5mQ0GfEwckBv/nNb/i3//gND549xSQaUamw2mpz79Y7/OiTH3Lv5m1urGzQUg1qXmV8K+aZFssQAD4htTDA+GZ83yokYeju09mOkqXwf/0oyvf5OL4ZyT4bADj3c1yv3+fKKgCXDgRcMutCsqCMA/iHQGYtfy+DNE3zGPKszrsT2toYKn6EFYK7t27z0x//BOl7VH7/W/702Wf0ej2kdg18zk/PeP78BZ9//jm//8sfuX/jNh/ceI8KlcKRXBYB1iAFtKp1PnznfZ7t73JzfYet1U3S1HLSPaV/3kdGClH18WQASOJYY1WMVRahBNKTCCUJfJ/IC/C8AKU8QGCNxGhBIjQ6sWCyJjtGT2ujIg82AyUUUuH2i8Ao67IRTEo67MFw4JoMWZezbwUIXHCiJxXCVygPUMKdn8za5Hq4oEU0xmjXktm4wju5Ap236Z1k0pA1whGZYpJT/Ln9nik1rp8zZNUBhXYsSyOK2GitcWd7h9urW9RkvVDWKMssEC4O4SQ+xQ9CDo6P+NvnX/DVF19z0jklrFe5efMm99+5x/c/+h73b91jq7XKVnOdQPhjS9LV9TeZABdzNQYKlxpXHnl6uywIl2nHRInvDLPK1pLlBR98+a6/yfm8Bbg6CsArCuVXjwMogwHeJhRp4KLV5QLRAjw/IPWrvHvvXW7cvU2tWaPX6zEcDun0OqSpYTgYcLh/wJeff8Gv1lcZvt9htbHCSuM2MQlB5g/WOsGkQ3xP0ahVCcN3qUVNDvaPee+dL1lptvjj3z7j2eEegZQENZ9ABS5AL9EIBV7gobUh0RqS2EXkewov9Al1RJKkLv0PRTxISUcanZishG7mdzciY85FxpCAkK7LYGafYmTWZ09YNGn2ZnNznPAFITTKKgwe0khS49gAaSfx61jAWKcA4Hz/wgjQmdKFcZX7MuHvCv8494Lrqeg8/1kvoHEmg7VgZLZuRBYgKKgFFXZaa9zfucud7ZtseG007ty10XiFQLuT7ikPdh8Ri5QvH37Ni90XdLtdhBWsNdf4xY9/ys9++jPqYZV7G7fYaq5S8UKCQtEnKVy73/x6fhtcVeHxZkO8igbw6r/RFWFy3v5ugEUs/S4zyoGd+Zsvz47nQt8Wt2f7ypZv/ssvePa/yjiANw3zneHcf3NlwKXzKXa2btBPB3z/e9/n6ZNnWCnY3dvn8PiIs7Mzup1zHjx4iKc8xNDw/r13eadxm9jEBf+uResYhCAkIPBC1lub3Nm5yw8++ISDs0MOjo85ODzGxAYTW2ziivYYa5CeQKeGJNXYOMkK5zjL2BcKlMCPAqpG4MuQNExJhinx0PUViOMYq3Uhb35S1tda10hIpy6ozgoFSmIK78e8Jv/YJheuB4GLMhRZRL7FCJvrC66DoXUR/rnvf1zPf3zFJxHvUuZ1CzLhbzPhnwn+/Hmy5M2TLDo1WG0JPEWr0eTO1k3evXOP22s3qVGjawZIOU2zG2M4Ojnmr3/7nK+efM2DR48465y7WJFqjfv37vHJBx/zzs5t1usrrNdarIQTn7/J3hNSuIJDJd5s3PyXX7j7d2ysien3+th4W4BFNt2U4ScukClXA1eHAXglzDr03dgrxwFQavd/D+SpU652/Xhw3IQlF3qw/PcQuKI2xe0SWFF1WqrO6J33SP6fKe9/70M+/+Jzfv+HP/LZX/7C0d4Bh0+fYxNNu9bg9PQMDxiMhtQqNQS4LnLSd5H7OgXlEYYht7Zu8V/+5T/z6MUTHj99zov9fY46p4wGI4wC64OMBFoZhoMRqU3wjY+vffddtSWVnrOXPUVUkYQqwoSue+CwHzMcDp2QTmLXilbgrotwwt91GEzRWISUSD/IzjejrDNBJ+WYRHfKB2CEs+CdH949FiKr0Gdy615ZlwKYV/bLFebsQXHB/HnVP3f1LS4mYJwcYBmzA9YKtDbo1BKPEkjBq1dZa67x3jvv8S8/+yXfr/8YECQyxkMhs+56IxNz2j3l8PyIL77+kt/96Y/s7+0SjxJu3rrF9z7+Hh9+8CGfvP8h7965T92LaITTBXqsNVk1wiX34oIlYyyTr27HAkkUCiCV+G6w0Mi/rP//wvnXA94VV3AuVOAy+4TFj/XMumDsqwSwZRzA3w1j4b7EIrvsYytnZgomGvB6a43vffg9Pvr+91hbW6Pb6XK4u8vwrEd63qFzesazJ8/5/LO/cXfzNspCtBnSqNRRnk8g6lhrSNIRxGf4lVU21tbY3GmTWstH73/E0ekZnz34K4f9M+LeCAKBL3xSYUiMQWmJtjlZbzGJIZESX3p40sf3fKT0wBN4nkZID6RL/xNDkeXeO6GMshjhKgsm2gUYWinwsCjPIKxyt7KUGCXwrOsz4Kxz5zLIi/K4TIJMPchko0G7okMSp0Bk/8ir24mJ398FKApXpTBrvy3ytrpZAx2niHggJDpNQGukkYSez0ZzjdubN7m7fYfb9VvjX9xz0QrufKzhqHPM18++4sXRPk+fP+PZoyf0B0NW11b5wccf83/81//CarPN3e1bbNVXCaWPN+O7X9T4CCZ+/MkdNFlS4+88c3OV+M4xeT9PX/wpUoCL5MDl/P9X9U1/tRiAbxMH8DI6aGa8mCFYugHeLuR1BnKFwlhDJHxWqk086XFjbZP7N+7S++Ccqh9xsH/A+WmHvRe7/O9//d+g4d1bd6iHFaIgxFc+KvMfj5KYZDRChpowDInTPqvNVT5870PwFEEt4nd//QO7xweYOEVbjacFIhKu8VAKNrGkVmOEJkWglUfgW1DgC9fAR0iB8iRe4BGYAIET4hZAWlAaLSTCCGetm6yNvQDXbTCLExA2a2Mrsla/mYQf97Z3n3Ey2kXtI0GinAKgcDR8Ru8vUgCszTP9ZVbJcMLcZIfCZB37sJY01tihphpWuLNzi+/f/5gPbr3D9uoOmklbZo8IUBibctLr8PWTBzzce8LB0RH9fh/fD7jRbvPBBx/wwx/8gPt37xHKgPVGm0gGKDlRHqyxc+2Eiyjl+ZuHm//yi/HyrFE/hUXjiwiAy+IKuYaulgJwEYrKwSupdBNpP/lYYQclE/DWQwpJgGRF1vGBj26+h/8LwWZrjZ2tbU5OT/jNv/+ap4+e8pt/+xWD8z7dn/6MWzs3aDVbyIpEZTS0VAFeUB0rF4FXZWt9kw/f/5B7791nZbVNb9BnNIzpnR+i+zGpVUR+SChDAuGDzih2YVyxPOUoca00CS5Az3Wjcya0UhIR+Vg8l6InAc+g0QSkBCYkNglpTtsDZH7+vJ+AkipTANy9nZffJXMpSCVRnsLzXM97KyxWWpAmUyLEOPhwYiqPExVxHQBdzT6EzMMExy2JrRau2I+xMHIK2U57i1/+6Gf85x//EzV8bjVu0KQ1/t18aqSkHHfO2D3e409//TN/+/pzzs47eJ7HL375cz76+Hvcf+cerVqTu5s3CfCoh9W59FFR1uV/O7Gg8t80o/8Kv+vUrq7H/XBFugEW8XLSf2pdMCXARUZRToR+oWd6nmo1Tm/K93nVruHVRrHo0HjMGrws5WuztkrroxqtepNKJWLv6ID+eY+z41OO9o/5c/pnKkHEB/fvE/khG5ubrDZXUVLhByGe50/5kRv1Bje3dhjqmE8/+RHPnj9HJwmfP5Kc9k5RxiBTgUwFZuhq3goJWT0ejLZoDIlI8GyMssoVzckD6BBIJZBKZdkDIDww0sX/h6QkNiVJU1Kduk57AoRQ45bAeV+BHOO7fk4BcMWCkGCExaKxVo+F/vS1zZ8NV4zI/U+Bla6FrhFjNsJog9UpHh5Vv8pqrc27N+7zw/c+4b31dwgQrNEmIBifo0Fw0jnnq6dfsXu4z4MHD/n9f/wRa2B7e5P37r/Hz3/yU9qtNpEMaQY1QuGPv6e1WdEiIacaUZV4W7CA5M86TOZjY5UgGxOFbeOPzu7jGuH6MAAX4mU//oLtUwFPgpv/8nOe/a9ffVcnWOI7wrjscEFgSwSVIOL+rXcwWHYP9rGxoRpU+PPv/8TB/gFfffkV//Hb/6BeqdLv96h8EBIGIb4XImYyEBSSVr1BpFPevXOP//yLf2Z9dY0//O3PfPb1ZzzZe8x5r8t5cob1LH7FJ6qE+KFEZf0JjNVo41LupHVUeh7MJFDOKkcgpXVKgBIIRdaIRyGtQikPbdJxpDtktH2mAMDE8BmrtXlQ4VgJcO4CJ/AnqYN2/D8K79ZC2xubrZmsMmBqMDqLuLfKFS4apXhhxI2NHT5+9yO+9/73eHfrLpu0CfGoEYzf18Nhj/5gyONnj/n86y+RoUdYq7DSXiXyQ378gx/yww8+4d1b9/A9H89IAuEV3D4Wa41zp4wDGEu8Lbj5Lz9nEmTCEov9Zb9p+ZtfPQVghpJ/JdH+0jiA6QnjteupPF4JLGIDclSDiHs7d1hvrVINQu7deYcP7r/Hf////Hd2n7/gV//2K/qdHr/4p5+zsbVOvVZntblGsVJgjkB4BJ5H0PT58P6HfPLJD3j3T+/R/B910l/H9B5/RdrroNHoVgVPSJTwkb4Y39JO0BonnMcslSPThZVum1Qu1146QW3JhB1Z5T3fz96XmU9eSGwe/AdjC8lVBSxcG+msZZunBOIEaB4nIHBRV2ac2E8mWB3dL61EaIvR1rVGTlw1Q095hJ7vqgdWJKvNVT5+90P+23/6r+ysbLERtakREhWu6SgecHpyxNHJCU+ePOTzv32BV4tYWV3lZz//OStRg59+70fcu3OXVb+JxGVaFNsFSyGwC1o8l3iLsCD2cm7kW/r/57ZfMUXx6ikAF2FZHMCMkJ9OB5yeI5jNACil/1WCK1trnNCSkkalRi2qEgQBQRCx2mxjYsNv/v3XnJ6e8vDhIzZvbHH/xT1azSZSeTSrTaTwFr5cfBTb6xtI3+PO1g1urm3z/u37jIZDDk4P6AzPMUPNqDPEJglBFKA8Z90j3DnZcW9ZO3YBYCRCGKQ2SGWQRiGM89Xn9QaQecqfLPj7ZZYmndnqmRskDwwcfwlhx4LfZNfIkvv/3cfHiomdeMty/z8GbGrRiUaPUnRsXGGhQFIJAxqNBiu1PmGoiQAAb+lJREFUJhvtTT559yPubNwg0j5NKkjjsg1cwSNDp9Ph+YvnjNIRw3hEqg1xd8T2jSprzXV++MH3+PD2u1TDSe1+aUWmrEyS8kqr/yqgKM0LCZdzoQEXpf/NLl+f++J6KQBzuIzwzlvTFDWAfFPpBrhKGNPe1rXYzeWsFIK1RhvvHY84ibGx4YP7H/DF55+zt7/HcBjz4NFjtm5sgVKomz6hHxEKf+4YAqj7FSTw3u17DH76z6zUG6w0moyI+eLhl3zx9ecMuj0GoxibaKQnkb5CeR7W99yLLvN15o14xFhAG0C6OzZL59PGuPx2yzgAz8q89K7JWgmTVQHMFQ0mUf9MfOaaTKEga/wDEzs6YxIELhlACadoSCuzyn4Gk1pIDDK1eEiq0qddrXH75m2+/+H3uX/zHq2oye1gGx9FFZ8ge02dnpzQG/Tods7p9fps3drBazbwVpqcnHX46L33aFeb3N6+OSX83anl1L/JzvP6vOSvGi6k/wsawExI4AW4vvfCtVAALmejLxDwC3dQugGuKsbUeJ4OVugGI4BWrY42lu9/7/t4ns+H73/Av//m13z9+Gt+94c/sXV0gPxpwMrmOqkFL/SyNjXzxwFoRXU+/egHrK20WW23GdohW2sb2DTl6Ytn9EZdRCIyAa1RZN3yrOvER561J6TLxVNuPQ9aNZkio63zuwsBNsXFPEg7KfhjLNrkHnyXyielQVoX8JcrG07s506IolAFsFnmn1MBlMCF/FmBNK7qH1ai8PGVxJOSWlBjpbnCrc3bfPzOh/zzpz9np7qNThKahIQE49oNw+GQTuecvf09dJpydtahlybsvHuXH/34x/S7PXZaG9S9iGhG+BchRUn7Xwl8a/r/5UL/OqgFV1MBuCg1b8G2S8vuS7gBbvzzz3j+r7/+Rqdd4s2CyRzveZCYQOBJwfbGOgCeusf+0SH9eMjh6QFGSlobG6zXtnh6/IzA86mpSYNik9XtzxvLCKBRq/Pe3fv4ocfx+QlREKKE4MHTB+we73LSOeW0d8og7pMME0aDkfOXe8oxA4FCer4rxFPwabtKfTKL1HccvbPCnRVvcZUUx9WuszK+Fu2i9PPI+EImjLGZ718wvh6uBa8BaxDglBTrlA6jU7QBaSRCCxSCUIbUGk3Wmm22N7bZWdvm5upN3rn3DnerN6hSQfjg26wUr7WOwRBOGdve3GJvf584SUkHIySSlXqLneYG9UKGgLWuR0De1bC0+K8Gbvzzzwqum0vQ/xdg4bSL6P8r6Bq4mgrAZeEkOfOW/3xZ4KVugPF+soWrd49cWwgxXWZ4FivNOt/78EOiasiDF49Zu7nFu7c+IAR6wwGDYEilFk5qyls71x4WIPACbm/eYm1lleZKk83NdUY24bOvPuOPf/kTnz/4nL39XbqDLr1hzxXDkeCHPj6udoD0JCqv4Y/AZJX3XO19XGaCteNbVArl0gYBI4BUZy19LEiXOaCk5yrjCbJ0v1yVEONa+ZYsmt+6NrgKXKR/YtCJxqbGVeyzPmEQsdposbWyyXvv3OeTj7/HR7c+ZLuyTd/2WaFJhQiDGasyVhvieIQX+Ozs7KCE5ODwiHfvv0tUr7G+uklL1ufCLkUW65AHJ5bP5RVBHnAC87/pIvr/pf7/6/3OvjYKwCu5AV66qbAiBCKvUS8mwU8l3n4IsdhuNMaMmw3durFDrVGlub7C2ahP3/Y56HQZ9vokUQLVghtBiDE9n+ed58pFFEQEQUBYCYkqISrySNOUw71DkjimWWlwfHbM4ekhnX6X1KSAQBkPoYWrIIjFapM17skaCknpCgMpd8/a8fvTReoJIbLAPcG4aUoeDGGyfWaBhDorJCTykr8ym5e6uUK4lEdpBcJ6gEYKCL2AWlBhrdlmZ32Hm9s3uLV9k43aOjv1bdZY4xSFyl7crlhQdq2twaYav+pq9j/8+gHt9iobmxvUarXxb2SMmUu/LOn+q4eiHHfLYnbr3OKSvbz8ONcAV6sb4BQucAPMDudGvV0wx84s5/NtVmai0MksX77xzz/n+b+WwYBXCTaLuB+XvM0ghGC1uQK+4rTboSEqGEaYSsOlt81Y/ON1kdHxWuN5Tg+XSGqqxs22j09AcjfBDjR3btzl6OwQr+Kzf7jH4+dP2N3b5ej0hFjHxCbFDg0JjvY20pX9dY2BlKsJ4LniPTYT3EIqVKCy1D6RZT9k9L4EazRGO1vKGFfsx/UpsK5wTlalyFoDRiM1IA3KU1S8iNWVNu1Gk4of0qjU2Fhd553NO2y1t4iTmJsbO6y1NtjAuVNqVJFGUszMM3nUvioUVWrUkcqj0WhMXdf8N9FaF8oal7hKuPHPPy8Y7mIqGHtseF0Uw1W022a3vQzF410hXBsGYArLYgRm3QA57Z+7AXK3wKJsgHF6oWMESlwtvKxYTCuqESmfEIVXbdD0IkJ/WgGY+rzN6PlFLoHMl32zfYP6J1UOuiccdA7Yvr3N4fEhf/7Ln/nb55/z5NlTTrpnnHZOGQxHDNOYUTrKIv6zoD5pMEogssJA1kXnYVWKTo1L9ctr+As3b9y4JyuWY6zOmIssxE/mZYQFCg/PSnwp8D1JLajSiGrcXr/BnZ2brNSbrDRa3L11h49vfkidOi/OX9CqtKh6tanvbGfoM4ljMIJCUF+j1brwd1h2TUu8/Ziz+JdF/+c0QU7/T09Ybt5fw/vmeioAs7gor3+phjitCMxOu/FPP+P5/y6DAa8yiqyAEpJq4ARVxQuoeMGFny12OMzdAc73PRFgkQqJ2lu022usDzcIIo9IVehsdIiI2Gzv0Bv0OD474ej8mPNuh96gzzCJSZKUWCeuyY41LhhQWawEIyG1KbFOXbCgtAjlKv1J6/zmAmdVSSFRvo9SrsCQJz2UUvhCEXiKSPnU/IhaWKEeVWlEVQLls1pvsh6tsd5YZW1ljc3qBm3aKBTbzW1CwqmgxWJBptxNIhAIKSkQAARBoRSwMePeA+PX/DV8iV8H3Pinn00r08sXpjE3vESBuKa42grAa6sKuFgpcH+m4wGKTECJEpeBEGJcfGgxI+CxGa0hgUa1jroHZxu32D87ZX1tnWG/z5Oz5+zt79Hpd+kPh/QGffqDPsM4ZpgMiXWKRpOiSa3mrHPK8dkZiU3RgFSeKyEspWvoJ4TrbSAV7bU2K60Wvh8QBRGeVPjSoxIG1KMqK9UmW6vr7DS3qPohu3vPaAdNVuttGtU69WqNRqOBykL1KlQWXwfElPB/hStIUX0vcQWxzPIv3ikXCvuFi4sPddGxrxjEO//nf7vafPUMHW+XbcuWbXE8y2+2eXWY4npW8myynAV2jT/rrMPn//s3r/PblChBajQjG9NJR6yFK3jAw9Eez54/oTvo0R8OOO92OO906A0G9Id9hvGQWCfEOiE1Cd1+j+6gR2pStHUBg+RthqXzu3ueh6986s0GjXqdKIiohBV8z8NXikoU0azWWa23ub1zg/v1d/CRPD97worXpBE0UEKhVNZsqBTPJb4BbvzTT8cFqgAouuNEkfJfQP9PrWfzmSyzYPk6KQBXmwF4FSxyAywIHpn5kLNZitPn9lPiqsMWFEAhZ4KTvsX+8oY1npp+TD2p8KhQVZXx/jfCVaIdRbffpTfo0Wn06DX79AdD+qM+cZKQJgkjk2BMSmJirDTUa02MsQzskERrEIIwDIlkhPIUZ91TAhkQ+AFhkDU8UgpPKsIgoFatsdFap11t0ca5QG61blJleTGeHMaacT2BV702UNL91wfTgrpo8c/59xd9bBFFUN47wDVUAF7JDTA1lgcDLpq44FPiZUcqcVWwUBCJb67+5emCkosb1hT3X8cnjNq0ggZJLSFJY+IkcS2A0xRjNNoYV08fwygdMNQ9Prr3CRY4To/p9QcIJWnUm6yIFkbC3x7/lbqqEqoQJV1HQZcFKPCUh+/7VIKISE4E/mWEvzv/b3aFSsF/zZC5pBZvmF+cDv5b+omlh7pOuPouAPgHuwEogwFLvHFI7IiR6VFXLUBxmO6hrQUp8FXIKitooEeHKhW862crlHgD4IL/KOn/7wjlU13Ed+EGuNr3T4m/E2ymfFpcbImS8y2HXwW+CPFVOF5f9zaZ3OCOdVBAk8bcZy8LbfRUdH8xN98l2JYPR4mXYMqyL+n/143rUS1jthjLy6YvGBnfbEXtcuomW0QDu8/d+KefvtLpligxizxDQAr5rYX/siNMugu9HuRFk6SQc4V5SuFf4mW48U8/zV6tS8j8wvv3pbn/c2sL9zgzcPXv0ZIBmC0KlK87U56LawLM0AP5zWdtGQz4mjFbOvc7OUbhv2+DgMrvvHx5yoU1ZgyK127y2VdVIrTR2dLkISg2ZXHp+JMDvG0Wvp2j9y4++/F8e/E9abNmUsX1bPdv1fX5x2BB8J8oBtfMmfkLV2fdANObrvdvUCoAl8FF8XxTnoLlwYA3/umnZUrgK2AcWZ9R3pNSC9O58t9GIbB5tTx3oOxY+X6Zi1B/04LPZuOe7Oy9KFyL3oU06Dc5WvYetXb6yLONVmaF3puMvJhTMbsAmAjogqCe3B/F+CA3Vwq5VKjbrFeItWbKM5jfy7awXsLhxj/9NH8IF2y9ZOe/8nK+FNdHAfgmRYGmJr1aaeBxgyAKL+QSl0JRgIyLw0wZA6/nWoq8vrfIhaVYeJy3RaAV/e3TLqtvD1VstPOSfb4N1ypHsSLjRdvH64X/XuZemdzHuIyOGa3NdSt8O+6vvy/E7KWaVgYKGsBlSv+W9P9iXOFmQAuw9LvOuAGK60UtIJ9S/DteLtQxK6YHFqzXG7/8Kc//rWQBXoalDXS+02Mtf0tcxZdzTtEX/xZ9CteJnr7s7ysuIUku2tdllYzrjhu/zKz/gkEFjO9PAe69PGV0TbZPB21PaWnTMmB2/RriegQBLsEra4Vz2uWCPtOzfinH7c1rsCVK/ANRFP75+nUU/iXeQFza3z/7/n1NwX/XCNfHBQBzboALt10mGHBOA512B0yo/8lnSxbgcrDFgLair57pdLJvGwPgjuGsXzNzb0hZEI7f8lhvImYF/XUS/GPmw1qMMW5QwGylwbEgstOpmPn2fLrrQshUUOA4xiR7V1iTfzL/vJwcg6t3f30TjK3/MRb5+2eYmEW6wey8Vwn+u0a/w/VSAL4tFgr2aQHv9IZpRWDsm8qzA0qMsShKOq9iF4QBozjmvNtllCYIC5UgoNlsYY1xJXE971IR7dbaiWWRYRiP6I8GIAWp1XQ6XVJjEAJCz6fVaLh9G0sUhAQzHf7eltiAIoy1GSn1dp33t8FsRoLFYrRGKcUwHnB4fEycJhirx3OUlARhQBSFKM/DGEOSJMRxQqpTV6bZuKBA3/NZW1sjCAKM1oReiEKgdUp/0Hd2gRScds4ZJgnaahSCldYKURCi45RaVCEMwgVnf82wyPqf8/dPfWCybXaoxEtx/RSA1xAMOMsGCDKhnwUHToR/IXCwZAEWYpECMIyHnJ6fEVRCjk7PePT4Md3BACUEa60V7r/zDgJJLYxo1BtTCsBSobxgrDfo8+Jol1RZBqMRz148ZxCPEEiatSr3bt+lEkZ4WrC2sjqnALxt7xlrr18o6qL7QWBJkhGogKPOMZ99/RnnnR7aJhgEEoPnBbTbTdbW16hWK8Q6pXN+zlmnw6A/JE5j4lGKQFKvNvj4o49ZabcQqSHwnCCP45jjkyMSNDGWr5885KR7TpykRL7Hu3fvsbayihmlbK9uEvjBtVLMZrHc+p9xBeQGlWCx1T879QLMf/x6XX/vekdBzKf+TEXxza5PWfV2flv212UHFOfb8XIxO6DENOUKzkIdjIbsH+6zvr3Ji70X/Pmvf2H/xR7KV3z44Yesba7TqjU4755TiSr4nj+3v7kXqbUYa8fR7NZauv0uz/aeU1tb4ej8lK9fPOVgfx8pJbdv3WJ1fQ0/Cjg+PaVeqUG1MXUcay3yLXphzCpaBosQEhefvvx7LBKibxP7YRZ8v9SkRNRAwMHJEQ+fPkFIkJ4EY6hUKlh/h+ZGE1lpIBPL0MQcdo45PT2l1+vT6fRIRym3b93l7vv32Ag2OT0/olVtAcopAGfHVFo1uqMBT/ee8/WjB8TxiLWNTZrtFvVmnZPDA5rVBs1a4625pt8VhPOhMHkHT2hUIS6I+BPFvzNzBJP9za1TmL9o/Grj+jEAU3iZ/V+YNUMFzH5yTCxMxQK4QTdUmCAsN375E57/229f67d502GsgbHe5K6eMQYh89x+gbWGeDji+PiY/ZNDfvXr3/J////+J2fPDyCS7B8c4Hs+d2/eol1vsdbW093zjEHKSbpVzsHMKhrWWnr9Ps9evMCe7PNkb5c//PnPHL54jpCKFwf3UEpx/9YdGKWM1rbnvs+rviqKXQOBqZoGRf+yMXZcWKfoq7YwVjiEvHwXPZvFshTnj9KUBOMqCwK+kCDEZP+ZlZUrOsaYKd+2lC+PHzZZX4xibIUofP/x+TGtnEzVYBCX+5bFe2DG8+au68z31zpFk/L42RP+9Nmf+eyrL0CAUhJjUur1OueD9/CrAdaTjEYxj1885fMvv+TF7gtOjk85PTnHxJr9o2M2tjapVCqkoxH5nZHqhPPOOYf9E54d7PGr3/6KLz//nHQUs3pzBwGYNCXtjri1dWu+FsE1wo1f/oQpk774uy/I1Jlz6c+uXcL6X/bp6wTvWt5yS+T+OGukyPkXFqe9AE6Qz1L/49dP/uKBsSJgC/uzCHZ++RNeXCMlIC+WsnC8gFRr+oMBD58+5j9+/zv+/de/QpwO0RFYz+PG9g1sqql+8PGUYFJCYCgIjwwC4ZSPGQxHQ47PTvnyLw/5+ukTfv/HPzE8OQIpebz7AmGhe9bh/o3baKOnfMnf5GV9Uc55sejMd1Hpd1aMGgmxNmANFeVlQWzTDEEuiIE5gX+Z7y+zQi6XTTUqZCG+Mor3wNQ+c2Vras8CrQ1fPfmaP/z5j/z7b3/NFw+/YhQnCAlpmtBqNuj0OwRRyChJGI5GfPb55/zhj3/k4aOHHOwfcnp8io/HweExGxsbBL7Pnc1b46NorekO+nz++Eu+fPSA//Wv/8qzhw8RicZ79BC0IR2OuL99hyRJuK7c4M4vf0L+C+U1psZGExNFrvhL2hlXwGS98Pnxhwujhf3DjBi4hnrANWcAprGcDyhuuYA1mGKmplkAIIsantBZ11jhH0OpGWlnQUiJUoqN7S3WtzZpr69xPjogbIRsbG2ytrXOyuoKVszT0MssU6UUWk+CvCyQ6JTeoM9Zt8N5p0Nn0KHW1YDmpHbKWa9DfzREm2kr1i5YXkbdvowqf51Uen7rGWPcC9M6IZzvX2vNea+LwVJrrrCmfHYH5zSCaE5BeFm1xe+Cqr5ojzlr9KrHnXNdYMmbdw3jEf3BgO6gR3fYZzQaOUVxNMKg6fT6DOKYFEtqLXGa0B+O6PT6dDrnBB2NLyRnvS69YY/haIRh+t5IdUpvMOC83+O83yUYCGQS0O11Oe/16A36xGmMMeZaMwDFdL6p32xRnY4LbwGxZPllo9cTpQKwSKAvYQHmswgL1QDz6oAzLMA4VKD44YJ6et1YgJfB8zyCIGB9c4ObjRpnvR6dwYD953vUmjU+/fRTvve9j9laXcO3HlJd/nGetbAsFm01SFChwo8i4koPjEF4CuEpvMBDeQqpJrEDTriOk8HG9P1CYfMSgfU6FIC8RK0ADJP4BGMtQqrx/s87HV4cHTDSMe81G4AiHg3RYQWkf9EhLn8u30FsQJ5ON8sUvSpyxQhh0RistOBLpO8hfQ9MClYQG0lFSZDCbfM8VGgQgYcM3D0hQp847GGFpRV6CN9z94yc0NjGGLS1COWOEVQiOjWNHKWISg0v8BGeGs+/TmmYOXLrH5iR3dPWfz5hPFqw/uccAAsVhWU+get3zYu4vgrAEkP+0izAWLIvmVayAHPQRo+DI8d+X2tRyptQcsJSrVZZaa6QmJTN9U0++ehj7r1znzAMubWzQ6NaB2up12uT6ynAGIu1Bqkkknm3gqfmb3flK/woIKpVqTXq9EZDRJoSVSOiSoQf+ihfTV5IOdVc4OmnUsxmyhgvGjfWoLXG9/wxY5FdESyWNEnIshYRQoy/lxBizJgIIcfWvRi/CLPXWTanSKlbLInRHJ2doiUc909JR0P6nT6hUIio5lIqlUIbM94/1pJqjTEaz/NcYcsszmKOvSlcH3DBdwJBqlPSNJ15eTNxi5Fb5m6b7/l4Uo3HZl06y6CNAVyr5PzYxU9NrrUGDF7gEVRCwlpEWKtiA4nRBulJwmqVsBLhhQEy8BCkKM/DCwOCaoVqvUYnTRF4RNUKQRShAg/ricJrwZ2757k5lUYdmnWIEyr1GlG9ShCGSM8rSK3rh9di/c8pAq9o/V/Ty399FYApLBP7JQvwOnF6fkZqNHGakBqN9BWVSoV6tUYVl2InkURRyGZ7AyshCqpsr24wShN85dNq1NlYW0MJge95aGvoJwOEknS6HQCiSkQtqOJRFFDz1j/CuRsySQtKIDzhfkMpsdKNWwFLco4uhTRNSU2KkILQCznpnNA577K9vkUURW4OBoNlMBrw/NlzdKoJwhClPJIkZjgcojxFu7WClIpqVKEeVfGUYpnFXRyNdQKeoDdytPbwb39FKRCxoXd+Ts2PWG23aa2skCYp9WodgWAQjzg+O+H47IStzU3SUcpoMKTdWqHZaI6ZkVkMTUo/HeIFPvtHexwdHoFxWRhKSiwuYE9bjbYGbZ3SEXg+GxubbK1uoNOEihfizShzuTummIGRJAmdQZeRTmi2VxjFI/wgoMF8br2LCbGOPfIkRgKexJqsoY9xjIDwFUiBRjPSCYM0JjYJWoLwPVAeILHCPfFGTHzYRdj81pFOwAkJIu+8LMAIey0F0N/V+l+Ia3jRZ3C9FYCLWICF20oW4NvgpHNGfzjkvHfGSb+DlYL2Spu1jVXeW7tHAHQY4AtJq9FECEGzUufWxnZG3wp8pVCZJa9NSjfu042HWDSPnj0ljkc0W03a7RXurdwGoKu7SC0RFCxomFiX2Qtca+3iBIzGYrJUuQmtflnM0uDaarr9LqlNabfXeLL7lOP9ExSC27fuAJCSMjQJ+ycH/O7zP5MMY5qNFlElpNftcnJ6SqUScf/eu4RhyHprlSgI8bzLRQx24yGjNOa81+XPf/0LXuizutqmGoVIDTK13L//Du/4EI9SqpUKCMkoHvFs7zlfPnpAKg2j7oje6Rnv3r1PvV6fY1rAxVacDjo8O91D+oovvvySRw8eIbTGUwpfuRYk2loSUmLjFEKEpBpVee/efd6z72GHI7ZaG6zXW1PHmbTUnVzjwWjI3tEhR91jWqN1uv0elUqF+zv3MaQIk1KXVRQCi3GshNETBcRoNCb7n8VK9+gaYUmsZpQkDOIhgyQmsSlagBYCaex4X4aZQNPs9AwGbTWpTtE6xeoUTEpqNRp3r/HN9cu3Gn8363+ZB+Ci/V4DXG8FYAqXYAHykdfMAghxPViA1dVVOD/luHvK4ekJZ/0OtdND3rF3qVZqtFWd58fP2VpZp1VpopAoqQiWuKelFKR9Q6PV4HzY5bhzypNnT6hUK9y9fRtPerT8BnunL2jVVvAaHqrACkjp9u95niv7a11UfA6hRObTzd0VgHACXQiBRDoBojWeVMgF4fsGAxJ6gx5RrUI37jKIhzx+8ZSVVov1rU0qfoRF0ZIhz8QeJ+ennJ2cYj2JCBUnvXN2j/bZ3NokaFSo1RqMRjHWmLFdpDPKOzEJ/W5vHAAolUIEEiMsRgmOTo94/OwxVgj6wy1WV1ZIBiNqQcQtc4uwVmH/4Anba5sgfTyhODw+Yqhj8CVWWp69eMbG6rr73t7kFWKB1KZ00yHPjl7w7OyQxGge7j7h0e5j0lFMJYzwpcQY55JI0KTCkGLQ2tKs1VGR73zvsSHuj/BuCGphFV95C+MAtDXEOmbveJ/zuM9pOqTT6xJWIogkofTpHp5xs73Baq2FUJbUuEyTYTwCJbDSKXqpNc5FkykBZOxPrgwYkY0rAcp9abPwvVHAlHDP0hWzJSuWhhRfaez88icTgf+6rf/p0SVncI2lfgHXqxvgMlx0DWa3TXUHzJbtzNy5v7nQL7AATFiAvGPgzi9+wot/v7pKwHA05PT0lIePH/HrP/wHD148oVqtcOf2bX6/vk270qS92kJ+JAkrERWiC1PIrLAkOuXw7JjHz5/xb7/9DX/67E8IKdnZ3OTG+hbrzTW2dtb5+OOPqTQrBJmrIS8IJKXA9xVKCrAajAHrrDIlBUpJlBCoLIXRYuiOeqjIp06F82GHZBBTq9SohBWKRUwsMExGWGk565zz1eMHnJyfcnh0xMnJCe2DNs2tNW5u3iLFcESHz7/4nM8+/yud8w7DJGF1bY29vV2ePX1Cb9Tn7nv3QArqMhr7tA2W81EPP4w47Z7w9OFjrHG+8Gq9RlStIHzJ4xfPePz8CbuH+3iBR1SrkCQJ58cn+Eiq9RrttTbnnXNSnYKPy4fvdHjy7AkrqyvE3QGHp8f0Br25oMqUlK4ecDw65+tnj/jtZ3/k6fNn7B8c0Dk9Q6cpvpR4UmINaDSpsM6alo4lq/ghXz/4mt822uy0N/nhhx8TRQHrzTYrtRVCL6BYPx9goEcMTczBySF//uKvPD/Ypzvoo3yPjY11NlZXWYnqDN79gPs3blOv1UhNynmnQ6/fc24gKdHWkGiN1SmJccyAlQLlKZTnoXwf6XnOPSRwWj0WmysFM/yzBciYhLEbQOT3bv5PgHAukevyKt75xU8mK5liPVYG7GRsLPDHbOqCneUsa8GlOjd32Wdftu0aoGQAlmD6vljAAiwYmWMB8vUiC/BSt8DVxf7+Pk+fPuXzv/2NX/361/zhb38mjEK2N7do11tsrLb54cff58bNG2xubyJJqOCTp4DBNE2YaieoHz5+zJ8//yv/+9e/4nd//B3DwZBatcJKs8Wd7Rv8/Mc/4cadG2ywhsFkdLILEZOZkHcMgJ38A6SSTgHwHEsgcKljB8cHBM2IoL7N/skBSS/mxqZHrVLLzszVHRjpmLPeOSpQ7B3t8++/+hXPn78g1gnt1VWe7r2g2m7i1UIq1Qpff/01f/zjH/nss88YDAZoYzjvnHN0dMSTZ8/oDQfcvncXnWpWbr+H9BTWWjqjHs8OXxA0Kjx/9pyvvvwcPUqp1qpsbGzQWllhkMZ89vlfefz8CafdM2r1OqM0xnY1xyfHdM/OCcOQeqPG5urG+N7e3dtlGI/4+sEDd9MnmlD4pEZP3a8WS4qmm/TpJH2eHj7nf/zP/8HnX3xJr9fLFCyLJwWVICQMQoSSpFiGacJQx44K16BHKRXhc//2PRqVCjs3trDGEgUVAs+f8v1bIDGOneiPBvzH737HX7/8nOOzM2KdEIYBd2/e4hc/+jGtSpX1lRXCilMCe/0+g8EQi8AIp0gZl1OBydw/OWsns/tAKqcIGgps0YxwL8IW/xXm2Zlt1w0X0f1z1r+YbFtq/S8+yku2lygVAJjWHmfF/kJtciLUGQv8l+1/RpVd5BYQ4kqzANJzL8/EpHS7XTg5ZehJXljD2dkZ3e45W+ubSE/Spk6fFHBV24Dx5RNCZsysyMkTEpO4nOrOOea8x2n3nF63gzWa27dvktqUJk00KTJjAQQCkblrpl4QQiClRCqF8hSBFxAE7jPdXpenL56x4W9Tq/bojvoc7u7TbqxAa7ILozXdfo/EpiRJypPnz3j4+CGHR0f4UQUZ+Jx1zzk5P+X47IRaOmIYx4x0QmqcGBIKpC+w0ommOI3p9bugwKt6IBV9G7N7csBXjx9QazV4/uwZR+cnoC0q8jHCEuuEYTJiMBrQG/QZjAb4UeDcF1KQOxJGoxH9QR/lKazv3Bkj4RSZxKScnJ1QCytEUTh2jRRhMAyTIZVGlf5owP7hIcnRAVhDWo3wpCQII9bWV9lY36JarzBIU46Pj9k9PqQ36DAajvA6HXTssRtVOO2eYSWcnJ+wsbJGo1IbE8KWjEqXktX6On4UYDB0+336vQ6622WkNY+N4f6t2yhfsrLaotVo0UuGaKNJdIq21gV8esoxTtaiPFccyWLRxqCzPH2nHBiM0ZkCIAoW/uKXQMYTOFeBcP+ssNdS+O/8Iq/4x1K6f/z3ZVJbzM5b8JmFu1ngerimKBWAS+N1sAB5R0AWswDZ/q6qEmAlWCWQUiF9RawESImH86trkxCnI7qdDj2ScRS/p7zFBXesRngyE5QeXuQRhx46VKSB7/zTmQA8Pz9jP9lnxW/ijxWA7LVszDjNzv0ehdQzIfB8D993nznvdnn45AmfPfmS1dVVXjx9Qc2r8M6Nu1PfNUkSTs5O+erJA7TVfPn1Vzzf20Nrg1eJ6A16/PVvf+Xg+IBOr8P777/PKB0Rhj61RoUg8qjWagRhgAp8ZKhIrObs7IwkTbCeYIjmZHTGg+eP+ctfP3Mlak9PwEC9VqM36KN8xU7ouwh0T42VMLAI6VLU/MBDV0K0SRn0+whfkpIyArpmyIgEKyydXpdaUCEIXIe8WehUk6YpR4cn9IcDjDDEgWJkFY1KRDUMWWu1+eC99/jogw9or6/RHfT58sFDvAdf8mLvBSf6hNjzsgBMw1n3nEdPn7LVajMaDREzb22NJk5TUq+PCnyieo1We4VeMmSgExgNSY1hMBxyfHzM0eERURC6VEalnPKYBfHZ7HoA+L6PUgprITV5AJ/GaIMxLk4Akyv07sm1uYCfeisYXDlkGIv8PJYgn7ugSuVVRE79zyrb5KNjI38y9jqs/xLLcc2bAS3DMhZgOnhvwgLARc2B3Gfs/DzBpDmQgHE1lyvqCvA8Dy/w8MOAIIqQlQpIgRcE+L6P5/kIJRiNRvRG56yFa+PPLk51c6V/pVL4oU9YiYjqNQbGEoY+kR8SRhFSSQaDAWenp9TXq1PvBmHNzPV2LgCjCy99DCpLd+v1euzu7vLV84eE9ZCz/TPev/suR2cnJDod1xoYmYROv8v+4QEv9nf5+uEDzs7Paa2uUM180Hv7++wf7xOEAa2VFpV6jWqjxspqmySOqTVr+FGA8pUTVtbSHwxIdYr0FSEeIgo4PD/hL3/9jC8/d/Xsd27eoNVquToGlYgwCtHCUq1VaTQaNBoNqrUKQeC5qHzfQ3sKnSYMBwOsMfgqIATCZgUj3PVPRiNXZ2HBL2GtxWiDTlLOT0/RSULo+8goJAKiKKBeqbK+tsa7d9/h0x/9iO0bO5x2O3hBQHfQZdDrMez1SYIA4QlU4DFMYw5PDmlV6iQ6xRgzrsGQux200XS7AwyWaqNGo92iMeoxMimJJ/HDwKWLDvr0uj3i4RBrLUoItDEM4xHD4RBjNVIosBaRU0vZd8v/jSmnV35EbSFm4mo+3y9HZvCM/zolfBI3IyYsyqWtfzsZmGVgllr/1/X6z6NkAHJc6r54DSwAWYZAgfZ3QocJQ4Bg5xc/5sW//8dr+nJvBoSQCCFdBLV0jADkvlcwQoxjgNyYQV0QBmitxWonALR1edgun18ilEIoCYU8dWtm2+HmFpgrDzu2xkxKksaMRkNGoyFGa2xmpcVJQqffY//oAH2YMjwbsNJosne6z2HvhHZzFYulmw45H/Q465zz5OlTDg4PSdIUL/CpNeqkOuHo5IjRcMhZ94zzXgevGhJEIc1Wi9FoiOd7pDolTmJn9WMZxUP6g74rX1trcdY54+DokIOjAzqDDuvrG9y8eZMP3n+P27dvs7W9Q6Ne57zXJapWWFltszHoEvg+QRBgU4NOE5I4ZtDvc352xunZKZ3knNDfINYx2qQYk5IaSzwakSSJS2fLhWJ2JY01mMRgtWv6pKS717XW6CTBhobQ82jWaqyvttnZ2CCKQp60WtQilx0gjMUajbUSI3DBeCIT9Lkgzp44Yw2JSRmkQ/o6ZqRjUpNihHZsk7Rjel4qiacyBdT38XQKFnSakiQxSTxyjJL0QBuMdm4YJQVeFriorEBal/0hhQIhx8r8tBtJFO4v93fckGpOeRCQ3eNX2Wbd+cWPIedvitH/BXdAwSHAd279X+WL/QooFYCFeN2xAMV5TPv/x1sLCkJWG+CqKQE269aXC2sDmT8UrBQIT7qqaDLr4IeGlygA2mjSLH9fZ4FbOqO4xwFcmT/f0d/T+eTu3zgpy/2z2nWLy/6lOh0rAJ7n4fkKISXDbkx/OODs/Jyn+y/48vljbooYoy2HR0ccnBxxcn7G4fERvWEfq6wLOvQVeBBEAUYYlO8hlEvZi6oV6s06tmMZJTFpP6XT7TAcDgnDgMFwwNHxEV9++SXPKy949uwZX339Fb1BHz8MWFltsb61zvbNHbZ3dlhdW8XzfUYmpVavsba+xjAZkqbuO40Gffq9HsN+H8/C+dkpz5894y9/+RO1Zounu885PDogHg6pBqF7CRs9McAK0dsi0948IfGlawJktSZNEnTiY7VB4Wo5BEq5v1LiCYlEIIwFrTFpirECLSwy8PCiAD8MUVmp3bEbIGPfLWCEUwbiNGaUjIh14pSBLA1Tegrle+MqgyoX3pYx4yN0ihaO2rdaIyx4UhF4Pn72GSeuJUookAqsGQt/929RzcLFlEHucbrqRQCd8GdGgM+2Z5raNLswjSnFYHZ5+VAp9edRKgBFvCoLMCP/c+E+ZfVnkt4Z/FOT8sFM+7XjTMGxGXzFXAFJmpBo7fynAvAkQriXs+d7eIGP8jyXc20MBg1cXKPeYiY/R1bUBwHWmrFgl1I6X7fv4xf2Z4xBp67MbV5OGOmqAEol8QIfz/ecsMjctFEQ0Wi0WF1dxVoYdPqcdc45Pj/jpHtKcBJgjOHw5JAXB7vsHexxcnZCnMYIKemP+hyfHQOQWk1Ujag36tTqNaq1CrValagScXp2ysnpCf1+n9PTE0ajAUJYzs7PePz4Ef3BAM8PONw74NnzpwyGAxCQGkOn22H/YB8lJYlOaLVaCAG1Ro1Wu8Vp55ST01POzs/onZ5zfn6K7o9QCM7OTnn65DEjM8ILAvYOj3j88DHn5+c0d25Qr9eoVitEYUjoT6rs5ZUZfd/DD3L/uXFCPSuHG4YhlSgiCgOX049jvKQFhcATeTtii7QuaM6LfCq1KmE1JAgiJ3gzSCSBDAgrIcY4V5LBZYckOsUa7Zid7DdFCHdfaTNmgzyp8LJuiCbJ7hlt0KljCDzpChcpqXKaA5Gdbx4zUpRbF6atLhgTL/vQVcFMzr+Ysf6nNo6t/Xxolg2YXpwJKrjEubzSmV9plArAUlyCBZibN/OZXOgXXQHkQj8fLgj68fKkkNBVYgFGSUKSJq62PDhLX+IK7nhZKp7MauUbTXoJX52wmRIhXUofAjCGVFtS6WUdADMlQHl4hVveaEMapyRpms0Tro6+tXhBSBAG+EGAtS7AjQAqUYX1tTVuxrcIo4hhb0CSpjx89AhtLbVaFWM03W6Xo6Mj9g/2XRnjwMdg6fX7mIN9pHIR5q2VJiurbRqtBrVahUqtQhD6pDrl7PyMbrfLcDREek4p6fW7PH/xjJPTE7SFfrfP2dkpCItQgm6vy8NHDzk5OWFtdZXbt25x/913Wd1YJ4wCqvUqKvCI0xFn3XP63XNGyQgvK007jIfsH+5z3D0l1obj0xNOTk5Jk4RKrcrq+irt+irVWnWuF4BAZCVuXYnfUZpgrEEoiR+5VMeoEuEFPgiB1po4SdFp4ooaKYH0lCvMo135ZCSuAU8YuN+3AInAwyPKCil5gY8VEGtXbtqkrq7D+H7K6f4kQRuDUh7VapVWs0mz2aTbU1itQRvCMCTyA6ccWAHaYjJGCGOc8pLb/UJMLHmZu5MYe/aKoQPZhZr8wyKEubIswBT1PyX9GS9PW//LqP8i5riDuc2l9X85lArALKZk+AKJP6sJXMACLKUTFm0v+P/HBQMy9uCqKAHaOOt/qpSrIPPT5qlRk/9dJlhnQrsWydf8zZsH+GUU7cybxBiTCYWEJHWlWRFgPQ/pq+wMXMR2bJwPvtascffOHbxmxPrxOmhLt9PHAHt7ewghMFZjtCZJndDcqYRgDIlO0NqAdCWJq7UKN2/d5NbtW6ytrVGtVmj1mqyurnJyckKaJiglqVYrSCkJw5Ag8PEywWtSjecp1jbWaK+1nVWbXdPzzjlaJ1QqEVs3tllTG1TrVRrNBs1Wk06vgzGW0POx9QYRimoUEYUhwvOIs54NGhdYF4Uh27dusHPrBqvVFrVmndSkeNLLrrjFemAkjHTqSuZm/ntkFouhBEbYrOBOyihNGMQj+vGAURqTYsAT4DlBrDFZWqTGCouRMG4alMEDFB7WxqRpmuXvZ5k2UmRB+Daz/N3v4gIJJbVKhc31de7cvkMsLd3hwFH/qWajtcLNGzdYabYc02Gdwmi1yxpxcSOTe3ApTH4XTd/TU6+YK4qc+p+m7GfiAMZYKLUXb7/I+l+4D7FwsUSpALwSlot0t6X433z8cmmBE1fAWHiN5f8FisRbBiEzf7yULo88s4BSa0itzmqzZ4VVZV6H9QJYR8c6n23+UnZ0r6cUgfLws0p+WIuZqdduccy+Nq4CXJL5+o0QGCydbpdur8cwGXAen1OlQtiIuH3vNtXzBmtrqwTK4/ysizbGtZQlTxEja3CTxQ14jhKPM+tTKkm9XmV9Y4Nbt27RqDfwfI+VlRa3b9/C8xSbW5uMhkMsjIP2pJJYY4jjhHiUYIzNtvmA67wXxzHJKMb3PDY3Nmm1mlSrFawUrLTb7Ny6SVSvEA9GkGhUYgiswJcKKQQay0hrhmnKKBlhEFSjiHt37rK5s0MzqhPUI1LpXCwuWiNlKGIGOua0e875oIdVglRIEJaRTuiNhnSGfTqjAf1kxCCN6SdurBv3GZkULQWEnquF4Ak6vS6n52f01vr00j49hlQIUUgMkGAZMOTgaJ+Tk2OSNAZh8XwfL/LRI1zQKRYJeELgK4nv+aysrHDr5g3ObUxza43YGpSQKG1oRRXevX2Xnc0tgiB0z2KqsdrFsWByv79zW4w7MxbNWZsH/5kJDcC88nu1MWvhM0X9TysDlwn8K6p/iy/elb+krxGlArAI34gFmKECLlUciIKgL+6q4ArIFIarwAIoqcYKwPiht84iTFMXbGeMBlxqnyK3LieYf7gnKVvjKH8hCTyPwPNcnX+ECz5M0yywMNuXAKsyJSBTQLAajSJNEw4PDtjb3WWj3uJRq8lIJFSrNYQnqEQh9WrVWYntAVZkleKyNrbWumpyAotSiiBwJWRdEZms813oEUURQRDQ6/dBWJLEBevduHmD1bVV0tT1HQj8LB5BKYwxjIYjRqPYWfFBQBSGSKXQJiWJE5IkQVioVqpElQqjOCa1Ltah3mgQVSPn3xYSLwWVGkhNpiRZtJQYlVXIsxZfKqphBeEpUgwn/Q59HeMFHhhLrGM6gx7PD3d5/Ow5B8fHpFhMILFa049HnPe6HJ2dsH90yN7RIcaT7J8ccnh+wmm/Qy8ekmKwnsRWApCCo+Mjnj5/xkq1QbNaQ9uEdr2Bkh7aGAY65uD4iC8fP+Dxk8d0e64Pgh94xGmAtjYrWuQCMD3PI/A9ZOhTr1dZXV3lhkmorrYQgUfoh3gWKkKy1mwR+gGDwYDueYdhf4BO0iyGwCBMdnfayb1YvEMtFmMs5PEo4yyA7H61jLMaZssqv+0YU/9FAT5TwnlOMbgIU4rB7PKi9akPXu4Y1xClAvCKeJk9Pr/95WmBcwGBU66AyZS3XQmYBOnllpDrtWeM+5cY9xpUvhPceSGgZc+tEjIr0uPje14Woe5etGOLLI/0H1dymzAA2lpMmmURWJf2hZRoAXEcc3R4yOPHj2mGFWrVCqk0VIKIZBjTOe8yGA6dP9m6z0ntITLffv6CR1hkKl0QYPbdXVycYBRDp9vFGkOaarRNs997WnkUQjh3QOxKElsgiWPiOHEBjMYJbqWUS4lMU+dqsJZUa3qDPkgYpY6ajzEoX7mSvMrD0yASDYnGGo0RAnxXDdBK59GOk5het8uxlUR+QKVSpVar4Ac+CIjThMPTY75+/JjPvvyCp7vP6Y2G49TMxGj6oyHHZ2c8fvaMerPJ7uGBa+D04hnH56f0RgNinYIUGE+R6JT9gwO++uorQukRKQ+FZTDoIQWM4pijszOe777gy0cPePjwAWdnpyRJnP3WOf3vUkXzPP7cFWRzF9BoRBLHKGExQmEsDFPDcaw5OTjmvHPOo8ePODo8YtgfYlJ3za0xkKU46jglTZJx+uAE2byMNcj/TcagoJNeCUxT/4yF95S1vzTw7yLr/5J6QolLo1QAluE7YQFmlABmhP5LagOAZefnP+bFr95OJSDNc/aN88M6SehctYCj6QUuOFBQENXLIJBConzlUvPAWVvG+WqN1JMof2xW3a8Qcp0LaSRKKaIgIjEGaazz7Z+f8+zJE0SccnZySrvdxpeKZBgzGgzdTyUFJmsOY3Fd+ay17ryUygoICWdZG5O1fyVjQtyHtHZxCKlO3fXIXBhexpiI7H4Q2T4RLigxSRKssXjKcwqQFO4ap06i5C9QV9RIk1hDKoAs2M73PHwkyoDU1v0Vrh6DFpBI434P3G0rDCgj8KWLivf9LLVSOpfJWfecFwcHPN17wYuDPfqDPgiBCnz8IAAp6Q+GPH7ylNFwRFStMkiG7B8f0ul0nUKjNVJIpOci9s/OznhgHqKHMYPTc3YfPyHyA9I0ZTgacd7rcXJ+xsHJEQdHh5ydnTEajdDa0fX54wiOydDWtfe1saHT6bC3u8fDhw/ZOzvCCAiUj7IWmWikBZ2k9Ho9jk9OODg6ZNQfIDR4SDyk+721RScak2aKZn53CnfNyGoHKBRKKCQaZWX2L4teuVzIyxuPnZ//eInALy7PKwOzwn8KpfX/naHsBvgyLLg+Y7E/u80u2Z63B7bT8xb+zfeR+/9nsgLe5reEzkqqpqmL/MZo8Fw+uOcphHKCJLEaI2aL9szDKteiNbWaRCeYLPULY7BaY6RBa4M2OaMyHVfg+z7Veo3WqMnpoEPoBSQiBpNiU82wN2B/sMf5wQlffPY5KssFV1ltAc/zXIU+KR1tbs24SY5SalxO1mjjivkkiYtBEKDURLhPWamZoqKkcj75vOOfceqQy3QQWONq0mNxAlPIscVvjJnEWmTR9lprjADrqbHAxlqEAc9alJUEUuEphRWC2GhGJgvAo5APLzzQlng4ckWSsih/6UmMdBH4vdj59YdZ6qOnPHypEBaGgyEvhi843D9AKIXBEFvNKHXFjrROkdYpQUJbRsmQw0HM4KTD3sOn/D6IQBvieESsNUJJhKdIjGYQD+mP3LhGoOMUUoO0AqU8pO+D56ERjEZDjk5OePz4CZ/9+S882n3GMB65mgTGIrVLT9Spu1+TNHV9A7S7HlZncQBW4AsPX07qCxT0WfdPW0xqMInGJM7VIlKD0AaRZqzA2/tYL0Ah6n9sxMxNmWI35/YwNqIm85a0Wpja5dINV+r6vj6UDMCl8WosQPG/0yz/AlfAZViBAt5aFkBkflHtaGphNEjnk/U931HdVtOPBySYKWt92rvqYBCMbExn0OU4q6pnU4PIggOFEFnrVolFkhpLQkqevd5oNtm+cYPVu9vo3ws++8vn2O4AZSxGecRCEyd9Otq6l3eqM+seV7fA98f7N5gsAt04qzdTEACSOGE4HJIksasvkCkGQskxLe1iBpxykCsASsixkZTnruf0ch5QKYQYMxlGa0y2r6ICkEe+W4GLsMcFPupUg7EuMC7Ld88VgERrEpM6pURk1fCUh0I6izdOSJMEaV1AI0qQKoWVYKTASFy2gy+ROgsT1Jp4lKLjJCv2Y0FJl3GRKyW4RjyuJoCLmUhGMaedPt30BA+BThLSOHE0v+fhRT5COSUsyRQdoXxMmqXsWYHv+YSVCkGtilABI9PjtNNhf/+Qp0+e8vDhQ/rDvmsBbXBKiBXjGhHKy35v4cSb0ZZ0mOJ7HtWgwubaBvdu3yPyqwSZ68pYVwUxTTRpLyHpDFGdBJFKtJ9iBxodp9jU/bZvO3Z+/uP5wUtY+0vT/goW/+TZ/wbWf4mlKBWAl2GZhjo1fJErYNEnlikB+ccLroBCylxRIdj52Y958eu3SwkQmTWbl/BFO0vVBeu5JjXD0YD940OO+2c0qg2qRCTEWDQCgY9CokjRdOiw1znk+d4Lnj59Sq/bdf5/QGZC1PM8hPLQUqARxKke3/Wrq6vcv3cff6XK4eExK5UG5xyDsFTCCGldJz6TpmiRkojYRfVLhfQUQsixUoPNWgtL1zI2z1nXWrtSulaPBXsYBFlWgMjK7LrYBClcpTslFTKzJA3OypSedGmLSeoK5FjprNoxg+AEv5q76u4+yhvfCJtVWcyoaXJlI98Xbn8CR/X7yoPcqs0q5hljEZ7E98LMU2URAnwpQUqU76FCH+V7SM9lFmAM2qakErS0mCz4UkiBkMplfQjXdjeKQqKogu+7GgzxcMSoPyDpD0lGIyfgAw8pXUVGKSXWuuI8SIFQCj8IMYG7HqutNu2VVVrtNpVWA8+PMJ5Eg6v/b0BaizRMyv4ikAi0llggCHx839UvQFustHhIGrU6O5vb3NjYYWdjBztKJ1feghQ+nvTxhEdgfWLr7o/Qj6h6AaEM8ITnmKC32Ezd+dmPxzT/lMAvLheDAJcI/8KHFiwuEP7zs6dR6gEXolQAXgkLxP4F9NI8CzAp87v0E7MBYEwrBGMlgLdPCbBkfdYzBsBqZ4HKzCrQJqXT6/L0+TMePHmIvCtoRg0keV8AhQsNlMQkHJwc8PD5Ex48fsjz588ZDoauOIyQCAMmdQWBLALlBfhRRJLliUsErUaTd27e4bB7ymZ7k4/uv0+r0kBb7ay93Ko2WXlao7OiQ45GzyP9TdYWVmQCLC9IZK0lTVNGoxGpThEIKpUKUaWCkpI0dSl7xriGvOM0SSFdOmJ2oyilXIVEY4hjl++OcJX3pFTjcsY59Q/OZWALN1o+Djj3gTFOkAvhqOusAFLOIAghMgHr3qA2+93y8sljRSWrmigQ7rOA8hRhFOGHAQh3DV1qogu2s9qVz82FPk6mgrUoT1Gr1ag3mlQrVYSUxKOYfrdLr9NlNBxgjXOxeJ6zyE12nZ2y5VwSQRjheR5RELCztc33Pvoet27dptFYQeKD7xHVa2xsbHHvnft4nk+v38dTksj3CfwATyp0Vs+BLN6DjFnyVYDnebSqDT744AM2VtbQw5RmVJu65tWoys2tW1gjOdw94rEKsEpwc2ubD+99wDs3blOPavjKn/qN3iYsFf4zUf9ubPyfhZhWCNzyhTJ8IQFQSv3LouwGeBnMCflFroDCeHF9btkWCv5lVn+uFBTXgUnFwKywyWwQwcucYm8YTB5pj7PSEdJZ68YijCVNUhf09eghUTXi5OSY1eYKYRiQp9MpqbBGMEpG7O/t8+UXX/L1119zdHSM0YbQD7IcbeGo1yQFIanW66xVNknMgDy6IJIhW/V1qmGF+N0RZpCgUJjA0uv16HV79Hp9Eh1jtR4rKuDo6lzw2jw+o0hdZr+VMcalNwpL6AW0V1dptppYazk/PePs9GxcUMdTXlZIyEWnawye9Gi2mjRbTQA65x3OT8+IdYrKrHc7vvdEJoyzMsfG5ekLIVGZOyD3UNuMMSCj2p2R7rIRXAyDHJ+PzrI0BNa5PDKlR0pJtVqjtdLCDwJGwxH9Xg9jDFEUEVUqICAejRgOBgyHw7HCIzNWQgrHQmjj4jU8T1JvNGivrFKrN5BSuu6Q3a6rijgcggXPU05JYxIQaYweF1oKgpBKpUKz2WBrY5O7N+9w+9YdIipoDMoL2NrZ5mf+z7l19w4vnr/g8PCANE6pRCGNWp3A90nSlH6/z3A4AOOEeqVaZX19k82NDdZra/iRYmttk1ZYp+IF4/s9CEPW1te48/59Pul2ubV1kydPnqKt4eb2Nj/44Q+5tXODp48eO2XnbRVcoujMzw0eF7c0DmgWzvgZGzksW2fG4rcLlhetF8aZ3U+JZSgZgG+Jpa6A4shSV8BkbC4eALvAFeC2CytcL3Er2Pn5p7z41e++my/3miGkwssCpgI/QCqF0IZ0FDu/Mpoz4NGDBwz6Pb764nMCz0fiCq24CniCVFvieESv2+P05Izu6Tn9Xj+LIHdCzmgzvlbCCtIkJWaEJ/3xe0ECNRkRRB7yzrusrq6yUlvldHjCs6fPXG4++e/nivrkud3OCmYcoW9FluGVpYfZXCALZ9krz9WcD8IQz/PQRjMaDBkNR7iucxNr25i8aJFFCZkJ0wghJWmcMBqOSEzqSt3m11bISWYBeQCaCxK0guy6yIkSY3OlU4y/g9GGJE2dG0VKVJZaqbXLY88zG4CsQRL4vkelWsXzPcfsJBohHY0fBCFgGY1ihoMBg+GQOB5hMteP8tQ4GDKvyiiFpFavs9JuU6s1kEIySkb0uz26/T6j4RBtnDvIWcwZM2Emz0l+PSvVCs1Wi3ZrhUalQSADdPa/wA9ZW12jElZot1a4ubVDv9fDFusqCEmcxAwGA5Is5sD3PTwvZG1tjbt37rIerrF7/JRmWKeiAoLCKzWKIjY3Nmm2VxBbO1S9kLs3bqONZrXd5r3336dVbWJHKbVq9a0UWDs//5TcDBezVP4cEzDZvijFD2bGFlr303Pewkv2RqFUAC6Llwnx2aGC5F/uCihS/gs0aDvxCk52lysBE8Vi52ef8uLXv3vtX/l1Y2tzk8GgT7u9QhSEoC1pb0g/6CGVR2oThv0Bg36fw719/MBzflTjBKGSzh+bZjX84yRBxwnWuJoA1lqGgwHxwFmZQT2gWqngSUnci4lHQ+rhSmagu99CCkGIz3bUZjVqEwDtSoOqCByl7UtqYRUrLIO4T5KmY8vZ8xSeclUNDXkPA+uyEKwdU/K1Sp1IBvT1EJtq0lHi0iExWCWoh3ViG5MmCSKz1F06mqSX9F0bWuHhey5wUAtD1YsYJDHDeJC5HlQWEJgFCQpJXpnOuV2yfHQYl7IFENIJdef/Z0zzIxi7I5yCMAmIk0rhK9+lLsYjVw44i4eQSlALGwT4pLhufClZl77YZUJYa5DSpSHmCoDNMhgEznKuyjohFSSQYhis9unFjpEZDgfO4s/qO0jAyyol5oWSdJoipSKqhPie79iJpI+SjmGoiipe5BGJgJqK2GisIaSrQWGxnJ2e0e/2wELUilhdW2WluUKiU5SVhF7AZriOD2yvbqKMSwssIggCVldW8XyPIAi5uXWDzfZGFuwpWKk28ZGst1ddzIl4u1wAOz/7NKP+i3JfzAnuKbcAM39nFYKF1P8CTWCh5Bcv2V5iFqUC8CpYZLwXh2fN/eL63HJusEyUgKKhPwl7n7AAE1cAhXU38DYoATda28TbQzbXN1ipN6lGNdJeHxOnLmXPOqs2HcX0zs4QiIl/nEnTNGNxJVkxmfBXhIGPlAqdJIjU5ZK3V1a4sbNDu75CBY8GEWFGgltczr5AjAPncvK2huL+yk00MMRQy46850lSnWAyCjokxMdHIHHi3MUCSMffYJyIZx3nFz5XIZHyUaFAo+mTMGDIDiucMKTndwlliMSjRQUP2A/PqRFRy84uBfrENAmwPpz4w/HxXKy9S1Pz8QrnlhL7MQnJuFCQydLZXJVCNztvlOT6MLomSh4+EREKyYgRQwZIFOs0GChIoxE1QgQwIqXHgDXqAJxhsUg8FIEXUPGyfgtYpMjjOZRjJnLXxPifwGCQWb59RESsYmyq6Xd6dDquRXKqNaHv02g2WVlZIfBc06A4HnHeO3MVEFOXfqekpNFs8NHHH1MlxMdjJaxB6BSjmBSNoJN02XvxObsvdjE6pb26yjv37vNOdZsTBkT4eC6SAIAq4cKOfoEXjAMsFYJgpe2Yqew7+tmHGtXGOED2bcFE+M/n+0+vF4T3DDEwLfwpCG2xZHl6famML4X/pVEqAN8YLyP/F8wuTppK7ytQ/y9xBUynBhY0BfHmKwEn3SOGnT7VsMK9O+9wenLC0cnxuAyvRY+D61x3PrDSXSNrbdZYBZR0hWyEFM4PLhS+7yGyQitapYRBxL133uGDDz5ke3WLRlClIvzxSxdcO96hHbEiKwA86O5h+wkb9TaNag2NppN0CVSDrh3xfO8ZacYAVCoVqtUqYRhiwQmjNM0EauCiurVreqOqkjoBx/ERba9B06s533qS0Bt26dYaHPT2OTk5IfRDoiiC5iYtEXHaPUX5TcJQIazgLOlwkpxRrd6kS8rZ6BiMINYuODBNU4QQVMIKlWoFpRRJmoz97y4tLSGJY2dxC0EQBIRhSBgESKlIdTouphMGISutFQI/oN/vcXp+ilASb+MdEhKUtVgVuBz/YZ/D3hFJ2ylDu7svcH5gOQlwy2555bl4jtwN4Psuyt4Cg+GQ806X1BgqUUS1VkVaODs958WL5zx98oTdFy84Pj0lHsVUa1V2tnfGTZWEEJwen/Ds2TN2d3c5PT1Fa02z2eD+/XddmeVmHYXKUkIlIx0ziPucx32ePX/Or3/1a/Z296hVK9y+c4d37t3jrNpGIjLVbBpjfb0AJWRWCCpfd993FrNdFd90jIX/Ask+K/yXUv+zLoCprIGXy/D57aXU/yYoFYBXxaVcAYtZgClXQLZxPitgiStgSmHI5s3EA7zpSkAzrGJaa9y9eYfhj4d88sn3eL77gt29F3T7PVCAzFLn0qwqnnO0u7HENQh2hYNcKp2SEkEWiW4lo+GQQW/A6uoav/jFL/jhjz7lZO+IlWbTuR0KSHXK+eCclUaFB08f8a9//g1mmHLvxh02NzZIbMr++QneyHIW93h28AydJgilaDQaNJtNojAiTmLOTs8YDAYEvk+1VnPCzBp0aqioKhWrGIQpO+1NNppreJ7ipN/h+ckuz0bPeHb6jNPjU4SCalRhvbVBO2xwYruc1FZoRQ2SOGH//Ij9zhFPggfEHvR0F51ohvFEwHueR73eoNlo4Ps+cRIzHA6dS0JJjNYM+n16/T5apyjlEQYhftZsKEliet0+SRxTqVTZ3NigWq3S6/U4Oj4CIdjf3qdSj2hUavRrbTCWw7MjHu09xUrBYDjk8HDf1WNQEj/wXZyDcHEIueB3wt+5amr1OkjB8ckJu7t7DOOY1XabnZ1tatUanU6HJ48e89fPPuNvn3/OkydPGPS61BpN3nv/fb7/ySfcvXuHIAjZ39vjs88+46+ffcbTJ0+JR0M2t7b55//c40ef/oj3mzfHlSYTqzk4OuTZ0S5Pdp/x18//xr//278RJwnv3LnDaruNiVM8I1DSn72tgYn4WaQIXCVMCX+REfWzwhzmlYFZZWEybWbsW+b8X+WL/x2gVAC+CV7mCphdu9AVsKAWQJbbPWYJZpiDiSsgVwJmAw3fTNS8Kn7TR9xyvveb927z7PlTPvvsLxyfHCM8iZWg0wStNUKKrPiKcClzoxHWQugHBIELpsstS2sBA8nIBcmtra3xs5/9nI/uf8Sz5jPa9TbWuiY8br7zi/c7ff588gV//MMf+dWv/x1PKjrnZ+yc76CNZu/gkPOTU9fhrnuGNprAD2i2mrRaKwRBQL/X4/DggM55Bz8IaDabVCoV8ip8Js1yxtda9G/1GN6ICcKAk9NTnu8+Z//FHntH+3TOzomTmDAMadZbrDSaRPUKRyvORzwYDtk72OXg8BAPhRcGWAyjJKbf6xPHMeCCz5oN1/Y3CHySJCVJYnzfp1KpIgSuy97JMf2+S6vzPB8vqxIYxyO65z1GoxHVapWtrQ1q9TqDXp/T01Msghfrz9jc3mR7a5vOSgerDfsH+3z9+AFHx8d0zjtu31lqXxC4LAcp3W8mPYmnJJ7nE/gh9XqdlVYL4Sn2Dw548vgJw3jEzs4OOklZX1tjOBhyfHzMixe7PPj6AV988TnJaQfVrGO0plVvUI0iatUax4dHvHj+nAdffcWTr75GDARn52fcvnObp48e07/3CdXs9Xc26vDs8AVfPfyKv/z1r/zpT3/m2dOnrLbbNBtNojCEWGMTTRgGC+/tHNdG/kzJfVFYXyCMs7FxO+6FbMBFy8WdldT/64T3hsuMtwDzkne5MHYbxsKbaeE+2wBowvJn40wrBsV4gNxFYLFs/+xTdt9AFsATCi9QbLbX8QKfqF7BrCZ0Ns7YaKy6ynPCYnWKNRbpZTX+hSRNNHESY61rjetnedpCuqps2mrQLiVMSUUYhdSDKkYnbLbXqPuVcetVgXsZCesu61mnQ2/YJx3GqCii2qhTX2ky6A/AWnqjAcNBH2HBEx6eUAgN6SjBJJpht0/cH5GMEqy2DOQAUotSXpY1oNGeIuwPSdIUbVKs8Z1LQ2dFdDJvuDACPUrpiS4Iy3rgugBWm3Vk4OGfBpjU0EmGRCbFVx7JMCbuZy4Iz5XqTeOUQXdA4sUuNQ5LoAJ86YoupUHIwA9JpHMFkGYBjBJsasb1FNCGYSbIkzhx1XuspT/oMRoOUEpSbzXwlEc/HuJ7HsN+n2F/gMhrPFhXL9+1WtauzJ4xpEpCahEpDIWiJ13hoHgwBGPwyAryaFekx1ce9UqV1ZU2Wxub9DodemGFoFZjtbVCvVqlEoREQUAtqrDaWmFncxsTJ1it2blzh5VGi/PjMx49f8i7N+5htKUeNWivryIfPyQZjAilx52bN7l9+w7vvfsulTBAaIuOY0To3EXGGow2Y/peiMXSJw+ozB/ozKGFQIw/Y7P1Nx3bmfU/Pu8Zv78tCnqRv8+yKaIQJ5V928n6ZCcTlnQBBAvetm/+dXuTUTIA3xTfyBWweNOEzp9mEGbjAaYiBWddAzOpgm+qEgAQeSHrzVUC4VHdDKmK0OW95zn11pGzQojxCzYvq4oFJaXLIS9WFsxS80wmdDzPo91uU1M1tNJOuM6chxKKih+y0VplePsdhmd9/MDj9s3bbG1sMhqN8FC0Gk16/R4m85l7njeOONfGMBoO2WivMxrFSCnH/myV5dFH1YggDNDDhJsb2+ysbhGEIZHnIwzc3rnF4eEBx8cnjuXAIpXEDwNa9SabG1s0V1qkaUogPBpRncQkBH6AEor+oE+/18daQxCERJFjR0QW2Y91pYvrtRqNRh3P9xiMBpyvn9PrdUnidCyQhHRKpE5dUyEhBMpXSOkCMq122QFB5LPSbrO1tsHm6jqe52O1YdDtEkifwWDIOFVPglLSVTrMBV+WQimFQAoXAxCGIUJKalGVdnMFIQTt1TZbm1s0Wy2MMfhSESif1dYK7927T7/TwQsCbt64wb1799jZ3sH3fepRFV95bKyucXJ0TK1aZXNnh1qlxt3tW7SrTZSVxHqIUJKtzU1u7tzg/N4Jm2sbSCnZ3Nnk5s2b9DpdQj+YitJ31PeMZTsDW1zIctaLAi4X/G+T8J+S6NlfMbOeLcxb+pMt826D5Qb/go0LJr35l/CNRKkAfAe4jCug+N8pK38mNXCqCdACoV/sFDirNLzJSkAg3K0XiYCd9e2pqnVTyF4ws9tnX7rTm/NKdk7oyyzO32ZFmPLPKymphhHNepPQD1FGYK2hElaQVlCv1KncjrixtcMwHpLqBCFcp76c3o+TZNwj3uS1+m0mJH0fqRQr7RWq1Sp7L15wY3OH7fUtlOdRDSJ8L+DG5g32jvc4OjwijkdZOpwTxr7nE4RBVvrXZ3tji/X2mguAVAprbFaoZggCojAiDEPXXjmZuFLCIKJWr1KrVfF8FxjY7/cZDAauWFLmepJZYx+JzNLpNHEaj4MyPenaLytPEVZCGrWGq7oYp1SDiFs3brHSWCFJkvF3cP9cpH9e894WCryIPKsF4RoVGdfTwPM9qrUq9WqdKIqw1tKo1lhpNLmxtc35+TmDft9d45UWG+sbtJotENCsN2jWm7xz5y6j0Yh2u83a+jqnR6fcvXWblUoTJdyxDl7ssrW9xcbqGub9D7MGRopGs0FUidi1u/j+dKW+XHm5CMso8bdNVhWF/7QwXxL0J2a2T31xMfO3OG92vHist++6vQ0ouwF+W1zEArBgyM7MLVIBuS6Qj+V6Q76YKwU5lThFLhSUgILSsP3TT9n9ze++1Vd8XcjLyM6WPFXyHxMFLRD4yncCJowYDYZonaB8nzAKCf3AdZtDkGjXrS4XktZaV+FuOHLuCuks3LygDVg8z8P3Aja3N6kHNdJhTLu5QpgFIzbrDVIM9TAi3LlNJayQJglxkoyvlbVmfH2klIiGqzvgSse69r/9fp/RaISUkqgSuQp2Scpg6ArYKKWIogq1etXVRfAVqXWR/sPh0AVX2pxxcc2KPM8VCY3jmN6gRzxyfRBC37EZrgSwwPcCKkHkzi+rGdCoN7KaAwUFAMA6FgELVpisWJGdlCbWJktNlHiBTxCGrga/5zvXhrVUoohatcrKygrDwZDhaIgAqpUKjYYLyjTGEHgusBALSMH6xgYrzRUefv2A1VabKIyyu8AitKAiqrSaTYQV1OpVfBXghz7GaM6OT7M2zPmTdX1E0fZPP52i7eeEP4xdlrkiN70+2e7inYrr2f7m/QHTWPhqFS/ZXuIyEHf+H/9Heem+DezSlWkKsLitsO4W7fx4vpz9nV13/59dL+7LTqxma9n9ze+/8VcsUaLE9cP2T3807eaYs/Sz/4jcJTJZn2ILptaLY4V9zY7PrM+rBiX9/zrwdlWfeBOx3HFVZLiYv2GL+rSYHxfTc+fyZxc+dDOnVnhgt3/6o1f4UiVKlLjOmBP+s3gl4c9i4f8y6r8U/t85ymZArwNzFNTCCIDpbeMNdunyJK7PZptskTeY++uKBkExdbAYG7j90x+VTECJEiUuhBP+bnnaEMnijqY4/Pm/4+3jJj9M5ixs7lNchuJbc7HwL7xDS3wrlAzAd4JlGvMFs4sswSxjkK8uq7S1dN39p6iNl0xAiRIllmEi/Bfk6b/K+2fufTdt+S8hLaemX3KwxLdAqQC8LrxMwI8XLnAFiNkPLeiaNWbZXkUJmP5bKgElSpSYRdHyn/97WeFf3OOiYj+zq69C/U9PK/HtUSoArxOzN/Jl1maVgLk7e7H/f2rqqzIDlEpAiRIlJph6H3wjppGZ99Oylr/fNOVv9p1Z4nWgVABeN16mBIgF25bR/8Upyx6ub0HPlUpAiRIlxu8BwTcU/hdF/DP9zlu4XJi00DVQCv/vCqUC8I/Aops4f3AKy8wu5wPFud9aCfjht/02JUqUeEsxfv6/jfDPV5a+qybLc+8spqeX+PuiVAC+C1zGFbCQHpvdtEjLzgaKD+zMAzX70M7+nVYCRKkElChxDeGe+5l3ycveGzmmDJZp4T/v9xezr6gZTDaW1v/fF6UC8F3hMkrA7FrxIZqduIxaKyoBwPSERccrfGZKCSjdASVKXBe4532J8M+wUN7Olvmdifj/RkF/S49XCv/vGqUC8F3iZUqAWLBtVgmYu/MXZQa8ehBg6Q4oUeJ64kLanwVjl3mfLHov5eOF5YXvxIXsQCn8/x4oFYC/KxbcyUt9YWLJsluYDwLM/77iQ5uPlUxAiRJXHgst/1c0JqY+MsVMzr+nFi8XsJhmuPT3KfHtUCoA3zUuuJenCQCxYOOyoMBscUoJKLgHXiWIp2QCSpS4Flhq+RfeG5cR/q8S8S8ozmV64vwrbR6lLvCdouwG+PfCkq6BU2t2ett81eDC9mJb4XH3wKwT4NRvOtNSeHZ9qsPgZM72T37E7m9//zq+eYkSJf7B2P7JpLa/e95x63kVX2bZgAXsQFZa3LUsZ7q7Xy7QC8tiqWyZzH0p9V/Kp+8U3j/6BK4Npm7mC5SA4lr+sOWiubA+tU1kSoDIlABhJ0pBtqPx2OycvNewyJQAtzMQ2UsDy+5v//AdXZQSJUp8l9j+SSHSHxazgHMuxUX+/Et295uy/Ge3Te/zpcK/xHeO0gXw98SSB2G8JhZsK2xY7A64iJabfjBfvZiQ+497iZQoUeJtwmsR/hfOKY5Nll8q/GeHi9tmFkt8tyi7Af5DMX3tiwb+1LbC2NychfPtXCfA3C/gLP/JPufmTEiCjBlw+9r+yQ/Y/e0fX+/XL1GixHeC7Z/8gAkPL4qymwmXT9ErkK3PvBym5hS7/lHY/2R5WvgvkC0LhX+JfxRKBuDvjQtYgOlhsXRsGROwSCsf9/Iu+v8KFkE+Z9YyWNTj271USpQo8SZjIvwZ/xVFyZs977PvhmnLf/JuYDy8iG0sHmN6fRoXSf7S+v9HoVQA/hG4QAkQUwsvUQKKS99SCViU5rNYCSjdASVKvKmYpv0XC/9Ff7+V8Ifp99EFwn9evpfC/x+JMgjwH4Uikza9MlkTzGcGFMbG9P0MLTem+cd8vnuYrZ3m/CfuADcmsr/FQEBhBTb3CYzdAT/EYtkrXQIlSrwR2PrJDxDMCOwllv+3Fv5jFMcnx5xGKfzfZJQMwBuDb8YEzNJw+fJLmYBZxuCCWgGCmSCgbKx0CZQo8Y/Hdi78s2czf65fSfiL4thLhP9L3z/zYxcK/xL/MMjH/9f/LH+JfxQWPTCL1hYpAdkGMTvxskpAgSa8jBIwmSemPlsqASVK/OMw5++fVdbhcsJ/LOhfTfgLCutTeAXhX0qgfwge/1//U5QugH80BBcmYkxvLqzNLo7XBePc/pe5A8Zj8+6ARXUBxvOg4BJwSoCF0iVQosTfCY7yhykBXhTIfzfhT2Hb/MpLZXsp/P+hKF0AbwKWP0mTEbFge/FBnZ3zDZmA2ZeFEMKtF90GMy+dfGyrZANKlPjOMfH3zwr/wlj2zI6fXxgrA69X+C/RBGaHZ7fPLJb4x6BUAN4UfFdKQEG4T42zWAmYsxiK88Rkn2VcQIkSf3+81N8/kfCF55uZ5/oVhL+YHi+F/9VC6QJ4kyBYmhkwP6ewXbCgZHBhTja4zB0AF5QFhnGGwFQWwdQ+8we/dAmUKPFdYCHlz6w1Px6Yz/EvLE8bBS8R/kzPuYzwX4xS+L+JKBmANw0XMAHzBMAlmYDC4OKUnaI1P3lxTDZPXipLXyRTLw03r3QJlCjx7bHU379A+DsC4CLh7x7W71L4z8v3Uvi/qXAMQFkN+M3DpboHzm+fYgIWzck6BkKxi6CbM+kkKCa1AhaNjTsH5gcQGXlQLBXqxrZ/nLEB/1GyASVKvAq2fvyDjIGfF8jCLhojY+gmf8cCfXbMFqS1LRgG405/k/3mhOFkhZn3E+Oxlwr/Uta8UfCg/E3eSMw9ZNO/0rRcL2wfP9yT9aliQcXtgmnqv+AaGEf/LxoruAZmswTyN4zN+whkJ7D14x+USkCJEpfE1o8dezZ2w82wd3Y8PGHlJq+LSXrwWFFfODbZr80HZpWK/FGf2z6ZM6MDzG+fWSzx5mD8s9z+b/9S6gFvIuzSlRkmYGb7zJidnWOXbMuXrc23zo/Z4nGK+7ALxor7cAN7//EnSpQoMY+tH38/WyrQ/UwEMYsUgqXBfkyE/IKx6Y8uF/6Luf2S9n+b8eT/+78ElDEAbz4WPXSza/MLZNwhxYf5Yr9ftj5rWSwam0ktmryM5sfmU45E4SVXokSJHO65yB7cgnU+F5/D4pid1yX8i4/3eFsp/K8kyiyAtw7TRNt4bX6hMGEy5hj7nKrPt7EwQ8C9UBZnCABLigRNjzHuWZDtw31wrASUbECJ6455q98tv7Jini3nm+cV88ny/PjsMWfPpzC26KOz20u8FSgZgLcByzTw2bVFTMB4dTL28od/0YvoEtbGVBSyGI9NrIpp66ZkA0pcdyy2+meeueI4FMZ4BVZusvx3Ef5z76wSbyJKBuCtxetiApiyzIUoZAgIJpH/xUBAptmAYr2ASaRxyQaUKLEMr8Pqz0bmrf7C8tTcJQr+9LbZ7dPzSsv/amHqVysDAd8CzP1CrxAYOF6djL2u4MDJR6f3YwvLMzudBA7OnEOpCJS4qpgS/OM/M9Z3wdc/kcWLFAKWCP9lVv/Mfr4r4V/qAm808gBAKBmAtw/5T7ckRXC8eWrhZUxAYT9z1nq2bWFcAFNpgXPNgxBZJmCRDRBjhWARGwDuJWkt7P+uVARKXA1sfvr9V3O9LbL6i+Mzkf+TP9+B8F8q+GdGS8H/1qGMAbgSuEAnFwu2z4wtzxC4OC5g/CKafWlN+SOz+fl4vp/CS2s6ZmCy/zI+oMRVwNaPC8J/6h6fSeUbz1lC+V8Yd5MPTPbP1PiC5/d1Cv8SbyVKBuBtxYxhv2BgMjJj9TM1BtNsQP7ET4oDLYsLcMRAZt1PMQRuzjdiA8bHnrABULoFSrx9WEb3wxKr/JWsfvefi9mAlx17dvvM+KsI/1IXeCsx97OVcQBvGV4SEzA1Yhdv/9ZxAdjJ+EyRIMvM+NLYgNljFMcnxyjdAiXedLwy3Z8r07PjiwL9iuMXWv0LjsEC4b9QcJfC/6qi6P+HkgF4+zFtxHM5JoDpOTMMwSvHBXBBlgBckg2YPgYUywm7bULYMj6gxBuLXPBP0f245aWC9xtb/eP/vEbhLxb9WTxn+YQSbxHmFYDS/r8CGEvp4si8WmBnf+zJWEEdKMwTmT6QW/AFZSIvKEShPTAFBYHZBkLZeOZOmOQRZHNs3tBo4iYoHn/r0+9jKRWBEv94bH76fQTZnVts0mMLln2mEE8glo5P/Xf8SGT3vlg8PjlO8fiTfY+PReF4xce/eA52sospiJnRUla89SgZgKuKYm5+PsRs2MACJaDwucl7rCCEM0tdZMtjRWBpLYHiOJlboMAezGYQ5OdcGHfHyV90pSJQ4s3AlOBfSumzmL6fG3f/mRpfyCBccJwLt80c74LxeWKgNPWvKhb+srf/axkHcKUwZ+kvCh1YFBtQiAuY/s/U4PTwktiA2Xz/8WphfFE9gZedRzF2gFIRKPHdIxf8Dq8gdF+avz/+zwJaf358cqy5g15O+L9M8C/7XIm3Ek/++/+a+zGXMACl/L9SyCzvuaGXzJlMsrnh75DPy7a7d1JBERAT4Swy7jFPHJjEB2RWf/HY+XttbPUznjveH7PbCscCtj79ZLxt//d/vuwVKlHiQmz+6JOxUBVTwnjCv08a8s5I3/HqhNkqLoviuJjc8KKwPL7PM/aswCMUtpHtxxYOLwrnydy8wqx5zMwpcfVQugCuCxbQ/ZdzCTDl34cFLgE3iMBmcXyFF1MeAzDVbIgxze/eTcvpf5tbPAvofwSLyxln65ufflIqAiW+FcaCf84KnyxcRM+PZ13KDSBmFr+N1T97rsWppeVfwmHpr3z7v/5zqfpdRSyi+plRBJbMmaXbF7sE3MLiVMIF26aY/sW0/3Q64ew+7cz0BcfLlvZ/VyoCJS6HzU8/AQrCtvDn2wp+t1gcn93nRcdbJNgXCP9lb3YxNeulc0pcDTz57/+68EctGYDrhgXBgTDDBiyZM2ED7PidNRWlX2QDxEymwBQbkAv7AhtA9lIcuwUKbMQUUzA+8DQjkAceTm3Ljpctlu6BEhdhOc2f4yJBe4HgL6x/E6Xg8lb/ojnzx5n7WkvmlLj6KBWA64rX4BKYig0oVhrM1nMqfqwITMUGuPlOD8g+my1PhP2MIiLytEEKioCdvCynYgTE5MuU7oESF+AyNP+FFnZRuBfW57a9qtVfFPxT22a3L5uz4HyWTCmF//XEhb966Qa4BnidLoGZseK6nZ90KbfAwmqCheXF22bO64LjFueUysD1QdHad3iDBP/UoRZb/VMfKSn/EhdgGf0PJQNQ4rW4BDLLO1+9DBuQrS91C7yMESjWCYDCtmy/c4zAzHHzkxsTCHbs9y2VgauJXOjDMuE7PbZYwC4QwK8o+N2mJdtKq7/E3xGlAlDC4du4BODysQHgFIFM8C91C+RvuoVxABcpAuMTYCqlqhAXcKF7IBvLXQRQKgNvMzZ/lCl1YkboTy1ewtr/poJ/Zv31BPktOr/Fx5vb1ZI5Ja4nXnoXlG6Aa4Zv7RKYLNjp/8zN+cZugewcFtL/c9sWHX+Re2DROSw6z1IheJMxFvgwb01PLYoF8+ZWptYvEu6Lt02Oc2m6f+bUXsnqnzmHpS/3UvhfG1xE/0PJAJSYxbd1CcCrswHjz7j1olvAKQL5G7CgCGSMgC2wAIvYgvHxs48vZwVmziGHLVZpc+dasgNvFopW/sVCv7Dybaz9mXVxWcE/s+3VBP+i81x8PnO7WjKnRIlL3RElC3BN8W3YgPHEC9iAqdVlLYIL278FIzBzqOmdz6wvZCYWnM+iXZUKwXePxVZ+trJgcbHQXzRwecH/Shb/9A5fIvhn5yw88YXntHBXC+aUuB54mfUPl2UASvF/TSEWCvgpNmBsXS9zCxTYgHxpoQDOOwbmnynMGW93K/PdBme2T70GCxZ/YZ/L5gDjeIKpeXPKS4FFKCgDU8LJwv4fSoXg22Lzh5/MSbbxql0iHAvjk7ksEISLhOfL5hTviXxVZHEsk+Wpj9rJyQhb2DD1MBUE/8zYwnewmD6PC4V/+Q4vsQClC6DExbiMSyCft0gJmHohfgu3APkBF7kGiudX3J4dLH+jFtZFtm4XfceiRVXoezClNEyde0EsFBUCMa8QQKkUXITNHxbo/ByXsoanx6cN+wUfmLWaF1rsYmb6YjZg4XYxs3Ch1T9r8U99YDFKyr/Ea8Cl75Db/+WfSh3yuuMyLoEL5i0PEpzZy0K3QGHjUtfA4uPbRedzUeDgZc9rwZTlLoPZoWk3x/4f/jI/+Ypj84ffcwszwnKZfF+4Mre4RMAumnuBX38ydPGcC3382eJlzmuOfVj2Zr6M4F8wr8T1wpP/+39f6gYoGYASl8ersAEL5s3SoQtz9C9kBLKdzFj00xb//PEnL/Hlc8aBg9nY+HQWMRW5uyEbt7Mv9Sn6d+ZaFandwnTHFCyKfXi7lYOxkM9RvK7Fa75wzoKBWXk83teSHb1M6C8Ye5m1v3DO31nwL51aCv4Sr4BXultKFqDEGN+WDRhPXhR8N2udTxZeByMwZiBeOo95ZuCy57hw25KBlxEmr/CZfyguENzLLdWXDCwT+Ms+u2j+pYX+ogO+TsE/mfDa6f4F80pcT1zW+oeSASjxTXEBGwDFGKYlbEA+eaavgLOIxbSQvSwjkM8prE96DeT7sOMdLmUOiuc7ywyMzyf/Xtl/FrIDk21zV8lOry6S6GJqaF6yzX/iElrBZRSHS70+LimULpxwGWFfWLqElT+edgmhPxm6jNBfdB6vQfAvnLvkPJZMKwV/iW+KV75zbpUsQIlZXJYNuGDuIp/7ZRiBxbucZwXmhhZ+8LLz5semT+ny3/Flh7lQYr9JT+KFb5JlgveCuRdtXypjL2HpT//n1eYt+Nxy5WD6fL+N4L9o6v+/vXNLjhuHoSh6tmEvYx5Vk2T1SaZqHstw1tHzEbebkgASfEmkdM5PYomA2LKkewmyZcQfQt4yRv8iVACgBd5qwKOt+W0Bya4I/EwZmAZjncDzIRyI/KbfiXZh27Vg3MO+3RStX1YJNvu2KRdtVXPwLE1ogTthP2982pQY3ceaWAfwiv6qrW0OltuW6RsK/zY5wg9dKbqKqAKASYtqwCIgpyLw/OGubCurCkTamu317a4qgdbPDGKntBX52rMeRUfaRf2AT/A/4h2ib7ZVyvzqOoFOwh9tjviDQu7oX4QKALQmtxqgtF0G5FQEnj8sqwLhA9hZFVj0a9V2kWZ1zxkVArnfV5qyyGZUCsIPF+ayN+yvDdpo2RmT0sUiwTcyuqcCltvU0b56CIQf5qP4iqIKAC5afFtgEaBVBJSMWvvkWoHnNn//7qEnUHbHRvqOc1NRDUgnN2iiM7pYFolbTCStUb4S5xX9bWikzP/+T7bwW/1ztANYUzL6F6ECAL0x5vw3FYFYNWARoFUEltv19uuqwHujWxDjrQws+rkuW68MgRmn7HtsXrRZ7HmmWeRU0+g7irXEEtnM1B4xayT4y+ZWpaJwtP/+T1fhV9oCtKTq6qIKAFlERsPZo+ePoFVFQNluNDAOYQ3nIyP9aD/v2j8Z8RVtY2mUbc2kJke0kmK/+E8yPmoUjHy+0f77RnX3xgkk+2keItIeQKN09C/S4J7HBEA2nY3A4ifnokH7MObqv0JDsM0Zbd1C8GtytBCiSI6t9iaOlyP4ke25c/tGFoQfDqVG/EVaTAEg/5CNXe7fTA0k2i/aBKq/zHNbO4In4RSBagbC+ytU7Vicdk+uphmWPRfNTdxl21YlKfAVz4hkak//rJmM9fRIYv8jl5bsvm4ebNe6Gr6/efMrXiq++kIm/ULdHsyazXG0B+hNE7v5+oUqABSSEK/yisD2B/8UwSrOqgCocdsNdndj8wLpY41001kD6vSIPt5u6y+ssr6ewz/Sf99olfijceYBXSGM+qGEt691o3+RZosAR3oUwVR8jKT0a0gdaCVi9EF7UBWwRm83XV1vt4Sg35Rk5lq/+zbH5jaOGIMMLdoeqJAqgXo/fnI+/26/j3+xOXbi7nHDcIvEvudWhf/mOIe37UXlF36en3AMzazn65c/uIqhnpKKgCPOVxUwAopG+LF1B3pbn1bn5N2J1ChdC0kaAl/eqgpBh9G+J4wRP9Ty9vXvJhdR0ysREwDN6GUEFsHbtvrsQEp0M0v+9uEL8+blyaPsEZEU5uTuFlMC+v6obHs+LsIPB9JK/EV4DwCMivpGvmD3Y5cVF1PLcPS5MgO3YP9z11pE7IWEP7tgCbdedt5gtNf1QzEx25OiBRYR+3sFvgR58S0E3z5ChujrnUmHI/owMM2vTqoA0I2eVYFFAqMyoO5KLSbUNxaV+527DiOuhOlwTxXAYyCOFv1IHEANLUf/Ih0MgAgmADpTagQcsXqSSkNgbvaM3mOMdJv5HyXuKoKZskDwo/nWIZGKREUsQA2txV+kkwEQwQTADjjUsokZWCSKmAHzgDmmILpjl7/2V0tcA2Mr/J07kpqeOcoXqRP9RDxALT3EX4Q1ADAziXUCIsY3AjPit4k2CwTi75+5r3sR7LBu6fWagzC9tW4gwr4vAsxd7OfYmdTzAsEXQfTh8nS9gqkCwCHUTBE44uMJ9VjvTIFL3KvuKk9wxWPBp5yuzS55bij6rnSIPuxMr9G/SGcDIIIJgANxCnmzaQIzaaSk7+5IUcOy0KqngjPYreEVYv8RVznST+QA6EVP8RfZwQCIYAJgAFqYgYw86cQFVYrquygnQeWjIWdNn9Wig+BnpUX04UB6i78IawDgKjjn+6NrBtZ5ErnMxOEGwxh4Fsrnf5Ow8HniCMvL3EjoP+KzrUVVLoCzsNvV/vqZKgAMRsZo3l+db3SZO14dPCaRR0qrp41TpLMOh/DDQLx96z/6F9nRAIiIvH7+feQnF1ydLoagKrpRJ3KDCh4LzZ4kRXMH+V1A8GFQ3r79s9vFuftdgAmAKcgcyWdf1D2NwRSUC31hc0QfhmdP8Rc5wACIYAJgQnobAlfQTLdNzfsAGoUg+DARe4u/yEEGQAQTAJNTONff/Sv8bY/4zr5TAsWhCD5MyhHiL3KgARDBBMBJaLDwr9uNcJD+75YW0YfJOUr8RQ42ACKYADgpjV/aP+NN0v4vlxz+uAJoypHiLzKAARDBBMBF2Okv+fQ8yn7Lk4d4NAF042jxFxnEAIhgAuDCzPAn/nqB0MMFGUH8RQYyACKYAIANZzAHiDzAB6OIv8hgBkBE5AUTAJDPEUYBYQfI4sdA4i8yoAEQwQQAAMC5GE38RUR+OboDGiOeKAAAgBJG1bQhDYDIuCcMAADAy8haNmzHHrx8YjoAAADm48f3ccVfZAIDICLy8uk3TAAAAEzDj+//Dq+vw3cwBCMAAAAjM4PwPxh2DYDGTCcWAACuxWwaNZUBEJnvBAMAwPmZUZum63AIUwIAAHAkMwr/g+kqACEzn3gAAJib2TVoagMgMv8vAAAA5uMM2jP9BwhhSgAAAHpyBuF/MH0FIORMvxgAABiLs2nMqT5MCNUAAABowdmE/8EpP1QIRgAAAEo4q/A/ONUUgMbZf4EAANCeK2jH6T9gCNUAAACIcQXhf3CZDxry8uevGAEAAPjgx1//XU4PL/eBQzACAADX5orC/+CyHzwEIwAAcC2uLPwPLn8CQjACAADnBuF/wokwwAwAAJwDRF+Hk5IAIwAAMCcIfxxOTgaYAQCAsUH0/XCiCsEMAACMAaJfBietAZgBAIB9QfTr4QR2AEMAANAWBL89nNAdwBAAAOSB4PeHE3wQmAIAgJ8g9sfASR8UDAIAnAUEfkz+B7FCKXdNp/m5AAAAAElFTkSuQmCC", sizes: "512x512", type: "image/png" }
      ]
    };
    const blob = new Blob([JSON.stringify(manifest)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const link = document.getElementById('manifestLink');
    if(link) link.setAttribute('href', url);
  }catch(err){ /* manifest is a progressive enhancement — safe to skip if it fails */ }
}
setupAppManifest();

async function manualSync(){
  await flushPendingWeeks();
  await pullFromRemote(true);
  reapplyPendingWeeksLocally();
  render();
  pullPhotosFromRemote(true);
  flushPendingPhotos();
}

(async function init(){
  await loadData();
  render();
  updateMobileNavLabel();
  checkWedBanner();
  const fy = document.getElementById('footerYear');
  if(fy) fy.textContent = new Date().getFullYear();

  const overlay = document.getElementById('syncOverlay');
  if(getSyncUrl()){
    await flushPendingWeeks(); // حاول تبعت أي أسبوع اتأجل الأول، قبل أي سحب
    await pullFromRemote(false);
    reapplyPendingWeeksLocally(); // لو لسه فيه أسبوع فشل حتى بعد المحاولة، رجّعه فوق اللي جاي من السيرفر
    render();
    pullPhotosFromRemote(false); // مش بنستناها — الصور مش على المسار الحرج، وبتظهر لما توصل
    flushPendingPhotos(); // لو فيه صور اتأجلت من مرة فاتت وسايبة النت
  }else{
    setSyncStatus('غير مفعّلة — البيانات محفوظة على الجهاز ده بس');
  }
  if(overlay) overlay.style.display = 'none';
})();
